package com.zarvimo.cricket.stream

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class CrowdSynthTest {

    @Test fun everySound_isStereo_audible_andNotClipping() {
        for (k in Sfx.values().filter { it != Sfx.CUSTOM }) {
            val d = CrowdSynth.render(k)
            assertTrue("$k has an even number of samples (stereo)", d.size % 2 == 0)
            assertTrue("$k lasts at least half a second", d.size / 2 >= CrowdSynth.RATE / 2)
            val peak = d.maxOf { abs(it.toInt()) }
            assertTrue("$k is audible (peak $peak)", peak > 8000)
            assertTrue("$k leaves headroom (peak $peak)", peak < 32767)
        }
    }

    @Test fun rendering_isDeterministic() {
        assertArrayEquals(CrowdSynth.render(Sfx.APPLAUSE), CrowdSynth.render(Sfx.APPLAUSE))
    }

    @Test fun ambience_loopsWithoutAJump() {
        val d = CrowdSynth.render(Sfx.AMBIENCE)
        val n = d.size / 2
        assertEquals(12 * CrowdSynth.RATE, n)
        // the step from the last frame to the first frame is no bigger than normal sample-to-sample movement
        var maxStep = 0
        for (i in 1 until 2000) maxStep = maxOf(maxStep, abs(d[2 * i] - d[2 * (i - 1)]))
        val seam = abs(d[0] - d[2 * (n - 1)])
        assertTrue("seam $seam vs normal $maxStep", seam <= maxStep * 3 + 2000)
    }

    @Test fun player_mixesVoices_andFinishesOneShots() {
        val p = SfxPlayer()
        val dst = ShortArray(200)
        assertEquals(0, p.pullStereo(dst, 100))
        p.play(Sfx.CHEER, ShortArray(300) { 1000 }, 1f)
        p.play(Sfx.HORN, ShortArray(300) { 500 }, 1f)
        assertTrue(p.oneShotActive)
        assertEquals(100, p.pullStereo(dst, 100))
        assertEquals(1500, dst[0].toInt())
        assertEquals(100, p.pullStereo(dst, 100))
        assertFalse("both clips ended", p.oneShotActive)
        assertEquals(0, p.pullStereo(dst, 100))
    }

    @Test fun player_loopKeepsGoing_untilStopped() {
        val p = SfxPlayer()
        val dst = ShortArray(400)
        p.play(Sfx.AMBIENCE, ShortArray(50) { 200 }, 0.5f, loop = true)
        repeat(5) { assertEquals(200, p.pullStereo(dst, 200)) }
        assertEquals(100, dst[399].toInt())
        assertFalse(p.oneShotActive)
        p.stop(Sfx.AMBIENCE)
        assertEquals(0, p.pullStereo(dst, 200))
    }

    @Test fun resample_changesLength_andKeepsLevel() {
        val src = ShortArray(2 * 22050) { 1000 }
        val out = SfxDecoder.resampleStereo(src, 22050, 44100)
        assertEquals(2 * 44100, out.size)
        assertTrue(out.all { it.toInt() == 1000 })
        assertEquals(src, SfxDecoder.resampleStereo(src, 44100, 44100))
    }

    @Test fun normalize_scalesToTheTargetPeak_andLeavesSilenceAlone() {
        val out = SfxDecoder.normalize(shortArrayOf(1000, -2000, 500, 0), 0.5f)
        assertEquals(16383, out.maxOf { abs(it.toInt()) })
        val quiet = shortArrayOf(3, -2)
        assertEquals(quiet, SfxDecoder.normalize(quiet, 0.5f))
    }

    @Test fun settings_keepRealRecordingsAcrossSaving() {
        val s = AudioMixSettings(
            sfxFiles = listOf(SfxFile("CHEER", "/data/x.mp3", "Stadium cheer")),
            extraSfx = listOf(MusicTrack("/data/y.wav", "Siren"))
        )
        val back = com.zarvimo.cricket.data.Json.audioMixFromJson(com.zarvimo.cricket.data.Json.audioMixToJson(s))
        assertEquals(s.sfxFiles, back.sfxFiles)
        assertEquals(s.extraSfx, back.extraSfx)
    }

    @Test fun library_usesTheChosenFileKindOverTheGeneratedSound() {
        SfxLibrary.setFiles(mapOf("HORN" to "/nonexistent/horn.mp3"))
        assertTrue(SfxLibrary.hasFile(Sfx.HORN))
        // a file that cannot be decoded falls back to the generated sound instead of failing
        assertTrue(SfxLibrary.get(Sfx.HORN).isNotEmpty())
        SfxLibrary.setFiles(emptyMap())
        assertFalse(SfxLibrary.hasFile(Sfx.HORN))
    }
}
