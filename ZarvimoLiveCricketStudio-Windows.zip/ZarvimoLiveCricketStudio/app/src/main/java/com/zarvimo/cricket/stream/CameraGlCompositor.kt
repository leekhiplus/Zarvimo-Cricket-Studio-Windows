package com.zarvimo.cricket.stream

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Handler
import android.os.SystemClock
import android.util.Range
import android.util.Size
import android.view.Display
import android.view.Surface
import androidx.core.content.ContextCompat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max

/**
 * Camera mode of the compositor. Everything here runs on ONE thread (the frame-pump thread, whose [handler] also
 * receives the Camera2 callbacks):
 *
 *   Camera2 -> SurfaceTexture (OES texture) -> OpenGL draw (rotated + centre-cropped to the output)
 *   scoreboard overlay (drawn by BroadcastRenderer into a transparent Bitmap) -> texture -> blended on top
 *   -> EGL window surface = the Surface RootEncoder gave us (it feeds the encoder and the on-screen preview).
 *
 * Problems that happen after [start] (camera disconnected, permission revoked...) are reported through [onProblem];
 * the caller then falls back to the background-picture mode.
 */
class CameraGlCompositor(
    private val context: Context,
    private val handler: Handler,
    private val onProblem: (String) -> Unit
) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var progOes = 0
    private var prog2d = 0
    private var camTex = 0
    private var ovTex = 0
    private var camSt: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private val frameReady = AtomicBoolean(false)
    private var hasFrame = false

    private val texMatrix = FloatArray(16)
    private val mvp = FloatArray(16)
    private val identity = FloatArray(16)
    private val flipY = FloatArray(16)

    private var overlayBmp: Bitmap? = null
    private var overlayCanvas: Canvas? = null
    private var overlayUploaded = false

    // "bubble" mode: background picture as the base layer, camera only inside a circle
    private var pip = false
    @Volatile var bubble: BubbleConfig = BubbleConfig.OFF
    private var progCircle = 0
    private var baseTex = 0
    private var baseBmp: Bitmap? = null
    private var baseCanvas: Canvas? = null
    private var baseUploaded = false
    private var lastBaseKey: Any? = UNSET_KEY

    private var outW = 0
    private var outH = 0
    private var front = false
    private var fpsTarget = 24
    private var sensorOrientation = 90
    private var bufW = 1280
    private var bufH = 720
    private var useContinuousAf = false
    private var fpsRanges: Array<Range<Int>>? = null

    @Volatile var rotationOffset = 0
    private var rotation = 0
    private var lastRotationCheck = 0L

    @Volatile private var closed = false
    private var cameraDevice: CameraDevice? = null
    private var session: CameraCaptureSession? = null

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
        position(0)
    }

    /** Throws if OpenGL cannot be set up. The camera itself opens asynchronously (errors go to [onProblem]). */
    fun start(outputSurface: Surface, width: Int, height: Int, fps: Int, frontFacing: Boolean, bubbleMode: Boolean = false) {
        outW = width
        outH = height
        fpsTarget = fps
        front = frontFacing
        pip = bubbleMode

        initEgl(outputSurface)
        progOes = buildProgram(VERTEX, FRAGMENT_OES)
        prog2d = buildProgram(VERTEX, FRAGMENT_2D)
        if (pip) progCircle = buildProgram(VERTEX, FRAGMENT_OES_CIRCLE)

        val tex = IntArray(3)
        GLES20.glGenTextures(3, tex, 0)
        camTex = tex[0]
        ovTex = tex[1]
        baseTex = tex[2]
        configureTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
        configureTexture(GLES20.GL_TEXTURE_2D, ovTex)
        configureTexture(GLES20.GL_TEXTURE_2D, baseTex)

        val st = SurfaceTexture(camTex)
        st.setOnFrameAvailableListener({ frameReady.set(true) }, handler)
        camSt = st
        camSurface = Surface(st)

        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        overlayBmp = bmp
        overlayCanvas = Canvas(bmp)
        if (pip) {
            val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            baseBmp = b
            baseCanvas = Canvas(b)
        }

        Matrix.setIdentityM(identity, 0)
        Matrix.setIdentityM(flipY, 0)
        flipY[5] = -1f
        flipY[13] = 1f

        openCamera()
    }

    // ------------------------------------------------------------------------------------------ drawing

    /**
     * @param baseKey    identity of the background picture; the base layer is re-rendered only when it changes (bubble mode)
     * @param renderBase draws the background picture (bubble mode only)
     */
    fun drawFrame(baseKey: Any?, renderBase: ((Canvas) -> Unit)?, renderOverlay: (Canvas) -> Unit) {
        if (closed) return
        if (frameReady.getAndSet(false)) {
            try {
                camSt?.updateTexImage()
                camSt?.getTransformMatrix(texMatrix)
                hasFrame = true
            } catch (e: Exception) {
                // a bad frame is skipped
            }
        }
        val now = SystemClock.uptimeMillis()
        if (now - lastRotationCheck > 400) {
            rotation = computeRotation()
            lastRotationCheck = now
        }

        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        if (pip) {
            drawBase(baseKey, renderBase)
            if (hasFrame) drawBubble()
        } else if (hasFrame) {
            buildMvp()
            drawQuad(progOes, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex, mvp, texMatrix)
        }

        val bmp = overlayBmp
        val cv = overlayCanvas
        if (bmp != null && cv != null) {
            bmp.eraseColor(Color.TRANSPARENT)
            renderOverlay(cv)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ovTex)
            if (!overlayUploaded) {
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
                overlayUploaded = true
            } else {
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA) // bitmap pixels are premultiplied
            drawQuad(prog2d, GLES20.GL_TEXTURE_2D, ovTex, identity, flipY)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    private fun drawBase(baseKey: Any?, renderBase: ((Canvas) -> Unit)?) {
        val bmp = baseBmp
        val cv = baseCanvas
        if (bmp == null || cv == null || renderBase == null) return
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, baseTex)
        if (baseKey !== lastBaseKey || !baseUploaded) {
            bmp.eraseColor(Color.BLACK)
            renderBase(cv)
            if (!baseUploaded) {
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
                baseUploaded = true
            } else {
                GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
            }
            lastBaseKey = baseKey
        }
        drawQuad(prog2d, GLES20.GL_TEXTURE_2D, baseTex, identity, flipY)
    }

    /** Camera picture inside a circle with a white ring, centre-cropped from the rotated camera image. */
    private fun drawBubble() {
        val b = bubble
        val d = b.size * outH
        val rotated90 = rotation == 90 || rotation == 270
        val rw = if (rotated90) bufH.toFloat() else bufW.toFloat()
        val rh = if (rotated90) bufW.toFloat() else bufH.toFloat()
        val s = max(d / rw, d / rh)
        Matrix.setIdentityM(mvp, 0)
        Matrix.translateM(mvp, 0, b.x * 2f - 1f, 1f - b.y * 2f, 0f)
        Matrix.scaleM(mvp, 0, 2f / outW, 2f / outH, 1f)
        Matrix.scaleM(mvp, 0, s, s, 1f)
        Matrix.rotateM(mvp, 0, -rotation.toFloat(), 0f, 0f, 1f)
        Matrix.scaleM(mvp, 0, bufW / 2f, bufH / 2f, 1f)
        GLES20.glUseProgram(progCircle)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(progCircle, "uCenter"), b.x * outW, (1f - b.y) * outH)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(progCircle, "uRadius"), d / 2f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(progCircle, "uRing"), max(3f, d * 0.03f))
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        drawQuad(progCircle, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex, mvp, texMatrix)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    /** Rotates the camera image upright (by sensor + display orientation + user offset) and centre-crops it to fill the output. */
    private fun buildMvp() {
        val rotated90 = rotation == 90 || rotation == 270
        val rw = if (rotated90) bufH.toFloat() else bufW.toFloat()
        val rh = if (rotated90) bufW.toFloat() else bufH.toFloat()
        val s = max(outW / rw, outH / rh)
        Matrix.setIdentityM(mvp, 0)
        Matrix.scaleM(mvp, 0, 2f / outW, 2f / outH, 1f)
        Matrix.scaleM(mvp, 0, s, s, 1f)
        Matrix.rotateM(mvp, 0, -rotation.toFloat(), 0f, 0f, 1f)
        Matrix.scaleM(mvp, 0, bufW / 2f, bufH / 2f, 1f)
    }

    private fun drawQuad(prog: Int, target: Int, tex: Int, mvpM: FloatArray, texM: FloatArray) {
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(target, tex)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMvp"), 1, false, mvpM, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTex"), 1, false, texM, 0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "sTex"), 0)
        val pos = GLES20.glGetAttribLocation(prog, "aPos")
        val tc = GLES20.glGetAttribLocation(prog, "aTc")
        quad.position(0)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 16, quad)
        quad.position(2)
        GLES20.glEnableVertexAttribArray(tc)
        GLES20.glVertexAttribPointer(tc, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(pos)
        GLES20.glDisableVertexAttribArray(tc)
    }

    // ------------------------------------------------------------------------------------------ orientation

    private fun displayDegrees(): Int = try {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        when (dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation) {
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    private fun computeRotation(): Int {
        val d = displayDegrees()
        val base = if (front) (sensorOrientation + d) % 360 else (sensorOrientation - d + 360) % 360
        return (base + rotationOffset) % 360
    }

    // ------------------------------------------------------------------------------------------ camera

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            onProblem("Camera permission is not granted")
            return
        }
        try {
            val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val wanted = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
            var id: String? = null
            for (cid in mgr.cameraIdList) {
                val c = mgr.getCameraCharacteristics(cid)
                if (c.get(CameraCharacteristics.LENS_FACING) == wanted) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                onProblem(if (front) "This device has no front camera" else "This device has no back camera")
                return
            }
            val ch = mgr.getCameraCharacteristics(id)
            sensorOrientation = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            fpsRanges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val af = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            useContinuousAf = af != null && af.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val size = chooseSize(map?.getOutputSizes(SurfaceTexture::class.java))
            bufW = size.width
            bufH = size.height
            camSt?.setDefaultBufferSize(bufW, bufH)
            rotation = computeRotation()
            mgr.openCamera(id, stateCallback, handler)
        } catch (e: SecurityException) {
            onProblem("Camera permission was denied")
        } catch (e: Exception) {
            onProblem("Camera could not be opened")
        }
    }

    private fun chooseSize(sizes: Array<Size>?): Size {
        if (sizes == null || sizes.isEmpty()) return Size(1280, 720)
        val target = 16.0 / 9.0
        val wide = sizes.filter { abs(it.width.toDouble() / it.height - target) < 0.03 }
        val pool = if (wide.isNotEmpty()) wide else sizes.toList()
        val enough = pool.filter { it.width >= outW && it.height >= outH }
        val pick = if (enough.isNotEmpty()) {
            enough.minByOrNull { it.width.toLong() * it.height }
        } else {
            pool.maxByOrNull { it.width.toLong() * it.height }
        }
        return pick ?: Size(1280, 720)
    }

    private fun pickFpsRange(): Range<Int>? {
        val ranges = fpsRanges ?: return null
        var best: Range<Int>? = null
        for (r in ranges) {
            if (r.lower <= fpsTarget && r.upper >= fpsTarget) {
                val b = best
                if (b == null || (r.upper - r.lower) < (b.upper - b.lower)) best = r
            }
        }
        return best ?: ranges.maxByOrNull { it.upper }
    }

    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            if (closed) {
                camera.close()
                return
            }
            cameraDevice = camera
            startSession(camera)
        }

        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
            if (!closed) onProblem("The camera was disconnected")
        }

        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
            if (!closed) onProblem("Camera error ($error)")
        }
    }

    @Suppress("DEPRECATION")
    private fun startSession(camera: CameraDevice) {
        val surface = camSurface ?: return
        try {
            camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (closed) {
                        s.close()
                        return
                    }
                    session = s
                    try {
                        val b = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        b.addTarget(surface)
                        if (useContinuousAf) b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                        pickFpsRange()?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
                        s.setRepeatingRequest(b.build(), null, handler)
                    } catch (e: Exception) {
                        if (!closed) onProblem("The camera preview could not start")
                    }
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (!closed) onProblem("The camera session could not be configured")
                }
            }, handler)
        } catch (e: Exception) {
            if (!closed) onProblem("The camera session could not be created")
        }
    }

    // ------------------------------------------------------------------------------------------ EGL / GL setup

    private fun initEgl(outputSurface: Surface) {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) throw IllegalStateException("EGL: no display")
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) throw IllegalStateException("EGL: initialize failed")
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(eglDisplay, attribs, 0, configs, 0, 1, num, 0) || num[0] <= 0 || configs[0] == null) {
            throw IllegalStateException("EGL: no suitable config")
        }
        val config = configs[0]
        eglContext = EGL14.eglCreateContext(eglDisplay, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) throw IllegalStateException("EGL: context failed")
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, config, outputSurface, intArrayOf(EGL14.EGL_NONE), 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw IllegalStateException("EGL: window surface failed")
        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) throw IllegalStateException("EGL: makeCurrent failed")
    }

    private fun configureTexture(target: Int, tex: Int) {
        GLES20.glBindTexture(target, tex)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun buildProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertex)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragment)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val status = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            GLES20.glDeleteProgram(prog)
            throw IllegalStateException("GL: program link failed")
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, source)
        GLES20.glCompileShader(sh)
        val status = IntArray(1)
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            GLES20.glDeleteShader(sh)
            throw IllegalStateException("GL: shader compile failed")
        }
        return sh
    }

    // ------------------------------------------------------------------------------------------ teardown

    fun release() {
        closed = true
        try {
            session?.close()
        } catch (_: Exception) {
        }
        session = null
        try {
            cameraDevice?.close()
        } catch (_: Exception) {
        }
        cameraDevice = null
        try {
            camSurface?.release()
        } catch (_: Exception) {
        }
        camSurface = null
        try {
            camSt?.release()
        } catch (_: Exception) {
        }
        camSt = null
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            try {
                EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
                if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
                EGL14.eglTerminate(eglDisplay)
            } catch (_: Exception) {
            }
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
        overlayBmp?.recycle()
        overlayBmp = null
        overlayCanvas = null
        baseBmp?.recycle()
        baseBmp = null
        baseCanvas = null
    }

    private companion object {
        val UNSET_KEY = Any()
        const val VERTEX = """
            uniform mat4 uMvp;
            uniform mat4 uTex;
            attribute vec4 aPos;
            attribute vec4 aTc;
            varying vec2 vTc;
            void main() {
                gl_Position = uMvp * aPos;
                vTc = (uTex * aTc).xy;
            }
        """
        const val FRAGMENT_OES = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTc;
            uniform samplerExternalOES sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
        """
        const val FRAGMENT_OES_CIRCLE = """
            #extension GL_OES_EGL_image_external : require
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vTc;
            uniform samplerExternalOES sTex;
            uniform vec2 uCenter;
            uniform float uRadius;
            uniform float uRing;
            void main() {
                float r = distance(gl_FragCoord.xy, uCenter);
                float a = 1.0 - smoothstep(uRadius - 1.5, uRadius, r);
                if (a <= 0.0) discard;
                vec3 c = texture2D(sTex, vTc).rgb;
                float ringMix = smoothstep(uRadius - uRing - 1.0, uRadius - uRing, r);
                c = mix(c, vec3(1.0), ringMix);
                gl_FragColor = vec4(c * a, a);
            }
        """
        const val FRAGMENT_2D = """
            precision mediump float;
            varying vec2 vTc;
            uniform sampler2D sTex;
            void main() {
                gl_FragColor = texture2D(sTex, vTc);
            }
        """
    }
}
