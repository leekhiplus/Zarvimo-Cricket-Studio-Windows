package com.zarvimo.cricket.ui

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zarvimo.cricket.ZarvimoApp
import com.zarvimo.cricket.data.Json
import com.zarvimo.cricket.data.LocalStore
import com.zarvimo.cricket.data.MediaImporter
import com.zarvimo.cricket.data.SecretStore
import com.zarvimo.cricket.graphics.BurstInfo
import com.zarvimo.cricket.live.ChatMessage
import com.zarvimo.cricket.live.LiveChatController
import com.zarvimo.cricket.graphics.BurstKind
import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.OverlayBuilder
import com.zarvimo.cricket.graphics.OverlayData
import com.zarvimo.cricket.graphics.PanelBuilder
import com.zarvimo.cricket.graphics.PanelInfo
import com.zarvimo.cricket.graphics.AlertInfo
import com.zarvimo.cricket.graphics.AlertKind
import com.zarvimo.cricket.graphics.AlertTone
import com.zarvimo.cricket.graphics.DrsText
import com.zarvimo.cricket.graphics.PanelKind
import com.zarvimo.cricket.graphics.Performer
import com.zarvimo.cricket.scoring.DlsTable
import com.zarvimo.cricket.scoring.SquadParser
import com.zarvimo.cricket.scoring.AdjustmentEvent
import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.BatterInEvent
import com.zarvimo.cricket.scoring.EndInningsEvent
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.InningsState
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.OpResult
import com.zarvimo.cricket.scoring.PenaltyEvent
import com.zarvimo.cricket.scoring.ScoreEvent
import com.zarvimo.cricket.scoring.SetBowlerEvent
import com.zarvimo.cricket.scoring.SwapStrikeEvent
import com.zarvimo.cricket.stream.AudioMixSettings
import com.zarvimo.cricket.stream.Sfx
import com.zarvimo.cricket.stream.SfxFile
import com.zarvimo.cricket.stream.SfxLibrary
import com.zarvimo.cricket.stream.AutoShowSettings
import com.zarvimo.cricket.stream.CommentaryEvent
import com.zarvimo.cricket.stream.CommentaryLines
import com.zarvimo.cricket.stream.MusicTrack
import com.zarvimo.cricket.stream.StartResult
import com.zarvimo.cricket.stream.StreamService
import com.zarvimo.cricket.stream.StreamSettings
import com.zarvimo.cricket.stream.StreamState
import com.zarvimo.cricket.stream.VideoSourceMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

/** Immutable snapshot of the match for the UI. */
data class MatchUi(
    val setup: MatchSetup = MatchSetup(),
    val visuals: MatchVisuals = MatchVisuals(),
    val matchId: String = UUID.randomUUID().toString(),
    val inningsIndex: Int = -1,
    /** The match is tied after a finished pair of innings: a super over may be started. */
    val canSuperOver: Boolean = false,
    /** Result text of the finished match (null while in progress). */
    val finalResult: String? = null,
    val state: InningsState? = null,
    val events: List<ScoreEvent> = emptyList(),
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val firstInningsText: String? = null,
    val teamALogoPath: String? = null,
    val teamBLogoPath: String? = null,
    /** Transient message (rule violation, info). Cleared by the next successful action. */
    val message: String? = null
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = (app as ZarvimoApp).engine
    private val store = LocalStore(app)
    private var session: MatchSession? = null

    val streamStatus = engine.status
    val previewStatus = engine.preview
    val audioState = engine.audio
    val musicState = engine.musicState
    val micLevel = engine.micLevel
    val headset = engine.headset
    val videoMode = engine.videoMode

    private val _audioMix = MutableStateFlow(AudioMixSettings())
    val audioMix: StateFlow<AudioMixSettings> = _audioMix.asStateFlow()

    /** YouTube viewers / live chat / replies (needs the user's own Google sign-in). */
    val liveChat = LiveChatController(app, viewModelScope)
    val live = liveChat.state
    private var commentInfo: PanelInfo? = null

    private val _autoShow = MutableStateFlow(AutoShowSettings())
    val autoShow: StateFlow<AutoShowSettings> = _autoShow.asStateFlow()
    val recording = engine.recording
    val liveBitrateKbps = engine.liveBitrateKbps

    // on-air extras layered over the scoring overlay
    private var baseOverlay = OverlayData()
    private var currentPanel: PanelInfo? = null
    private var currentBurst: BurstInfo? = null
    private var panelKind: PanelKind? = null

    // ---- announcement banners (DRS, drinks break, rain delay...)
    private var currentAlert: AlertInfo? = null
    private var alertJob: Job? = null
    private val _alertOnAir = MutableStateFlow<String?>(null)
    /** Title of the banner currently on air (null = none). */
    val alertOnAir: StateFlow<String?> = _alertOnAir.asStateFlow()

    /** DRS reviews left for team A / team B. Reset with every new match. */
    private val _reviews = MutableStateFlow(Pair(2, 2))
    val reviews: StateFlow<Pair<Int, Int>> = _reviews.asStateFlow()
    private var panelShownAt = 0L
    private var panelJob: Job? = null
    private val _panelOnAir = MutableStateFlow<PanelKind?>(null)
    val panelOnAir: StateFlow<PanelKind?> = _panelOnAir.asStateFlow()

    private val _match = MutableStateFlow(MatchUi())
    val match: StateFlow<MatchUi> = _match.asStateFlow()

    private val _graphics = MutableStateFlow(GraphicsConfig())
    val graphics: StateFlow<GraphicsConfig> = _graphics.asStateFlow()

    private val _stream = MutableStateFlow(StreamSettings())
    val stream: StateFlow<StreamSettings> = _stream.asStateFlow()

    private val _rememberKey = MutableStateFlow(false)
    val rememberKey: StateFlow<Boolean> = _rememberKey.asStateFlow()

    private val _liveProblems = MutableStateFlow<List<String>>(emptyList())
    val liveProblems: StateFlow<List<String>> = _liveProblems.asStateFlow()

    private val _savedMatches = MutableStateFlow<List<Json.SavedMatch>>(emptyList())
    val savedMatches: StateFlow<List<Json.SavedMatch>> = _savedMatches.asStateFlow()

    private val _presets = MutableStateFlow<List<GraphicsConfig>>(emptyList())
    val presets: StateFlow<List<GraphicsConfig>> = _presets.asStateFlow()

    /** DLS resource table: the pasted official one when present, otherwise the built-in estimate. */
    private val _dlsTable = MutableStateFlow(DlsTable.approximate())
    val dlsTable: StateFlow<DlsTable> = _dlsTable.asStateFlow()

    private val _toast = MutableStateFlow<String?>(null)
    val toast: StateFlow<String?> = _toast.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            store.loadGraphics()?.let { _graphics.value = it }
            store.loadStreamSettings()?.let { _stream.value = it }
            val key = SecretStore.load(getApplication<Application>())
            if (key.isNotEmpty()) {
                _rememberKey.value = true
                _stream.update { it.copy(streamKey = key) }
            }
            store.loadAudioMix()?.let { _audioMix.value = it }
            engine.applyAudioMix(_audioMix.value)
            store.loadAutoShow()?.let { _autoShow.value = it }
            engine.applyAutoShow(_autoShow.value)
            val saved = _stream.value
            if (saved.bubbleEnabled) {
                if (engine.hasCameraPermission()) engine.setBubble(saved.bubble()) else _stream.update { it.copy(bubbleEnabled = false) }
            }
            if (saved.videoSource.isCamera) {
                if (engine.hasCameraPermission()) {
                    engine.setVideoSource(saved.videoSource, saved.cameraRotationOffset)
                } else {
                    _stream.update { it.copy(videoSource = VideoSourceMode.BACKGROUND) }
                }
            }
            store.loadDlsTableText()?.let { t -> DlsTable.parse(t).table?.let { _dlsTable.value = it } }
            store.loadAutosave()?.let { restore(it) }
            loadAllBitmaps()
            engine.broadcast.update(config = _graphics.value)
            refreshSaved()
            publish()
        }
    }

    init {
        // The engine may fall back to the background picture (camera unplugged / permission lost): keep the UI in step.
        viewModelScope.launch {
            engine.videoMode.collect { m ->
                if (_stream.value.videoSource != m) {
                    _stream.update { it.copy(videoSource = m) }
                    val s = _stream.value
                    launch(Dispatchers.IO) { store.saveStreamSettings(s) }
                }
            }
        }
        viewModelScope.launch {
            engine.bubbleEnabled.collect { on ->
                if (!on && _stream.value.bubbleEnabled) {
                    _stream.update { it.copy(bubbleEnabled = false) }
                    val s = _stream.value
                    launch(Dispatchers.IO) { store.saveStreamSettings(s) }
                }
            }
        }
        // When the stream goes live and the user is signed in to YouTube, connect viewers + chat automatically.
        viewModelScope.launch {
            engine.status.collect { st ->
                if (st.state == StreamState.STREAMING) {
                    if (live.value.signedIn && !liveChat.isPolling()) liveChat.connect(null)
                } else if (st.state == StreamState.IDLE) {
                    if (liveChat.isPolling()) liveChat.disconnect()
                }
            }
        }
        viewModelScope.launch {
            engine.notice.collect { n ->
                if (n != null) {
                    _toast.value = n
                    engine.consumeNotice()
                }
            }
        }
    }

    fun consumeToast() { _toast.value = null }
    fun reportMessage(text: String) { _toast.value = text }

    // ====================================================================== match / scoring

    fun newMatch(setup: MatchSetup, visuals: MatchVisuals) {
        val err = setup.validate()
        if (err != null) { _toast.value = err; return }
        session = MatchSession(setup)
        _match.value = MatchUi(setup = setup, visuals = visuals)
        _reviews.value = Pair(2, 2)
        publish()
    }

    fun updateSetup(setup: MatchSetup, visuals: MatchVisuals) {
        val err = setup.validate()
        if (err != null) { _toast.value = err; return }
        val s = session
        if (s == null || s.innings.isEmpty()) {
            session = MatchSession(setup)
            _match.update { it.copy(setup = setup, visuals = visuals) }
        } else {
            // Rules for an in-progress match are locked to avoid rewriting history; only labels/colours change.
            val locked = _match.value.setup.copy(title = setup.title, venue = setup.venue,
                momName = setup.momName, momTeam = setup.momTeam, momDetail = setup.momDetail,
                tossWinner = setup.tossWinner, tossDecision = setup.tossDecision, startTime = setup.startTime,
                squadA = setup.squadA, squadB = setup.squadB)
            _match.update { it.copy(setup = locked, visuals = visuals) }
            if (locked != setup) _toast.value = "Match already started: only title, venue and colours were updated"
        }
        publish()
    }

    /** Man of the match: name, team and one line of figures. Editable at any time; shows live on the card if it is on air. */
    fun setManOfMatch(name: String, team: String, detail: String) {
        _match.update { it.copy(setup = it.setup.copy(momName = name.trim(), momTeam = team.trim(), momDetail = detail.trim())) }
        publish()
    }

    /** The three best performances of the match (runs + 20 per wicket) to pick the man of the match from. */
    fun momSuggestions(): List<Performer> = session?.let { PanelBuilder.topPerformers(it) } ?: emptyList()

    /** Playing XI lists: allowed at any time (before or during the match); they never touch the scoring events. */
    fun setSquads(a: List<String>, b: List<String>) {
        _match.update { it.copy(setup = it.setup.copy(squadA = a.take(SquadParser.MAX_PLAYERS), squadB = b.take(SquadParser.MAX_PLAYERS))) }
        publish()
    }

    fun startInnings(setup: InningsSetup, targetOverride: Int? = null) {
        val s = session ?: run { _toast.value = "Create the match first"; return }
        handle(s.startInnings(setup, targetOverride))
    }

    fun addBall(runs: Int, boundary: Boolean = false) = addEvent { BallEvent(it, runsBat = runs, boundary = boundary) }
    fun addEvent(factory: (Long) -> ScoreEvent) {
        val s = session ?: return
        var createdId = -1L
        val r = s.add { id ->
            createdId = id
            factory(id)
        }
        handle(r)
        if (r is OpResult.Ok) onEventAdded(createdId)
    }

    /** Four / six / wicket just recorded: full-screen animation and spoken commentary (each can be switched off). */
    private fun onEventAdded(id: Long) {
        val s = session ?: return
        val st = s.currentState ?: return
        val ev = s.current?.events?.lastOrNull { it.id == id } as? BallEvent ?: return
        val kind = when {
            ev.wicket != null -> BurstKind.WICKET
            ev.runsBat == 6 -> BurstKind.SIX
            ev.runsBat == 4 -> BurstKind.FOUR
            else -> return
        }
        val rec = st.allBalls.lastOrNull { it.eventId == id }
        val auto = _autoShow.value
        val batter = if (kind == BurstKind.WICKET) st.lastDismissed?.name.orEmpty() else rec?.striker.orEmpty()
        val detail = if (kind == BurstKind.WICKET) {
            st.lastDismissed?.let { d -> d.name + (d.dismissal?.let { "  $it" } ?: "") }.orEmpty()
        } else {
            batter
        }
        if (auto.burstAnimations) {
            currentBurst = BurstInfo(kind, detail, SystemClock.uptimeMillis())
            pushOverlay()
        }
        if (auto.crowdSounds) {
            engine.playSfx(
                when (kind) {
                    BurstKind.FOUR -> Sfx.APPLAUSE
                    BurstKind.SIX -> Sfx.ROAR
                    BurstKind.WICKET -> Sfx.CHEER
                }
            )
        }
        val wanted = when (kind) {
            BurstKind.FOUR -> auto.onFour
            BurstKind.SIX -> auto.onSix
            BurstKind.WICKET -> auto.onWicket
        }
        if (auto.voiceEnabled && wanted) {
            val event = when (kind) {
                BurstKind.FOUR -> CommentaryEvent.FOUR
                BurstKind.SIX -> CommentaryEvent.SIX
                BurstKind.WICKET -> CommentaryEvent.WICKET
            }
            val type = ev.wicket?.type
            engine.speakCommentary(
                CommentaryLines.line(event, batter, rec?.bowler, type, urdu = false),
                CommentaryLines.line(event, batter, rec?.bowler, type, urdu = true),
                auto.voiceUrdu
            )
        }
    }

    fun setBowler(name: String) = addEvent { SetBowlerEvent(it, name) }
    fun batterIn(name: String) = addEvent { BatterInEvent(it, name) }
    fun swapStrike() = addEvent { SwapStrikeEvent(it) }
    fun penalty(runs: Int) = addEvent { PenaltyEvent(it, runs) }
    fun adjust(runs: Int, wickets: Int, note: String) = addEvent { AdjustmentEvent(it, runs, wickets, note.ifBlank { "Manual correction" }) }
    fun endInnings(reason: String) = addEvent { EndInningsEvent(it, reason) }

    fun undo() { session?.let { handle(it.undo()) } }
    fun redo() { session?.let { handle(it.redo()) } }

    fun replaceEvent(id: Long, factory: (Long) -> ScoreEvent) { session?.let { handle(it.replaceEvent(id, factory)) } }
    fun deleteEvent(id: Long) { session?.let { handle(it.deleteEvent(id)) } }
    /** Pastes the official DLS table. Returns an error text or null when it was accepted and saved. */
    fun loadDlsTable(text: String): String? {
        val p = DlsTable.parse(text)
        val t = p.table ?: return p.error ?: "The table could not be read"
        _dlsTable.value = t
        viewModelScope.launch(Dispatchers.IO) { store.saveDlsTableText(text) }
        return null
    }

    fun useEstimatedDlsTable() {
        _dlsTable.value = DlsTable.approximate()
        viewModelScope.launch(Dispatchers.IO) { store.clearDlsTable() }
    }

    /** Runs scored by the team that batted first in the match (innings 1), for the DLS calculator. */
    fun firstInningsRuns(): Int? = session?.stateOf(0)?.runs

    /**
     * Applies a DLS result: reduced overs for the interrupted innings and the revised target for the chase.
     * Only the first pair of innings (the match itself) can be adjusted this way.
     */
    fun applyDls(target: Int?, team1Overs: Int?, team2Overs: Int?) {
        val s = session ?: run { _toast.value = "Start the match first"; return }
        val idx = s.currentIndex
        if (idx < 0 || idx >= 2) { _toast.value = "DLS applies to the two innings of the match, not to a super over"; return }
        if (team1Overs != null) {
            val r = s.setOversOverride(0, team1Overs)
            if (r is OpResult.Error) { _toast.value = "Team 1 overs: ${r.message}"; return }
        }
        if (idx == 1) {
            if (team2Overs != null) {
                val r = s.setOversOverride(1, team2Overs)
                if (r is OpResult.Error) { _toast.value = "Team 2 overs: ${r.message}"; return }
            }
            if (target != null) {
                val r = s.setTargetOverride(1, target)
                if (r is OpResult.Error) { _toast.value = r.message; return }
            }
        }
        publish()
        if (idx == 1 && target != null) {
            val ov = team2Overs ?: s.stateOf(1)?.oversLimit
            showAlertText("DLS TARGET $target", if (ov != null) "IN $ov OVERS" else "", AlertTone.AMBER)
        }
    }

    fun setTarget(target: Int?) { session?.let { handle(it.setTargetOverride(it.currentIndex, target)) } }

    private fun handle(r: OpResult) {
        when (r) {
            is OpResult.Ok -> publish(null)
            is OpResult.Error -> publish(r.message)
        }
    }

    /** Rebuilds the UI snapshot and pushes the new overlay to the compositor (picked up by the very next frame). */
    private fun publish(message: String? = null) {
        val s = session
        val cur = _match.value
        val state = s?.currentState
        val first = if (s != null && s.innings.size >= 2) s.stateOf(0)?.let { "${it.battingTeam} ${it.scoreText} (${it.oversText})" } else null
        val next = cur.copy(
            inningsIndex = s?.currentIndex ?: -1,
            canSuperOver = s?.canStartSuperOver == true,
            finalResult = s?.finalResult(),
            state = state,
            events = s?.current?.events?.toList() ?: emptyList(),
            canUndo = s?.current?.events?.isNotEmpty() == true,
            canRedo = s?.current?.redoStack?.isNotEmpty() == true,
            firstInningsText = first,
            message = message
        )
        _match.value = next
        baseOverlay = OverlayBuilder.from(next.setup, s, next.visuals)
        // a panel on air (scorecard, graph...) follows the live score
        panelKind?.let { k ->
            val info = buildPanel(k)
            if (info != null) currentPanel = info.copy(shownAtMs = panelShownAt) else clearPanelState()
        }
        pushOverlay()
        autosave(next)
    }

    private fun pushOverlay() {
        engine.broadcast.update(overlay = baseOverlay.copy(panel = currentPanel, burst = currentBurst, alert = currentAlert))
    }

    // ====================================================================== on-air panels & automatic extras

    private fun buildPanel(kind: PanelKind): PanelInfo? {
        val cur = _match.value
        when (kind) {
            PanelKind.PLAYING_XI -> return PanelBuilder.playingXi(cur.setup, cur.visuals.teamAColor, cur.visuals.teamBColor)
            PanelKind.TOSS_CARD -> return PanelBuilder.toss(cur.setup, cur.visuals)
            PanelKind.MAN_OF_MATCH -> return PanelBuilder.manOfMatch(cur.setup, cur.visuals)
            PanelKind.MATCH_SUMMARY -> return session?.let { PanelBuilder.summary(cur.setup, it, cur.visuals) }
            PanelKind.RESULT_CARD -> return session?.let { PanelBuilder.result(cur.setup, it, cur.visuals) }
            else -> Unit
        }
        val st = session?.currentState ?: return null
        return when (kind) {
            PanelKind.SCORECARD -> PanelBuilder.scorecard(st)
            PanelKind.STRIKER, PanelKind.NON_STRIKER, PanelKind.BOWLER -> PanelBuilder.player(st, kind)
            PanelKind.PARTNERSHIP -> PanelBuilder.partnership(st)
            PanelKind.RUN_RATE -> PanelBuilder.runRate(st)
            PanelKind.COMMENT -> commentInfo
            else -> null
        }
    }

    private fun clearPanelState() {
        panelJob?.cancel()
        panelJob = null
        panelKind = null
        currentPanel = null
        _panelOnAir.value = null
    }

    /** Puts a panel on air; it hides itself after the configured number of seconds (tap again or Hide to remove it sooner). */
    fun showPanel(kind: PanelKind) {
        val info = buildPanel(kind)
        if (info == null) {
            _toast.value = kind.emptyHint
            return
        }
        panelJob?.cancel()
        panelKind = kind
        panelShownAt = SystemClock.uptimeMillis()
        currentPanel = info.copy(shownAtMs = panelShownAt)
        _panelOnAir.value = kind
        pushOverlay()
        val seconds = if (kind.fullScreen) maxOf(12, _autoShow.value.panelSeconds) else _autoShow.value.panelSeconds
        panelJob = viewModelScope.launch {
            delay(seconds * 1000L)
            hidePanel()
        }
    }

    private fun putAlert(info: AlertInfo) {
        alertJob?.cancel()
        val shown = info.copy(shownAtMs = SystemClock.uptimeMillis())
        currentAlert = shown
        _alertOnAir.value = shown.title
        pushOverlay()
        if (!shown.sticky) {
            val seconds = maxOf(6, _autoShow.value.panelSeconds)
            alertJob = viewModelScope.launch {
                delay(seconds * 1000L)
                hideAlert()
            }
        }
    }

    fun showAlert(kind: AlertKind) = putAlert(AlertInfo(kind.title, kind.sub, kind.tone.color, kind.sticky))

    fun showAlertText(title: String, sub: String, tone: AlertTone, sticky: Boolean = false) {
        if (title.isBlank()) return
        putAlert(AlertInfo(title.trim().uppercase(), sub.trim().uppercase(), tone.color, sticky))
    }

    /** "Review by <team>": the banner stays until the decision is announced. */
    fun showReview(teamIsA: Boolean) {
        val setup = _match.value.setup
        val left = if (teamIsA) _reviews.value.first else _reviews.value.second
        putAlert(DrsText.review(if (teamIsA) setup.teamA else setup.teamB, left))
    }

    /** The review failed: the team loses one (an umpire's call keeps it, so there is nothing to press). */
    fun reviewLost(teamIsA: Boolean) {
        _reviews.update { (a, b) -> if (teamIsA) Pair(maxOf(0, a - 1), b) else Pair(a, maxOf(0, b - 1)) }
    }

    fun setReviews(a: Int, b: Int) { _reviews.value = Pair(a.coerceIn(0, 9), b.coerceIn(0, 9)) }

    fun hideAlert() {
        alertJob?.cancel()
        alertJob = null
        currentAlert = null
        _alertOnAir.value = null
        pushOverlay()
    }

    /** Shows a viewer's comment on the broadcast (same auto-hide timer as the other panels). */
    fun showComment(m: ChatMessage) {
        commentInfo = PanelBuilder.comment(m.author, m.text, m.highlight)
        showPanel(PanelKind.COMMENT)
    }

    fun ytCredentials(): Pair<String, String> = liveChat.credentials()
    fun ytSaveCredentials(id: String, secret: String) = liveChat.saveCredentials(id, secret)
    fun ytSignIn() = liveChat.beginSignIn()
    fun ytSignOut() = liveChat.signOut()
    fun ytConnect(linkOrId: String) = liveChat.connect(linkOrId.ifBlank { null })
    fun ytDisconnect() = liveChat.disconnect()
    fun ytSend(text: String, replyTo: String?) = liveChat.send(text, replyTo)
    fun ytClearReplyStatus() = liveChat.clearReplyStatus()

    fun hidePanel() {
        clearPanelState()
        pushOverlay()
    }

    fun updateAutoShow(block: (AutoShowSettings) -> AutoShowSettings) {
        _autoShow.update { block(it).sanitized() }
        val a = _autoShow.value
        engine.applyAutoShow(a)
        viewModelScope.launch(Dispatchers.IO) { store.saveAutoShow(a) }
    }

    fun testVoice() {
        val a = _autoShow.value
        engine.applyAutoShow(a.copy(voiceEnabled = true))
        engine.speakCommentary("Test. FOUR! A beautiful shot from the batter.", "ٹیسٹ۔ چوکا! بہت شاندار شاٹ۔", a.voiceUrdu)
    }

    fun testBurst(kind: BurstKind) {
        currentBurst = BurstInfo(kind, "Preview", SystemClock.uptimeMillis())
        pushOverlay()
    }

    private fun autosave(m: MatchUi) {
        val s = session ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                store.saveAutosave(toSaved(m, s, "autosave"))
            } catch (_: Exception) {
            }
        }
    }

    private fun toSaved(m: MatchUi, s: MatchSession?, name: String) =
        Json.SavedMatch(m.matchId, name, System.currentTimeMillis(), m.setup, m.visuals, s, m.teamALogoPath, m.teamBLogoPath)

    private fun restore(saved: Json.SavedMatch) {
        session = saved.session ?: MatchSession(saved.setup)
        _match.value = MatchUi(
            setup = saved.setup, visuals = saved.visuals, matchId = saved.id.ifBlank { UUID.randomUUID().toString() },
            teamALogoPath = saved.teamALogoPath, teamBLogoPath = saved.teamBLogoPath
        )
    }

    fun resetMatch() {
        _reviews.value = Pair(2, 2)
        session = null
        _match.value = MatchUi(visuals = _match.value.visuals)
        engine.broadcast.assets.teamALogo = null
        engine.broadcast.assets.teamBLogo = null
        publish()
    }

    // ====================================================================== saved matches & presets

    fun saveMatchAs(name: String) {
        val m = _match.value
        val s = session
        viewModelScope.launch(Dispatchers.IO) {
            store.saveMatch(toSaved(m, s, name.ifBlank { "${m.setup.teamA} vs ${m.setup.teamB}" }))
            refreshSaved()
            _toast.value = "Match saved"
        }
    }

    fun loadMatch(saved: Json.SavedMatch) {
        restore(saved)
        viewModelScope.launch(Dispatchers.IO) {
            loadTeamLogos()
            publish()
        }
    }

    fun deleteMatch(id: String) {
        viewModelScope.launch(Dispatchers.IO) { store.deleteMatch(id); refreshSaved() }
    }

    fun savePreset(name: String) {
        val g = _graphics.value.copy(name = name.ifBlank { "Preset" })
        viewModelScope.launch(Dispatchers.IO) { store.savePreset(g); refreshSaved(); _toast.value = "Preset saved" }
    }

    fun applyPreset(g: GraphicsConfig) { setGraphics(g.sanitized()); viewModelScope.launch(Dispatchers.IO) { loadAllBitmaps() } }

    fun deletePreset(name: String) {
        viewModelScope.launch(Dispatchers.IO) { store.deletePreset(name); refreshSaved() }
    }

    private fun refreshSaved() {
        _savedMatches.value = store.listMatches()
        _presets.value = store.listPresets()
    }

    // ====================================================================== graphics

    fun setGraphics(g: GraphicsConfig) {
        val clean = g.sanitized()
        _graphics.value = clean
        engine.broadcast.update(config = clean) // visible in preview AND stream on the next frame
        viewModelScope.launch(Dispatchers.IO) {
            try { store.saveGraphics(clean) } catch (_: Exception) { }
        }
    }

    fun updateGraphics(block: (GraphicsConfig) -> GraphicsConfig) = setGraphics(block(_graphics.value))

    fun importMedia(uri: Uri, kind: MediaKind) {
        viewModelScope.launch(Dispatchers.IO) {
            val path = MediaImporter.importImage(getApplication<Application>(), uri, kind.name.lowercase())
            if (path == null) { _toast.value = "That file could not be read as an image"; return@launch }
            when (kind) {
                MediaKind.BACKGROUND -> { _graphics.update { it.copy(backgroundUri = path) }; engine.broadcast.assets.background = MediaImporter.load(path, 1920) }
                MediaKind.LOGO -> { _graphics.update { it.copy(logoUri = path) }; engine.broadcast.assets.logo = MediaImporter.load(path, 512) }
                MediaKind.SPONSOR -> { _graphics.update { it.copy(sponsorUri = path) }; engine.broadcast.assets.sponsor = MediaImporter.load(path, 512) }
                MediaKind.TEAM_A -> { _match.update { it.copy(teamALogoPath = path) }; engine.broadcast.assets.teamALogo = MediaImporter.load(path, 384) }
                MediaKind.TEAM_B -> { _match.update { it.copy(teamBLogoPath = path) }; engine.broadcast.assets.teamBLogo = MediaImporter.load(path, 384) }
            }
            setGraphics(_graphics.value)
        }
    }

    fun clearMedia(kind: MediaKind) {
        when (kind) {
            MediaKind.BACKGROUND -> { _graphics.update { it.copy(backgroundUri = null) }; engine.broadcast.assets.background = null }
            MediaKind.LOGO -> { _graphics.update { it.copy(logoUri = null) }; engine.broadcast.assets.logo = null }
            MediaKind.SPONSOR -> { _graphics.update { it.copy(sponsorUri = null) }; engine.broadcast.assets.sponsor = null }
            MediaKind.TEAM_A -> { _match.update { it.copy(teamALogoPath = null) }; engine.broadcast.assets.teamALogo = null }
            MediaKind.TEAM_B -> { _match.update { it.copy(teamBLogoPath = null) }; engine.broadcast.assets.teamBLogo = null }
        }
        setGraphics(_graphics.value)
    }

    private fun loadAllBitmaps() {
        val g = _graphics.value
        val a = engine.broadcast.assets
        a.background = MediaImporter.load(g.backgroundUri, 1920)
        a.logo = MediaImporter.load(g.logoUri, 512)
        a.sponsor = MediaImporter.load(g.sponsorUri, 512)
        loadTeamLogos()
    }

    private fun loadTeamLogos() {
        val m = _match.value
        engine.broadcast.assets.teamALogo = MediaImporter.load(m.teamALogoPath, 384)
        engine.broadcast.assets.teamBLogo = MediaImporter.load(m.teamBLogoPath, 384)
    }

    // ====================================================================== streaming

    fun updateStream(block: (StreamSettings) -> StreamSettings) {
        _stream.update(block)
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        if (!engine.isActive()) engine.reconfigurePreview(s.profile, s.fps)
    }

    // ====================================================================== video source (camera / background)

    fun hasCameraPermission(): Boolean = engine.hasCameraPermission()

    fun setVideoSource(mode: VideoSourceMode) {
        _stream.update { it.copy(videoSource = mode) }
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        engine.setVideoSource(mode, s.cameraRotationOffset)
    }

    /** Camera bubble (round camera picture over the background): any change is saved and applied live. */
    fun updateBubble(block: (StreamSettings) -> StreamSettings) {
        _stream.update(block)
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        engine.setBubble(s.bubble())
    }

    fun setCameraRotation(degrees: Int) {
        _stream.update { it.copy(cameraRotationOffset = degrees) }
        val s = _stream.value
        viewModelScope.launch(Dispatchers.IO) { store.saveStreamSettings(s) }
        engine.setVideoSource(s.videoSource, degrees)
    }

    // ====================================================================== background music & monitoring

    fun updateAudioMix(block: (AudioMixSettings) -> AudioMixSettings) {
        _audioMix.update { block(it).sanitized() }
        val a = _audioMix.value
        engine.applyAudioMix(a)
        viewModelScope.launch(Dispatchers.IO) { store.saveAudioMix(a) }
    }

    fun addMusic(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            var added = 0
            for (u in uris) {
                val imported = MediaImporter.importAudio(ctx, u) ?: continue
                updateAudioMix { a -> a.copy(tracks = a.tracks + MusicTrack(imported.first, imported.second)) }
                added++
            }
            _toast.value = if (added == uris.size) "Music added ($added)" else "$added of ${uris.size} files could be used; the rest are not audio files"
        }
    }

    fun removeMusic(track: MusicTrack) {
        updateAudioMix { a -> a.copy(tracks = a.tracks.filter { it.path != track.path }) }
        viewModelScope.launch(Dispatchers.IO) { runCatching { File(track.path).delete() } }
    }

    fun playSfx(kind: Sfx) = engine.playSfx(kind)
    fun playSfxFile(path: String) = engine.playSfxFile(path)

    /** Replaces a generated sound by a real recording. The file is checked by decoding it once. */
    fun setSfxFile(kind: Sfx, uri: Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val imported = MediaImporter.importAudio(ctx, uri)
            if (imported == null) { _toast.value = "That file is not an audio file"; return@launch }
            if (SfxLibrary.loadFile(imported.first) == null) {
                runCatching { File(imported.first).delete() }
                _toast.value = "This audio file could not be read. Try mp3 or wav."
                return@launch
            }
            val old = _audioMix.value.sfxFiles.firstOrNull { it.kind == kind.name }
            updateAudioMix { a -> a.copy(sfxFiles = a.sfxFiles.filter { it.kind != kind.name } + SfxFile(kind.name, imported.first, imported.second)) }
            old?.let { SfxLibrary.forget(it.path); runCatching { File(it.path).delete() } }
            _toast.value = "${kind.label}: your recording is now used"
        }
    }

    fun clearSfxFile(kind: Sfx) {
        val old = _audioMix.value.sfxFiles.firstOrNull { it.kind == kind.name } ?: return
        updateAudioMix { a -> a.copy(sfxFiles = a.sfxFiles.filter { it.kind != kind.name }) }
        SfxLibrary.forget(old.path)
        viewModelScope.launch(Dispatchers.IO) { runCatching { File(old.path).delete() } }
    }

    fun addExtraSfx(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            var added = 0
            for (u in uris) {
                val imported = MediaImporter.importAudio(ctx, u) ?: continue
                if (SfxLibrary.loadFile(imported.first) == null) { runCatching { File(imported.first).delete() }; continue }
                if (_audioMix.value.extraSfx.size >= 12) break
                updateAudioMix { a -> a.copy(extraSfx = a.extraSfx + MusicTrack(imported.first, imported.second)) }
                added++
            }
            _toast.value = if (added > 0) "$added sound pad(s) added" else "No usable audio file chosen"
        }
    }

    fun removeExtraSfx(t: MusicTrack) {
        updateAudioMix { a -> a.copy(extraSfx = a.extraSfx.filter { it.path != t.path }) }
        SfxLibrary.forget(t.path)
        viewModelScope.launch(Dispatchers.IO) { runCatching { File(t.path).delete() } }
    }
    fun stopSfx() = engine.stopSfx()
    fun musicPlay() = engine.musicPlay()
    fun musicPause() = engine.musicPause()
    fun musicNext() = engine.musicNext()

    fun setRememberKey(remember: Boolean) {
        _rememberKey.value = remember
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            if (remember) SecretStore.save(ctx, _stream.value.streamKey) else SecretStore.clear(ctx)
        }
    }

    /** Called by the UI when the user presses Start Live (after the mic permission has been granted). */
    fun startLive() {
        val s = _stream.value
        when (val r = engine.startStream(s)) {
            is StartResult.Rejected -> _liveProblems.value = r.reasons
            StartResult.Started -> {
                _liveProblems.value = emptyList()
                if (_rememberKey.value) {
                    val ctx = getApplication<Application>()
                    viewModelScope.launch(Dispatchers.IO) { SecretStore.save(ctx, s.streamKey) }
                }
                StreamService.start(getApplication<Application>())
            }
        }
    }

    fun stopLive() {
        engine.stopStream()
        StreamService.stop(getApplication<Application>())
    }

    fun setMuted(muted: Boolean) = engine.setUserMuted(muted)
    fun lowerBitrateNow() {
        val s = _stream.value
        val lowered = com.zarvimo.cricket.stream.BitrateAdvisor.reduced(s.videoBitrateKbps, s.profile)
        engine.setVideoBitrateOnFly(lowered)
        _stream.update { it.copy(videoBitrateKbps = lowered) }
    }

    fun elapsedSeconds(): Long? = engine.elapsedSeconds()
    fun hasMic(): Boolean = engine.hasMicPermission()
    fun engineRef() = engine

    fun clearLiveProblems() { _liveProblems.value = emptyList() }
}

enum class MediaKind { BACKGROUND, LOGO, SPONSOR, TEAM_A, TEAM_B }
