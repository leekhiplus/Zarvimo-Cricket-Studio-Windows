package com.zarvimo.cricket.scoring

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DlsEngineTest {

    /** Synthetic straight-line table (NOT official): resources = 2 x overs left, minus 10% per wicket lost. */
    private fun linearTable(): DlsTable {
        val sb = StringBuilder("Overs W0 W1 W2 W3 W4 W5 W6 W7 W8 W9\n")
        for (u in listOf(0, 10, 20, 30, 40, 50)) {
            sb.append(u)
            for (w in 0..9) sb.append(' ').append(2.0 * u * (1 - 0.1 * w))
            sb.append('\n')
        }
        val p = DlsTable.parse(sb.toString())
        assertNull(p.error)
        return p.table!!
    }

    @Test fun parse_acceptsHeader_interpolates_andMarksOfficial() {
        val t = linearTable()
        assertTrue(t.official)
        assertEquals(100.0, t.r(50.0, 0), 1e-9)
        assertEquals(50.0, t.r(25.0, 0), 1e-9)
        assertEquals(45.0, t.r(25.0, 1), 1e-9)
        assertEquals(0.0, t.r(30.0, 10), 1e-9)
    }

    @Test fun parse_rejectsBadInput() {
        assertNotNull(DlsTable.parse("50 100 90").error)
        assertNotNull(DlsTable.parse("40 90 80 70 60 50 40 30 20 10 5 1").error)
        assertNotNull(DlsTable.parse("").error)
    }

    @Test fun approximate_isMonotonic_andNotOfficial() {
        val t = DlsTable.approximate()
        assertFalse(t.official)
        assertEquals(100.0, t.r(50.0, 0), 1e-6)
        assertEquals(0.0, t.r(0.0, 0), 1e-6)
        assertTrue(t.r(40.0, 0) < t.r(50.0, 0))
        assertTrue(t.r(20.0, 3) < t.r(20.0, 2))
        assertEquals(56.6, t.r(20.0, 0), 1.0)
    }

    @Test fun resources_subtractWhatEveryStoppageTakesAway() {
        val t = linearTable()
        val inn = DlsInnings(50.0, listOf(DlsStoppage(30.0, 0, 20.0)))
        assertEquals(80.0, DlsCalc.resources(t, inn), 1e-9)
        assertEquals(100.0, DlsCalc.resources(t, DlsInnings(50.0)), 1e-9)
    }

    @Test fun target_whenTeam2HasLess_scalesTheScore() {
        val t = linearTable()
        val o = DlsCalc.target(t, 245, 200, DlsInnings(50.0), DlsInnings(40.0))!!
        assertEquals(100.0, o.r1, 1e-9)
        assertEquals(80.0, o.r2, 1e-9)
        assertEquals(160.0, o.par, 1e-9)
        assertEquals(161, o.target)
    }

    @Test fun target_whenTeam2HasMore_addsG50Share() {
        val t = linearTable()
        val o = DlsCalc.target(t, 245, 150, DlsInnings(40.0), DlsInnings(50.0))!!
        assertEquals(150 + 245 * 20 / 100.0, o.par, 1e-9)
        assertEquals(200, o.target)
    }

    @Test fun parNow_followsResourcesUsed() {
        val t = linearTable()
        // 200 set in a full match; chasing 50 overs; 30 overs left with 0 wickets lost => 40% of resources used
        val par = DlsCalc.parNow(t, 245, 200, DlsInnings(50.0), DlsInnings(50.0), 30.0, 0)!!
        assertEquals(200 * 40.0 / 100.0, par, 1e-9)
    }

    @Test fun parseOvers_understandsBalls() {
        assertEquals(12.5, DlsCalc.parseOvers("12.3", 6)!!, 1e-9)
        assertEquals(8.0, DlsCalc.parseOvers("8", 6)!!, 1e-9)
        assertNull(DlsCalc.parseOvers("12.7", 6))
        assertNull(DlsCalc.parseOvers("abc", 6))
    }
}
