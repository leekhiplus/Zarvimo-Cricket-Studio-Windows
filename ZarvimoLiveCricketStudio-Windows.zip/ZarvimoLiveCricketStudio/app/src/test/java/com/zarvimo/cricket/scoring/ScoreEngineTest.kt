package com.zarvimo.cricket.scoring

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScoreEngineTest {

    private val setup = InningsSetup("Lahore", "Karachi", "Bat1", "Bat2", "Bowl1")
    private var ids = 0L

    private fun cfg(overs: Int = 20, target: Int? = null, freeHit: Boolean = true) =
        InningsConfig(oversLimit = overs, target = target, enforceFreeHit = freeHit)

    private fun ball(
        runs: Int = 0,
        extra: ExtraType = ExtraType.NONE,
        extraRuns: Int = 0,
        nbType: ExtraType = ExtraType.NONE,
        boundary: Boolean = false,
        wicket: WicketInfo? = null
    ) = BallEvent(++ids, runs, extra, extraRuns, nbType, boundary, wicket)

    private fun play(vararg events: ScoreEvent, config: InningsConfig = cfg()): InningsState {
        val r = ScoreEngine.replay(config, setup, events.toList())
        assertTrue("Replay failed: $r", r is ReplayResult.Ok)
        return (r as ReplayResult.Ok).state
    }

    private fun fail(vararg events: ScoreEvent, config: InningsConfig = cfg()): ReplayResult.Failed {
        val r = ScoreEngine.replay(config, setup, events.toList())
        assertTrue("Expected failure but got $r", r is ReplayResult.Failed)
        return r as ReplayResult.Failed
    }

    private fun over(vararg balls: BallEvent) = balls.toList().toTypedArray()

    // ---------------------------------------------------------------- basic runs / legal balls

    @Test fun dotBall_countsLegalBall_noRuns() {
        val s = play(ball(0))
        assertEquals(0, s.runs)
        assertEquals(1, s.legalBalls)
        assertEquals("0.1", s.oversText)
        assertEquals(1, s.striker!!.balls)
    }

    @Test fun oddRuns_rotateStrike_evenRuns_doNot() {
        val s1 = play(ball(1))
        assertEquals("Bat2", s1.striker!!.name)
        val s2 = play(ball(2))
        assertEquals("Bat1", s2.striker!!.name)
        val s3 = play(ball(3))
        assertEquals("Bat2", s3.striker!!.name)
        assertEquals(3, s3.runs)
    }

    @Test fun boundaryFour_noRotation_countsFour() {
        val s = play(ball(4, boundary = true))
        assertEquals("Bat1", s.striker!!.name)
        assertEquals(4, s.striker!!.runs)
        assertEquals(1, s.striker!!.fours)
    }

    @Test fun fourRunByRunning_isNotABoundary_noRotationBecauseEven() {
        val s = play(ball(4, boundary = false))
        assertEquals(0, s.striker!!.fours)
        assertEquals("Bat1", s.striker!!.name)
    }

    @Test fun six_countsSix() {
        val s = play(ball(6, boundary = true))
        assertEquals(6, s.runs)
        assertEquals(1, s.striker!!.sixes)
    }

    @Test fun fiveRuns_rotatesStrike() {
        val s = play(ball(5))
        assertEquals("Bat2", s.striker!!.name)
        assertEquals(5, s.runs)
    }

    // ---------------------------------------------------------------- extras

    @Test fun wide_isNotLegal_batterNotFaced_bowlerCharged_noRotation() {
        val s = play(ball(extra = ExtraType.WIDE))
        assertEquals(1, s.runs)
        assertEquals(0, s.legalBalls)
        assertEquals(0, s.striker!!.balls)
        assertEquals(1, s.bowler!!.runs)
        assertEquals(1, s.extras.wides)
        assertEquals("Bat1", s.striker!!.name)
        assertEquals(1, s.bowler!!.wides)
    }

    @Test fun wideWithOneRun_totalTwo_rotates() {
        val s = play(ball(extra = ExtraType.WIDE, extraRuns = 1))
        assertEquals(2, s.runs)
        assertEquals(2, s.extras.wides)
        assertEquals("Bat2", s.striker!!.name)
        assertEquals(2, s.bowler!!.runs)
    }

    @Test fun wideBoundary_fiveRunsTotal_noRotation() {
        val s = play(ball(extra = ExtraType.WIDE, extraRuns = 4, boundary = true))
        assertEquals(5, s.runs)
        assertEquals("Bat1", s.striker!!.name)
    }

    @Test fun noBall_withBatRuns_batterFaced_notLegal_freeHitNext() {
        val s = play(ball(4, extra = ExtraType.NO_BALL, boundary = true))
        assertEquals(5, s.runs)
        assertEquals(0, s.legalBalls)
        assertEquals(1, s.striker!!.balls)
        assertEquals(4, s.striker!!.runs)
        assertEquals(5, s.bowler!!.runs)
        assertEquals(1, s.extras.noBalls)
        assertTrue(s.freeHit)
    }

    @Test fun noBall_withByes_byesNotChargedToBowler() {
        val s = play(ball(extra = ExtraType.NO_BALL, extraRuns = 2, nbType = ExtraType.BYE))
        assertEquals(3, s.runs)
        assertEquals(1, s.bowler!!.runs) // only the no-ball penalty
        assertEquals(2, s.extras.byes)
        assertEquals(1, s.extras.noBalls)
        assertEquals("Bat1", s.striker!!.name) // 2 runs run -> no rotation
    }

    @Test fun noBall_extraRunsWithoutType_rejected() {
        val f = fail(ball(extra = ExtraType.NO_BALL, extraRuns = 1))
        assertTrue(f.reason.contains("bye", ignoreCase = true))
    }

    @Test fun bye_isLegal_batterFaced_notChargedToBowler_rotatesOnOdd() {
        val s = play(ball(extra = ExtraType.BYE, extraRuns = 1))
        assertEquals(1, s.runs)
        assertEquals(1, s.legalBalls)
        assertEquals(0, s.bowler!!.runs)
        assertEquals(1, s.extras.byes)
        assertEquals(1, s.nonStriker!!.balls) // original striker now at non-striker end
        assertEquals("Bat2", s.striker!!.name)
    }

    @Test fun legBye_isLegal_notChargedToBowler() {
        val s = play(ball(extra = ExtraType.LEG_BYE, extraRuns = 2))
        assertEquals(2, s.extras.legByes)
        assertEquals(0, s.bowler!!.runs)
        assertEquals(1, s.legalBalls)
    }

    @Test fun byeWithoutRuns_rejected() {
        fail(ball(extra = ExtraType.BYE, extraRuns = 0))
    }

    @Test fun runsOffBatWithWide_rejected() {
        fail(ball(runs = 1, extra = ExtraType.WIDE))
    }

    @Test fun penaltyRuns_addedToExtras_noRotation() {
        val s = play(PenaltyEvent(++ids, 5))
        assertEquals(5, s.runs)
        assertEquals(5, s.extras.penalty)
        assertEquals("Bat1", s.striker!!.name)
    }

    // ---------------------------------------------------------------- overs

    @Test fun sixLegalBalls_completeOver_swapStrike_requireNewBowler() {
        val s = play(*over(ball(0), ball(0), ball(0), ball(0), ball(0), ball(0)))
        assertEquals("1.0", s.oversText)
        assertEquals("Bat2", s.striker!!.name) // end-of-over swap
        assertTrue(s.bowlerRequired)
        assertEquals(1, s.bowlers.first().maidens)
    }

    @Test fun widesAndNoBalls_doNotCompleteOver() {
        val s = play(
            ball(extra = ExtraType.WIDE), ball(extra = ExtraType.NO_BALL),
            ball(0), ball(0), ball(0), ball(0), ball(0)
        )
        assertEquals(5, s.legalBalls)
        assertEquals("0.5", s.oversText)
        assertFalse(s.bowlerRequired)
    }

    @Test fun overEnd_afterOddRunOnLastBall_strikeEndsWithOriginalStriker() {
        // last ball single: rotation (Bat2 on strike) then end-of-over swap -> Bat1 on strike
        val s = play(*over(ball(0), ball(0), ball(0), ball(0), ball(0), ball(1)))
        assertEquals("Bat1", s.striker!!.name)
    }

    @Test fun maiden_notAwarded_whenWideBowled() {
        val s = play(*over(ball(extra = ExtraType.WIDE), ball(0), ball(0), ball(0), ball(0), ball(0), ball(0)))
        assertEquals(0, s.bowlers.first().maidens)
    }

    @Test fun maiden_stillAwarded_withByesAndLegByes() {
        val s = play(*over(
            ball(extra = ExtraType.BYE, extraRuns = 1), ball(extra = ExtraType.LEG_BYE, extraRuns = 1),
            ball(0), ball(0), ball(0), ball(0)
        ))
        assertEquals(1, s.bowlers.first().maidens)
        assertEquals(2, s.runs)
    }

    @Test fun nextBall_withoutNewBowler_rejected() {
        val f = fail(*over(ball(0), ball(0), ball(0), ball(0), ball(0), ball(0), ball(0)))
        assertTrue(f.reason.contains("bowler", ignoreCase = true))
    }

    @Test fun sameBowlerConsecutiveOvers_rejected_butDifferentBowlerAllowed() {
        val six = over(ball(0), ball(0), ball(0), ball(0), ball(0), ball(0))
        fail(*six, SetBowlerEvent(++ids, "Bowl1"))
        val s = play(*six, SetBowlerEvent(++ids, "Bowl2"), ball(1))
        assertEquals("Bowl2", s.bowler!!.name)
        assertEquals(1, s.bowler!!.runs)
    }

    @Test fun bowlerFigures_oversMaidensRunsWickets() {
        val s = play(
            ball(1), ball(0), ball(0), ball(4, boundary = true),
            ball(wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Bat3")), ball(0)
        )
        assertEquals("1.0-0-5-1", s.bowlers.first().figuresText)
    }

    // ---------------------------------------------------------------- wickets

    @Test fun bowled_creditsBowler_fallOfWickets_pendingBatterBlocksNextBall() {
        val s = play(ball(wicket = WicketInfo(DismissalType.BOWLED)))
        assertEquals(1, s.wickets)
        assertEquals(1, s.bowler!!.wickets)
        assertEquals(StrikeEnd.STRIKER, s.pendingBatterEnd)
        assertNull(s.striker)
        assertEquals(1, s.fallOfWickets.size)
        assertEquals("Bat1", s.fallOfWickets[0].batter)
        assertEquals("Bat1", s.lastDismissed!!.name)
        assertEquals("b Bowl1", s.lastDismissed!!.dismissal)
        fail(ball(wicket = WicketInfo(DismissalType.BOWLED)), ball(0))
    }

    @Test fun incomingBatter_takesStrikerEnd() {
        val s = play(ball(wicket = WicketInfo(DismissalType.CAUGHT, fielder = "Fld")))
        val s2 = play(ball(wicket = WicketInfo(DismissalType.CAUGHT, fielder = "Fld")), BatterInEvent(++ids, "Bat3"))
        assertNotNull(s)
        assertEquals("Bat3", s2.striker!!.name)
        assertEquals("Bat2", s2.nonStriker!!.name)
        assertEquals("c Fld b Bowl1", s2.batters.first { it.name == "Bat1" }.dismissal)
    }

    @Test fun incomingBatter_inlineInWicketInfo() {
        val s = play(ball(wicket = WicketInfo(DismissalType.LBW, incomingBatter = "Bat3")))
        assertEquals("Bat3", s.striker!!.name)
        assertNull(s.pendingBatterEnd)
        assertEquals(3, s.batters.size)
    }

    @Test fun caughtAndBowler_text() {
        val s = play(ball(wicket = WicketInfo(DismissalType.CAUGHT, fielder = "Bowl1", incomingBatter = "Bat3")))
        assertEquals("c & b Bowl1", s.batters.first { it.name == "Bat1" }.dismissal)
    }

    @Test fun runOut_nonStriker_afterOneRun_incomingTakesCorrectEnd() {
        // 1 run completed => ends swapped: Bat2 at striker end, Bat1 at non-striker end.
        // Bat2 (non-striker by role) is run out => dismissed at STRIKER end => new batter becomes striker.
        val s = play(
            ball(1, wicket = WicketInfo(DismissalType.RUN_OUT, outBatterIsStriker = false, incomingBatter = "Bat3"))
        )
        assertEquals(1, s.runs)
        assertEquals(1, s.wickets)
        assertEquals(0, s.bowler!!.wickets) // run-out not credited to bowler
        assertEquals("Bat3", s.striker!!.name)
        assertEquals("Bat1", s.nonStriker!!.name)
    }

    @Test fun runOut_striker_noRuns_newBatterAtStrikerEnd() {
        val s = play(ball(0, wicket = WicketInfo(DismissalType.RUN_OUT, outBatterIsStriker = true, incomingBatter = "Bat3")))
        assertEquals("Bat3", s.striker!!.name)
        assertEquals("Bat2", s.nonStriker!!.name)
    }

    @Test fun caughtWithRuns_rejected() {
        fail(ball(1, wicket = WicketInfo(DismissalType.CAUGHT)))
    }

    @Test fun bowledNonStriker_rejected() {
        fail(ball(wicket = WicketInfo(DismissalType.BOWLED, outBatterIsStriker = false)))
    }

    @Test fun bowledOffNoBall_rejected_runOutAllowed() {
        fail(ball(extra = ExtraType.NO_BALL, wicket = WicketInfo(DismissalType.BOWLED)))
        val s = play(ball(extra = ExtraType.NO_BALL, wicket = WicketInfo(DismissalType.RUN_OUT, incomingBatter = "Bat3")))
        assertEquals(1, s.wickets)
        assertEquals(0, s.legalBalls)
    }

    @Test fun stumpedOffWide_allowed_bowledOffWide_rejected() {
        val s = play(ball(extra = ExtraType.WIDE, wicket = WicketInfo(DismissalType.STUMPED, fielder = "WK", incomingBatter = "Bat3")))
        assertEquals(1, s.wickets)
        assertEquals(1, s.runs)
        assertEquals(0, s.legalBalls)
        fail(ball(extra = ExtraType.WIDE, wicket = WicketInfo(DismissalType.BOWLED)))
    }

    @Test fun freeHit_blocksBowled_allowsRunOut_andCarriesOverWide() {
        fail(ball(extra = ExtraType.NO_BALL), ball(wicket = WicketInfo(DismissalType.BOWLED)))
        val s = play(ball(extra = ExtraType.NO_BALL), ball(extra = ExtraType.WIDE))
        assertTrue(s.freeHit) // wide does not use up the free hit
        val s2 = play(ball(extra = ExtraType.NO_BALL), ball(0))
        assertFalse(s2.freeHit)
        val s3 = play(ball(extra = ExtraType.NO_BALL), ball(wicket = WicketInfo(DismissalType.RUN_OUT, incomingBatter = "Bat3")))
        assertEquals(1, s3.wickets)
    }

    @Test fun freeHit_canBeDisabled() {
        val s = play(
            ball(extra = ExtraType.NO_BALL), ball(wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Bat3")),
            config = cfg(freeHit = false)
        )
        assertEquals(1, s.wickets)
    }

    @Test fun batterWhoAlreadyBatted_cannotComeInAgain() {
        fail(ball(wicket = WicketInfo(DismissalType.BOWLED)), BatterInEvent(++ids, "Bat2"))
    }

    @Test fun tenWickets_endsInnings_andRejectsFurtherBalls() {
        val events = mutableListOf<ScoreEvent>()
        for (i in 3..11) events += ball(wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Bat$i"))
        // 9 wickets so far; keep bowler legal across overs by changing bowler each 6 balls
        val withBowlers = mutableListOf<ScoreEvent>()
        var legal = 0
        var toggle = 2
        for (e in events) {
            withBowlers += e
            legal++
            if (legal % 6 == 0) withBowlers += SetBowlerEvent(++ids, "Bowl${toggle++ % 2 + 1}x")
        }
        withBowlers += ball(wicket = WicketInfo(DismissalType.LBW))
        val s = play(*withBowlers.toTypedArray())
        assertEquals(10, s.wickets)
        assertTrue(s.ended)
        assertEquals("All out", s.endReason)
        assertEquals(0, s.wicketsRemaining)
        assertEquals(10, s.fallOfWickets.size)
        fail(*withBowlers.toTypedArray(), ball(0))
    }

    // ---------------------------------------------------------------- innings end / target

    @Test fun oversLimit_endsInnings() {
        val c = cfg(overs = 1)
        val s = play(*over(ball(0), ball(0), ball(0), ball(0), ball(0), ball(0)), config = c)
        assertTrue(s.ended)
        assertEquals("Overs complete", s.endReason)
        fail(*over(ball(0), ball(0), ball(0), ball(0), ball(0), ball(0), ball(0)), config = c)
    }

    @Test fun chase_requiredRunsBallsRemainingAndRunRate() {
        val c = cfg(overs = 20, target = 150)
        val s = play(ball(4, boundary = true), ball(1), ball(0), config = c)
        assertEquals(5, s.runs)
        assertEquals(145, s.requiredRuns)
        assertEquals(117, s.ballsRemaining)
        assertEquals(145 * 6.0 / 117, s.requiredRunRate!!, 1e-9)
        assertEquals(5 * 6.0 / 3, s.runRate, 1e-9)
    }

    @Test fun chase_endsWhenTargetReached() {
        val c = cfg(overs = 20, target = 10)
        val s = play(ball(6, boundary = true), ball(4, boundary = true), config = c)
        assertTrue(s.ended)
        assertEquals("Target reached", s.endReason)
        assertEquals(0, s.requiredRuns)
    }

    @Test fun firstInnings_hasNoRequiredRate() {
        val s = play(ball(1))
        assertNull(s.requiredRuns)
        assertNull(s.requiredRunRate)
    }

    @Test fun manualEnd_declaresInnings() {
        val s = play(ball(1), EndInningsEvent(++ids, "Declared"))
        assertTrue(s.ended)
        assertEquals("Declared", s.endReason)
    }

    // ---------------------------------------------------------------- manual adjustment

    @Test fun manualAdjustment_reportedSeparately() {
        val s = play(ball(2), AdjustmentEvent(++ids, runs = 3, wickets = 0, note = "scorer correction"))
        assertEquals(5, s.runs)
        assertEquals(3, s.manualRunsAdjustment)
        assertEquals(2, s.striker!!.runs) // batter figures untouched
    }

    @Test fun manualAdjustment_cannotMakeScoreNegative() {
        fail(AdjustmentEvent(++ids, runs = -1, note = "bad"))
    }

    @Test fun manualSwapStrike_correctsEnds() {
        val s = play(SwapStrikeEvent(++ids))
        assertEquals("Bat2", s.striker!!.name)
    }

    // ---------------------------------------------------------------- batter stats

    @Test fun batterBalls_wideNotCounted_noBallCounted() {
        val s = play(ball(extra = ExtraType.WIDE), ball(extra = ExtraType.NO_BALL), ball(0))
        assertEquals(2, s.striker!!.balls)
    }

    @Test fun strikeRate() {
        val s = play(ball(2), ball(0))
        assertEquals(100.0, s.striker!!.strikeRate, 1e-9)
    }

    @Test fun recentBalls_labels() {
        val s = play(
            ball(0), ball(4, boundary = true), ball(extra = ExtraType.WIDE), ball(extra = ExtraType.NO_BALL, runs = 1),
            ball(extra = ExtraType.BYE, extraRuns = 2), ball(extra = ExtraType.LEG_BYE, extraRuns = 1),
            ball(wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Bat3"))
        )
        assertEquals(listOf("0", "4", "Wd", "Nb+1", "2b", "1lb", "W"), s.recentBalls.map { it.label })
    }

    @Test fun setupValidation() {
        assertNotNull(ScoreEngine.validateSetup(InningsSetup("A", "B", "x", "x", "y")))
        assertNotNull(ScoreEngine.validateSetup(InningsSetup("A", "B", "", "x", "y")))
        assertNotNull(ScoreEngine.validateSetup(InningsSetup("A", "B", "x", "y", " ")))
        assertNull(ScoreEngine.validateSetup(setup))
    }

    // ---------------------------------------------------------------- session: undo / redo / edit

    private fun session(overs: Int = 20): MatchSession {
        val s = MatchSession(MatchSetup(teamA = "Lahore", teamB = "Karachi", oversLimit = overs))
        val r = s.startInnings(setup)
        assertTrue(r is OpResult.Ok)
        return s
    }

    private fun MatchSession.ball(runs: Int = 0, boundary: Boolean = false) =
        add { id -> BallEvent(id, runsBat = runs, boundary = boundary) }

    @Test fun undo_removesLastEvent_andRedoRestoresIt() {
        val s = session()
        s.ball(1); s.ball(4, boundary = true)
        assertEquals(5, s.currentState!!.runs)
        val u = s.undo() as OpResult.Ok
        assertEquals(1, u.state.runs)
        assertEquals("Bat2", u.state.striker!!.name)
        val r = s.redo() as OpResult.Ok
        assertEquals(5, r.state.runs)
    }

    @Test fun newEvent_clearsRedoStack() {
        val s = session()
        s.ball(1); s.undo(); s.ball(2)
        assertTrue(s.redo() is OpResult.Error)
    }

    @Test fun undo_onEmptyInnings_isError() {
        assertTrue(session().undo() is OpResult.Error)
    }

    @Test fun undo_afterWicket_restoresBatter() {
        val s = session()
        s.add { id -> BallEvent(id, wicket = WicketInfo(DismissalType.BOWLED)) }
        assertEquals(1, s.currentState!!.wickets)
        val u = s.undo() as OpResult.Ok
        assertEquals(0, u.state.wickets)
        assertEquals("Bat1", u.state.striker!!.name)
        assertFalse(u.state.batters.first { it.name == "Bat1" }.out)
    }

    @Test fun editEarlierEvent_recomputesWholeScorecard() {
        val s = session()
        s.ball(1); s.ball(0); s.ball(0)
        val firstId = s.current!!.events.first().id
        val res = s.replaceEvent(firstId) { id -> BallEvent(id, runsBat = 2) } as OpResult.Ok
        assertEquals(2, res.state.runs)
        assertEquals("Bat1", res.state.striker!!.name) // 2 runs => no rotation any more
    }

    @Test fun invalidEdit_isRejected_andOriginalKept() {
        val s = session()
        s.ball(0) // id a
        s.add { id -> BallEvent(id, runsBat = 0, wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Bat3")) }
        val before = s.current!!.events.toList()
        // turn the first ball into a bowled wicket with the SAME incoming batter -> 2nd wicket event's batter already batted
        val firstId = before.first().id
        val res = s.replaceEvent(firstId) { id ->
            BallEvent(id, wicket = WicketInfo(DismissalType.BOWLED, incomingBatter = "Bat3"))
        }
        assertTrue(res is OpResult.Error)
        assertEquals(before, s.current!!.events.toList())
        assertEquals(1, s.currentState!!.wickets)
    }

    @Test fun deleteEvent_inMiddle_revalidates() {
        val s = session()
        s.ball(1); s.ball(2); s.ball(3)
        val midId = s.current!!.events[1].id
        val res = s.deleteEvent(midId) as OpResult.Ok
        assertEquals(4, res.state.runs)
        assertEquals(2, s.current!!.events.size)
    }

    @Test fun deleteSetBowler_thatLaterBallsDependOn_isRejected() {
        val s = session()
        repeat(6) { s.ball(0) }
        val bowlerChange = s.add { id -> SetBowlerEvent(id, "Bowl2") } as OpResult.Ok
        s.ball(1)
        val id = s.current!!.events.first { it is SetBowlerEvent }.id
        assertNotNull(bowlerChange)
        assertTrue(s.deleteEvent(id) is OpResult.Error)
        assertEquals(8, s.current!!.events.size)
    }

    @Test fun invalidAdd_isRejected_andNotStored() {
        val s = session()
        val res = s.add { id -> BallEvent(id, runsBat = 9) }
        assertTrue(res is OpResult.Error)
        assertTrue(s.current!!.events.isEmpty())
    }

    // ---------------------------------------------------------------- session: two innings & target

    @Test fun secondInnings_target_isFirstInningsPlusOne_andCanBeOverridden() {
        val s = session(overs = 1)
        repeat(6) { s.ball(4, boundary = true) } // 24 runs, innings ends (1 over)
        assertTrue(s.currentState!!.ended)
        val second = InningsSetup("Karachi", "Lahore", "K1", "K2", "L1")
        assertTrue(s.startInnings(second) is OpResult.Ok)
        assertEquals(25, s.targetFor(1))
        val st = s.currentState!!
        assertEquals(25, st.target)
        assertEquals(25, st.requiredRuns)
        assertEquals(6, st.ballsRemaining)

        assertTrue(s.setTargetOverride(1, 18) is OpResult.Ok) // e.g. a manual DLS-style target
        assertEquals(18, s.currentState!!.target)
    }

    @Test fun secondInnings_cannotStart_beforeFirstEnds() {
        val s = session()
        s.ball(1)
        assertTrue(s.startInnings(InningsSetup("Karachi", "Lahore", "K1", "K2", "L1")) is OpResult.Error)
    }

    @Test fun secondInnings_chaseCompletes_whenTargetReached() {
        val s = session(overs = 1)
        repeat(6) { s.ball(1) } // 6 runs -> target 7
        s.startInnings(InningsSetup("Karachi", "Lahore", "K1", "K2", "L1"))
        s.ball(6, boundary = true)
        assertFalse(s.currentState!!.ended)
        s.ball(1)
        val st = s.currentState!!
        assertTrue(st.ended)
        assertEquals("Target reached", st.endReason)
    }

    @Test fun matchSetupValidation() {
        assertNull(MatchSetup().validate())
        assertNotNull(MatchSetup(teamA = "", teamB = "B").validate())
        assertNotNull(MatchSetup(teamA = "A", teamB = "a").validate())
        assertNotNull(MatchSetup(oversLimit = 0).validate())
        assertEquals(10, MatchSetup(playersPerSide = 11).maxWickets)
    }
}
