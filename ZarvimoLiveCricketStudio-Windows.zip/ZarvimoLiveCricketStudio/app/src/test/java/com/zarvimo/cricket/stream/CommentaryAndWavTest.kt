package com.zarvimo.cricket.stream

import com.zarvimo.cricket.scoring.DismissalType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.random.Random

class CommentaryAndWavTest {

    @Test
    fun boundaryLinesNameTheBatter() {
        val four = CommentaryLines.line(CommentaryEvent.FOUR, "Babar", null, null, urdu = false, random = Random(1))
        val six = CommentaryLines.line(CommentaryEvent.SIX, "Rizwan", null, null, urdu = false, random = Random(2))
        assertTrue(four.contains("Babar"))
        assertTrue(six.contains("Rizwan"))
    }

    @Test
    fun wicketLineMentionsDismissalAndBowler() {
        val l = CommentaryLines.line(CommentaryEvent.WICKET, "Rizwan", "Shaheen", DismissalType.BOWLED, urdu = false)
        assertTrue(l.contains("Rizwan"))
        assertTrue(l.contains("bowled"))
        assertTrue(l.contains("Shaheen"))
    }

    @Test
    fun runOutDoesNotCreditTheBowler() {
        val l = CommentaryLines.line(CommentaryEvent.WICKET, "Rizwan", "Shaheen", DismissalType.RUN_OUT, urdu = false)
        assertTrue(l.contains("run out"))
        assertFalse(l.contains("Shaheen"))
    }

    private fun wav(rate: Int, samples: Int): ByteArray {
        val data = ShortArray(samples) { (it * 100).toShort() }
        val bb = ByteBuffer.allocate(44 + samples * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + samples * 2).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(samples * 2)
        data.forEach { bb.putShort(it) }
        return bb.array()
    }

    @Test
    fun wavIsConvertedToStereo44k() {
        val out = WavDecoder.toStereo44k(wav(22050, 100))
        assertNotNull(out)
        assertEquals(2 * 200, out!!.size) // 100 frames at 22.05 kHz -> 200 frames at 44.1 kHz, 2 channels
    }

    @Test
    fun garbageIsRejected() {
        assertNull(WavDecoder.toStereo44k(ByteArray(10)))
        assertNull(WavDecoder.toStereo44k(ByteArray(64)))
    }
}
