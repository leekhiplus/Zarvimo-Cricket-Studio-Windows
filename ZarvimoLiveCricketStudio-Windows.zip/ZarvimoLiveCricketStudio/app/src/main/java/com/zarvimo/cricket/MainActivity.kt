package com.zarvimo.cricket

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zarvimo.cricket.stream.StreamState
import com.zarvimo.cricket.ui.AppIcon
import com.zarvimo.cricket.ui.AppViewModel
import com.zarvimo.cricket.ui.Ic
import com.zarvimo.cricket.ui.Muted
import com.zarvimo.cricket.ui.GraphicsScreen
import com.zarvimo.cricket.ui.HomeScreen
import com.zarvimo.cricket.ui.Ink
import com.zarvimo.cricket.ui.Gold
import com.zarvimo.cricket.ui.Panel
import com.zarvimo.cricket.ui.StudioScreen
import com.zarvimo.cricket.ui.StudioTab
import com.zarvimo.cricket.ui.SavedScreen
import com.zarvimo.cricket.ui.ScoringScreen
import com.zarvimo.cricket.ui.SetupScreen
import com.zarvimo.cricket.ui.SettingsScreen
import com.zarvimo.cricket.ui.StreamConfigScreen
import com.zarvimo.cricket.ui.ZarvimoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ZarvimoTheme { AppRoot() } }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Free encoder / GL resources when the user really leaves and nothing is being streamed.
        val engine = (application as ZarvimoApp).engine
        if (isFinishing && !engine.isActive()) engine.release()
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Ic.Home), Tab("score", "Score", Ic.Cricket), Tab("preview", "Studio", Ic.Film),
    Tab("graphics", "Graphics", Ic.Layers), Tab("stream", "Stream", Ic.Radio)
)

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    val ss by vm.streamStatus.collectAsState()
    val toast by vm.toast.collectAsState()
    var showRationale by remember { mutableStateOf(false) }

    // Keep the screen awake while a stream session is active so the operator can keep scoring.
    val view = LocalView.current
    val active = ss.state != StreamState.IDLE && ss.state != StreamState.ERROR
    DisposableEffect(active) {
        view.keepScreenOn = active
        onDispose { view.keepScreenOn = false }
    }

    LaunchedEffect(toast) {
        toast?.let { snack.showSnackbar(it); vm.consumeToast() }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        // Notifications are optional (the foreground service still runs); the microphone is mandatory.
        if (vm.hasMic()) vm.startLive()
        else vm.reportMessage("Microphone permission denied: live audio cannot be transmitted. You can grant it in system settings.")
    }

    val onStartLive: () -> Unit = {
        if (vm.hasMic()) vm.startLive() else showRationale = true
    }

    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    Scaffold(
        containerColor = Ink,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Panel, tonalElevation = 0.dp) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = current == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { AppIcon(t.icon, size = 24.dp) },
                        label = { Text(t.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold,
                            unselectedIconColor = Muted, unselectedTextColor = Muted,
                            indicatorColor = Color(0x26FFC107)
                        )
                    )
                }
            }
        }
    ) { inner ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(inner)) {
            composable("home") { HomeScreen(vm, { nav.navigate(it) }, onStartLive) }
            composable("setup") { SetupScreen(vm) { nav.navigate(it) } }
            composable("score") { ScoringScreen(vm) { nav.navigate(it) } }
            composable("preview") { StudioScreen(vm, onStartLive, { nav.navigate(it) }, StudioTab.SOURCE) }
            composable("chat") { StudioScreen(vm, onStartLive, { nav.navigate(it) }, StudioTab.CHAT) }
            composable("graphics") { GraphicsScreen(vm) }
            composable("stream") { StreamConfigScreen(vm, onStartLive) }
            composable("monitor") { StudioScreen(vm, onStartLive, { nav.navigate(it) }, StudioTab.STATUS) }
            composable("saved") { SavedScreen(vm) { nav.navigate(it) } }
            composable("settings") { SettingsScreen(vm) }
        }
    }

    if (showRationale) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Microphone access") },
            text = {
                Text(
                    "Zarvimo needs the microphone to capture your live commentary. Audio is captured and sent only between " +
                        "“Go Live” and “Stop Live”, and you can mute it at any time. Notification permission (Android 13+) lets the " +
                        "app show the “Stop Live” control while streaming in the background."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showRationale = false
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                    permissionLauncher.launch(perms.toTypedArray())
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Not now") } }
        )
    }
}
