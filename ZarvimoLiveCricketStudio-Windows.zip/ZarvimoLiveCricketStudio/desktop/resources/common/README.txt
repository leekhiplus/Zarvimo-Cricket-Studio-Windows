ffmpeg.exe is downloaded here by the GitHub workflow (build-windows.yml) and bundled into the app.
