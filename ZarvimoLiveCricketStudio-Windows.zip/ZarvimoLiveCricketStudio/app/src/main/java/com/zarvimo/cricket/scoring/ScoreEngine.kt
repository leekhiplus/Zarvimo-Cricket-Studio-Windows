package com.zarvimo.cricket.scoring

/**
 * Stateless entry point: the innings state is ALWAYS derived by replaying the event list.
 * This guarantees undo / redo / edit can never leave the scorecard inconsistent.
 */
object ScoreEngine {

    fun replay(config: InningsConfig, setup: InningsSetup, events: List<ScoreEvent>): ReplayResult {
        val problem = validateSetup(setup) ?: seedProblem(config, setup)
        if (problem != null) return ReplayResult.Failed(-1, -1, problem)
        val builder = InningsBuilder(config, setup)
        events.forEachIndexed { index, event ->
            val error = builder.apply(event)
            if (error != null) return ReplayResult.Failed(index, event.id, error)
        }
        return ReplayResult.Ok(builder.snapshot())
    }

    fun validateSetup(setup: InningsSetup): String? {
        val s = setup.striker.trim()
        val n = setup.nonStriker.trim()
        if (s.isEmpty() || n.isEmpty()) return "Both opening batters are required"
        if (s.equals(n, ignoreCase = true)) return "Striker and non-striker must be different players"
        if (setup.bowler.trim().isEmpty()) return "Opening bowler is required"
        return null
    }

    /** Checks the "join in the middle" seed; null when there is none or it is consistent. */
    fun seedProblem(config: InningsConfig, setup: InningsSetup): String? {
        val sd = setup.seed ?: return null
        val bpo = config.ballsPerOver
        if (sd.runs < 0) return "The team score cannot be negative"
        if (sd.wickets !in 0..config.maxWickets) return "Wickets must be between 0 and ${config.maxWickets}"
        if (sd.legalBalls !in 1..config.maxBalls) return "Overs completed must be between 0.1 and ${config.oversLimit}.0"
        val extras = sd.wides + sd.noBalls + sd.byes + sd.legByes + sd.penalty
        val numbers = listOf(
            sd.wides, sd.noBalls, sd.byes, sd.legByes, sd.penalty, sd.strikerRuns, sd.strikerBalls, sd.strikerFours, sd.strikerSixes,
            sd.nonStrikerRuns, sd.nonStrikerBalls, sd.nonStrikerFours, sd.nonStrikerSixes, sd.bowlerLegalBalls, sd.bowlerMaidens,
            sd.bowlerRuns, sd.bowlerWickets, sd.currentOverRuns
        )
        if (numbers.any { it < 0 }) return "Numbers cannot be negative"
        if (sd.outBatters.size > sd.wickets) return "More dismissed batters are listed than wickets have fallen"
        val s = setup.striker.trim()
        val n = setup.nonStriker.trim()
        val names = (sd.outBatters.map { it.name.trim() } + s + n)
        if (names.any { it.isEmpty() }) return "Every listed batter needs a name"
        if (names.map { it.lowercase() }.toSet().size != names.size) return "A batter name is used twice"
        if (sd.outBatters.any { it.runs < 0 || it.balls < 0 || it.fours < 0 || it.sixes < 0 }) return "Numbers cannot be negative"
        val batterRuns = sd.strikerRuns + sd.nonStrikerRuns + sd.outBatters.sumOf { it.runs }
        if (batterRuns + extras > sd.runs) return "The batters' runs plus extras ($batterRuns + $extras) are more than the team score (${sd.runs})"
        if (extras > sd.runs) return "Extras are more than the team score"
        val current = setup.bowler.trim()
        val bowlerNames = sd.otherBowlers.map { it.name.trim() } + current
        if (bowlerNames.any { it.isEmpty() }) return "Every listed bowler needs a name"
        if (bowlerNames.map { it.lowercase() }.toSet().size != bowlerNames.size) return "A bowler name is used twice"
        if (sd.otherBowlers.any { it.legalBalls < 0 || it.maidens < 0 || it.runs < 0 || it.wickets < 0 }) return "Numbers cannot be negative"
        val bowledBalls = sd.bowlerLegalBalls + sd.otherBowlers.sumOf { it.legalBalls }
        if (bowledBalls > sd.legalBalls) return "The bowlers' overs ($bowledBalls balls) are more than the overs completed (${sd.legalBalls} balls)"
        val inOver = sd.legalBalls % bpo
        if (inOver > 0 && sd.bowlerLegalBalls < inOver) return "The current bowler must have bowled at least the ${inOver} ball(s) of the over in progress"
        val maxPerBowler = config.maxOversPerBowler
        if (maxPerBowler != null) {
            val over = (sd.otherBowlers.map { it.name to it.legalBalls } + (current to sd.bowlerLegalBalls)).firstOrNull { it.second > maxPerBowler * bpo }
            if (over != null) return "${over.first} has bowled more than the maximum $maxPerBowler overs"
        }
        val pr = sd.partnershipRuns
        val pb = sd.partnershipBalls
        if ((pr != null && (pr < 0 || pr > sd.runs)) || (pb != null && (pb < 0 || pb > sd.legalBalls))) return "The partnership is larger than the innings"
        if (sd.overRuns.any { it < 0 }) return "Runs per over cannot be negative"
        return null
    }

    fun ballLabel(e: BallEvent): String {
        val w = e.wicket != null
        return when (e.extra) {
            ExtraType.NONE -> when {
                w && e.runsBat > 0 -> "${e.runsBat}W"
                w -> "W"
                else -> e.runsBat.toString()
            }
            ExtraType.WIDE -> "Wd" + (if (e.extraRuns > 0) "+${e.extraRuns}" else "") + (if (w) "+W" else "")
            ExtraType.NO_BALL -> {
                var s = "Nb"
                if (e.runsBat > 0) s += "+${e.runsBat}"
                if (e.extraRuns > 0) s += "+${e.extraRuns}" + (if (e.noBallRunType == ExtraType.LEG_BYE) "lb" else "b")
                if (w) s += "+W"
                s
            }
            ExtraType.BYE -> "${e.extraRuns}b" + (if (w) "+W" else "")
            ExtraType.LEG_BYE -> "${e.extraRuns}lb" + (if (w) "+W" else "")
        }
    }
}

internal class InningsBuilder(private val config: InningsConfig, private val setup: InningsSetup) {

    private class MBatter(val name: String, val order: Int) {
        var runs = 0
        var balls = 0
        var fours = 0
        var sixes = 0
        var out = false
        var dismissal: String? = null
        fun snap() = BatterStat(name, order, runs, balls, fours, sixes, out, dismissal)
    }

    private class MBowler(val name: String) {
        var legalBalls = 0
        var maidens = 0
        var runs = 0
        var wickets = 0
        var wides = 0
        var noBalls = 0
    }

    private var runs = 0
    private var wickets = 0
    private var legalBalls = 0
    private var wides = 0
    private var noBalls = 0
    private var byes = 0
    private var legByes = 0
    private var penalty = 0
    private var manualRuns = 0
    private var manualWickets = 0

    private val batters = LinkedHashMap<String, MBatter>()
    private val bowlers = LinkedHashMap<String, MBowler>()
    private var striker: String? = null
    private var nonStriker: String? = null
    private var bowler: String? = null
    private var pendingEnd: StrikeEnd? = null
    private var freeHit = false
    private var ended = false
    private var endReason: String? = null

    private var currentOverLegal = 0
    private var overIndex = 0
    private var overRunsCharged = 0
    private var overMaidenVoid = false
    private var lastOverBowler: String? = null

    private val allBalls = ArrayList<BallRecord>()
    private val fow = ArrayList<FallOfWicket>()
    private var lastDismissed: String? = null

    // innings joined in the middle (see InningsSeed)
    private var seedOvers = 0
    private var seedOverRuns: List<Int> = emptyList()
    private var partnershipStartRuns: Int? = null
    private var partnershipStartBalls: Int? = null

    init {
        val s = setup.striker.trim()
        val n = setup.nonStriker.trim()
        val sd = setup.seed
        if (sd == null) {
            batters[s] = MBatter(s, 1)
            batters[n] = MBatter(n, 2)
            striker = s
            nonStriker = n
            bowler = setup.bowler.trim()
            bowlers.getOrPut(bowler!!) { MBowler(bowler!!) }
        } else {
            applySeed(sd, s, n)
        }
    }

    private fun applySeed(sd: InningsSeed, s: String, n: String) {
        var order = 1
        for (ob in sd.outBatters) {
            val name = ob.name.trim()
            val b = MBatter(name, order++)
            b.runs = ob.runs
            b.balls = ob.balls
            b.fours = ob.fours
            b.sixes = ob.sixes
            b.out = true
            b.dismissal = ob.dismissal.ifBlank { "out" }
            batters[name] = b
            lastDismissed = name
        }
        val sb = MBatter(s, order++)
        sb.runs = sd.strikerRuns
        sb.balls = sd.strikerBalls
        sb.fours = sd.strikerFours
        sb.sixes = sd.strikerSixes
        batters[s] = sb
        val nb = MBatter(n, order)
        nb.runs = sd.nonStrikerRuns
        nb.balls = sd.nonStrikerBalls
        nb.fours = sd.nonStrikerFours
        nb.sixes = sd.nonStrikerSixes
        batters[n] = nb
        striker = s
        nonStriker = n

        runs = sd.runs
        wickets = sd.wickets
        legalBalls = sd.legalBalls
        wides = sd.wides
        noBalls = sd.noBalls
        byes = sd.byes
        legByes = sd.legByes
        penalty = sd.penalty

        for (ob in sd.otherBowlers) {
            val name = ob.name.trim()
            val b = MBowler(name)
            b.legalBalls = ob.legalBalls
            b.maidens = ob.maidens
            b.runs = ob.runs
            b.wickets = ob.wickets
            bowlers[name] = b
        }
        val cur = setup.bowler.trim()
        val cb = MBowler(cur)
        cb.legalBalls = sd.bowlerLegalBalls
        cb.maidens = sd.bowlerMaidens
        cb.runs = sd.bowlerRuns
        cb.wickets = sd.bowlerWickets
        bowlers[cur] = cb

        val bpo = config.ballsPerOver
        overIndex = sd.legalBalls / bpo
        currentOverLegal = sd.legalBalls % bpo
        if (currentOverLegal == 0) {
            // the over just ended: the same bowler may not start the next one, the scorer picks the next bowler
            lastOverBowler = cur
            bowler = null
            overRunsCharged = 0
        } else {
            bowler = cur
            overRunsCharged = sd.currentOverRuns
        }
        seedOvers = overIndex
        seedOverRuns = sd.overRuns
        // Current partnership: as entered, otherwise counted from the moment the innings was joined.
        partnershipStartRuns = sd.partnershipRuns?.let { (runs - it).coerceAtLeast(0) } ?: runs
        partnershipStartBalls = sd.partnershipBalls?.let { (legalBalls - it).coerceAtLeast(0) } ?: legalBalls

        when {
            wickets >= config.maxWickets -> endInnings("All out")
            legalBalls >= config.maxBalls -> endInnings("Overs complete")
        }
    }

    /** @return null on success, otherwise a human-readable error. */
    fun apply(event: ScoreEvent): String? = when (event) {
        is BallEvent -> applyBall(event)
        is SetBowlerEvent -> applySetBowler(event)
        is BatterInEvent -> applyBatterIn(event)
        is SwapStrikeEvent -> applySwap()
        is PenaltyEvent -> applyPenalty(event)
        is AdjustmentEvent -> applyAdjustment(event)
        is EndInningsEvent -> {
            if (ended) "Innings has already ended" else { endInnings(event.reason.ifBlank { "Innings closed" }); null }
        }
    }

    // ------------------------------------------------------------------------------------------

    private fun applyBall(e: BallEvent): String? {
        if (ended) return "Innings has ended"
        if (pendingEnd != null) return "A new batter must be selected before the next ball"
        val s = striker
        val n = nonStriker
        if (s == null || n == null) return "Both batters must be at the crease"
        val bw = bowler ?: return "A bowler must be selected"

        // ---- field validation ----
        if (e.runsBat < 0 || e.runsBat > 7) return "Runs off the bat must be between 0 and 7"
        if (e.extraRuns < 0 || e.extraRuns > 10) return "Extra runs must be between 0 and 10"
        if (e.extra != ExtraType.NO_BALL && e.noBallRunType != ExtraType.NONE) return "Bye type is only valid on a no-ball"
        when (e.extra) {
            ExtraType.NONE -> if (e.extraRuns != 0) return "Extra runs need an extra type"
            ExtraType.WIDE -> if (e.runsBat != 0) return "A wide cannot have runs off the bat"
            ExtraType.NO_BALL -> if (e.extraRuns > 0 && e.noBallRunType != ExtraType.BYE && e.noBallRunType != ExtraType.LEG_BYE)
                return "Specify bye or leg-bye for extra runs on a no-ball"
            ExtraType.BYE, ExtraType.LEG_BYE -> {
                if (e.runsBat != 0) return "Byes / leg-byes cannot have runs off the bat"
                if (e.extraRuns < 1) return "Byes / leg-byes need at least 1 run"
            }
        }
        if (e.boundary && e.runsBat + e.extraRuns < 4) return "A boundary must be at least 4 runs"

        val wk = e.wicket
        if (wk != null) {
            if (e.extra == ExtraType.WIDE && !wk.type.allowedOnWide) return "${wk.type.label} is not possible off a wide"
            if ((e.extra == ExtraType.NO_BALL || (freeHit && config.enforceFreeHit)) && !wk.type.allowedOnNoBall) {
                return "${wk.type.label} is not possible off a no-ball / free hit"
            }
            if (!wk.outBatterIsStriker && !wk.type.canDismissNonStriker) return "${wk.type.label} cannot dismiss the non-striker"
            if (!wk.type.allowsRuns && (e.runsBat != 0 || e.extraRuns != 0)) return "No runs are credited with ${wk.type.label}"
            if (wickets + 1 > config.maxWickets) return "All wickets have already fallen"
        }

        // ---- compute ----
        val legal = e.extra.isLegalDelivery
        val faced = e.extra != ExtraType.WIDE
        val penaltyRuns = when (e.extra) {
            ExtraType.WIDE -> config.widePenalty
            ExtraType.NO_BALL -> config.noBallPenalty
            else -> 0
        }
        val teamRunsAdded = e.runsBat + penaltyRuns + e.extraRuns
        val bowlerCharged = e.runsBat +
            (if (e.extra == ExtraType.WIDE) penaltyRuns + e.extraRuns else 0) +
            (if (e.extra == ExtraType.NO_BALL) penaltyRuns else 0)

        runs += teamRunsAdded
        when (e.extra) {
            ExtraType.WIDE -> wides += penaltyRuns + e.extraRuns
            ExtraType.NO_BALL -> {
                noBalls += penaltyRuns
                if (e.extraRuns > 0) {
                    if (e.noBallRunType == ExtraType.LEG_BYE) legByes += e.extraRuns else byes += e.extraRuns
                }
            }
            ExtraType.BYE -> byes += e.extraRuns
            ExtraType.LEG_BYE -> legByes += e.extraRuns
            ExtraType.NONE -> Unit
        }

        val batter = batters.getValue(s)
        if (faced) batter.balls += 1
        batter.runs += e.runsBat
        if (e.boundary && e.runsBat == 4) batter.fours += 1
        if (e.boundary && e.runsBat == 6) batter.sixes += 1

        val bowlerStat = bowlers.getOrPut(bw) { MBowler(bw) }
        bowlerStat.runs += bowlerCharged
        if (legal) bowlerStat.legalBalls += 1
        if (e.extra == ExtraType.WIDE) bowlerStat.wides += 1
        if (e.extra == ExtraType.NO_BALL) bowlerStat.noBalls += 1
        overRunsCharged += bowlerCharged

        // ---- strike after completed runs ----
        val physicalRuns = if (e.boundary) 0 else e.runsBat + e.extraRuns
        val swapped = physicalRuns % 2 == 1
        val atStrikerEnd: String? = if (swapped) n else s
        val atNonStrikerEnd: String? = if (swapped) s else n
        striker = atStrikerEnd
        nonStriker = atNonStrikerEnd

        // ---- free hit bookkeeping (computed from state BEFORE this ball) ----
        val wasFreeHit = freeHit
        freeHit = e.extra == ExtraType.NO_BALL || (e.extra == ExtraType.WIDE && wasFreeHit)

        if (legal) {
            legalBalls += 1
            currentOverLegal += 1
        }

        // ---- wicket ----
        if (wk != null) {
            val dismissedName = if (wk.outBatterIsStriker) s else n
            val dismissed = batters.getValue(dismissedName)
            dismissed.out = true
            dismissed.dismissal = dismissalText(wk, bw)
            wickets += 1
            if (wk.type.creditsBowler) bowlerStat.wickets += 1
            lastDismissed = dismissedName
            fow.add(FallOfWicket(wickets, runs, dismissedName, dismissed.runs, oversText()))

            val dismissedAtStrikerEnd = (dismissedName == atStrikerEnd)
            if (dismissedAtStrikerEnd) striker = null else nonStriker = null
            pendingEnd = if (dismissedAtStrikerEnd) StrikeEnd.STRIKER else StrikeEnd.NON_STRIKER

            if (wickets >= config.maxWickets) {
                pendingEnd = null
            } else {
                val incoming = wk.incomingBatter?.trim()
                if (!incoming.isNullOrEmpty()) {
                    val err = placeBatter(incoming)
                    if (err != null) {
                        // roll back is not possible mid-way; replay will report this event as failed
                        return err
                    }
                }
            }
        }

        allBalls.add(
            BallRecord(
                eventId = e.id,
                overIndex = overIndex,
                label = ScoreEngine.ballLabel(e),
                runsAdded = teamRunsAdded,
                legal = legal,
                wicket = wk != null,
                bowler = bw,
                striker = s
            )
        )

        // ---- over completion ----
        if (legal && currentOverLegal >= config.ballsPerOver) {
            val tmp = striker
            striker = nonStriker
            nonStriker = tmp
            pendingEnd = when (pendingEnd) {
                StrikeEnd.STRIKER -> StrikeEnd.NON_STRIKER
                StrikeEnd.NON_STRIKER -> StrikeEnd.STRIKER
                null -> null
            }
            if (overRunsCharged == 0 && !overMaidenVoid) bowlerStat.maidens += 1
            lastOverBowler = bw
            bowler = null
            overIndex += 1
            currentOverLegal = 0
            overRunsCharged = 0
            overMaidenVoid = false
        }

        // ---- innings end conditions ----
        val target = config.target
        when {
            target != null && runs >= target -> endInnings("Target reached")
            wickets >= config.maxWickets -> endInnings("All out")
            legalBalls >= config.maxBalls -> endInnings("Overs complete")
        }
        return null
    }

    private fun applySetBowler(e: SetBowlerEvent): String? {
        if (ended) return "Innings has ended"
        val name = e.name.trim()
        if (name.isEmpty()) return "Bowler name is required"
        val current = bowler
        if (current != null && current.equals(name, ignoreCase = true)) return null
        if (currentOverLegal == 0 && legalBalls > 0 && !config.allowConsecutiveOvers &&
            lastOverBowler?.equals(name, ignoreCase = true) == true
        ) return "The same bowler cannot bowl consecutive overs"
        val max = config.maxOversPerBowler
        val existing = bowlers[name]
        if (max != null && existing != null && existing.legalBalls >= max * config.ballsPerOver) {
            return "$name has already bowled the maximum $max overs"
        }
        if (current != null && currentOverLegal > 0) overMaidenVoid = true // mid-over change voids maiden
        bowler = name
        bowlers.getOrPut(name) { MBowler(name) }
        return null
    }

    private fun applyBatterIn(e: BatterInEvent): String? {
        if (ended) return "Innings has ended"
        if (pendingEnd == null) return "No batter is needed right now"
        val name = e.name.trim()
        if (name.isEmpty()) return "Batter name is required"
        return placeBatter(name)
    }

    private fun placeBatter(name: String): String? {
        val end = pendingEnd ?: return "No batter is needed right now"
        if (batters.keys.any { it.equals(name, ignoreCase = true) }) return "$name has already batted"
        batters[name] = MBatter(name, batters.size + 1)
        if (end == StrikeEnd.STRIKER) striker = name else nonStriker = name
        pendingEnd = null
        return null
    }

    private fun applySwap(): String? {
        if (ended) return "Innings has ended"
        val t = striker
        striker = nonStriker
        nonStriker = t
        pendingEnd = when (pendingEnd) {
            StrikeEnd.STRIKER -> StrikeEnd.NON_STRIKER
            StrikeEnd.NON_STRIKER -> StrikeEnd.STRIKER
            null -> null
        }
        return null
    }

    private fun applyPenalty(e: PenaltyEvent): String? {
        if (ended) return "Innings has ended"
        if (e.runs < 1 || e.runs > 20) return "Penalty runs must be between 1 and 20"
        runs += e.runs
        penalty += e.runs
        val target = config.target
        if (target != null && runs >= target) endInnings("Target reached")
        return null
    }

    private fun applyAdjustment(e: AdjustmentEvent): String? {
        if (runs + e.runs < 0) return "Adjustment would make the score negative"
        if (wickets + e.wickets < 0 || wickets + e.wickets > config.maxWickets) return "Adjustment would make wickets invalid"
        runs += e.runs
        wickets += e.wickets
        manualRuns += e.runs
        manualWickets += e.wickets
        if (wickets >= config.maxWickets && !ended) endInnings("All out")
        return null
    }

    private fun endInnings(reason: String) {
        ended = true
        endReason = reason
    }

    private fun oversText() = "${legalBalls / config.ballsPerOver}.${legalBalls % config.ballsPerOver}"

    private fun dismissalText(wk: WicketInfo, bowlerName: String): String {
        val f = wk.fielder?.trim().orEmpty()
        return when (wk.type) {
            DismissalType.BOWLED -> "b $bowlerName"
            DismissalType.CAUGHT -> when {
                f.isEmpty() -> "c b $bowlerName"
                f.equals(bowlerName, ignoreCase = true) -> "c & b $bowlerName"
                else -> "c $f b $bowlerName"
            }
            DismissalType.LBW -> "lbw b $bowlerName"
            DismissalType.STUMPED -> if (f.isEmpty()) "st b $bowlerName" else "st $f b $bowlerName"
            DismissalType.HIT_WICKET -> "hit wicket b $bowlerName"
            DismissalType.RUN_OUT -> if (f.isEmpty()) "run out" else "run out ($f)"
            DismissalType.OBSTRUCTING_FIELD -> "obstructing the field"
            DismissalType.HIT_BALL_TWICE -> "hit the ball twice"
        }
    }

    fun snapshot(): InningsState {
        val bpo = config.ballsPerOver
        fun bowlerSnap(b: MBowler) = BowlerStat(b.name, b.legalBalls, bpo, b.maidens, b.runs, b.wickets, b.wides, b.noBalls)
        val batterSnaps = batters.values.map { it.snap() }
        return InningsState(
            battingTeam = setup.battingTeam,
            bowlingTeam = setup.bowlingTeam,
            runs = runs,
            wickets = wickets,
            legalBalls = legalBalls,
            ballsPerOver = bpo,
            oversLimit = config.oversLimit,
            maxWickets = config.maxWickets,
            extras = Extras(wides, noBalls, byes, legByes, penalty),
            manualRunsAdjustment = manualRuns,
            manualWicketsAdjustment = manualWickets,
            striker = striker?.let { batters[it]?.snap() },
            nonStriker = nonStriker?.let { batters[it]?.snap() },
            bowler = bowler?.let { bowlers[it] }?.let(::bowlerSnap),
            batters = batterSnaps,
            bowlers = bowlers.values.map(::bowlerSnap),
            fallOfWickets = fow.toList(),
            lastDismissed = lastDismissed?.let { batters[it]?.snap() },
            currentOver = allBalls.filter { it.overIndex == overIndex },
            allBalls = allBalls.toList(),
            freeHit = freeHit,
            pendingBatterEnd = pendingEnd,
            ended = ended,
            endReason = endReason,
            target = config.target,
            seedOvers = seedOvers,
            seedOverRuns = seedOverRuns,
            partnershipStartRuns = partnershipStartRuns,
            partnershipStartBalls = partnershipStartBalls
        )
    }
}
