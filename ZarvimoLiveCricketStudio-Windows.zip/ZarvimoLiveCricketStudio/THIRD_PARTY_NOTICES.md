# Third-party notices

This project (Zarvimo Live Cricket Studio) bundles no third-party source code. It depends on the following
libraries, fetched by Gradle at build time under their own licenses:

| Library | Use | License |
|---|---|---|
| RootEncoder (`com.github.pedroSG94.RootEncoder:library`) by pedroSG94 | RTMP/RTMPS client, MediaCodec H.264/AAC encoders, OpenGL stream pipeline | Apache License 2.0 |
| AndroidX / Jetpack (Compose, Activity, Lifecycle, Navigation, Core) | UI and app framework | Apache License 2.0 |
| Kotlin standard library / coroutines | Language runtime | Apache License 2.0 |
| JUnit 4 (tests only) | Unit tests | Eclipse Public License 1.0 |

No audio, image, or font assets from third parties are included. Stadium backgrounds and logos are supplied by the
user at runtime; the user is responsible for holding the rights to any media they import.
