import org.jetbrains.compose.desktop.application.dsl.TargetFormat

// Windows (desktop) edition of Zarvimo Live Cricket Studio.
// This is a SEPARATE Gradle project: it never touches the Android build in ../app.
// It re-uses the pure-Kotlin cricket logic from ../app/src/main/java (scoring, DLS, overlay model, JSON) by copying
// the listed files into build/generated before compiling. Everything Android-specific (camera, MediaCodec, OpenGL,
// RootEncoder) is replaced here by Java2D rendering + an FFmpeg process.

plugins {
    kotlin("jvm") version "2.2.21"
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21"
    id("org.jetbrains.compose") version "1.9.3"
}

repositories {
    google()
    mavenCentral()
}

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.10.2")
    // Real org.json (the Android build uses the platform one).
    implementation("org.json:json:20240303")
}

// ---- shared pure-Kotlin sources (no android.* imports) ---------------------------------------------------------
val sharedRoot = file("../app/src/main/java/com/zarvimo/cricket")
val sharedFiles = listOf(
    "data/Json.kt",
    "graphics/Alerts.kt",
    "graphics/GraphicsModel.kt",
    "graphics/Panels.kt",
    "scoring/Dls.kt",
    "scoring/MatchSession.kt",
    "scoring/Models.kt",
    "scoring/ScoreEngine.kt",
    "scoring/SeedParser.kt",
    "stream/AudioMixModel.kt",
    "stream/AutoShowModel.kt",
    "stream/StreamModel.kt",
)

val syncShared by tasks.registering(Sync::class) {
    from(sharedRoot) { include(sharedFiles) }
    into(layout.buildDirectory.dir("generated/shared/kotlin/com/zarvimo/cricket"))
}

kotlin {
    sourceSets.named("main") {
        kotlin.srcDir(layout.buildDirectory.dir("generated/shared/kotlin"))
    }
}

tasks.named("compileKotlin") { dependsOn(syncShared) }

compose.desktop {
    application {
        mainClass = "com.zarvimo.cricket.desktop.MainKt"

        nativeDistributions {
            targetFormats(TargetFormat.Msi, TargetFormat.Exe)
            packageName = "ZarvimoLiveCricketStudio"
            packageVersion = "1.0.0"
            description = "Cricket scoring and live-stream studio for Windows"
            vendor = "Zarvimo"
            includeAllModules = true
            // resources/common/ffmpeg.exe (downloaded by the GitHub workflow) is copied next to the app.
            appResourcesRootDir.set(layout.projectDirectory.dir("resources"))
            windows {
                menu = true
                shortcut = true
                dirChooser = true
                perUserInstall = true
                upgradeUuid = "6f0e2f0a-4e0c-4b0e-9f3a-2b6a7c1d5e11"
            }
        }
    }
}
