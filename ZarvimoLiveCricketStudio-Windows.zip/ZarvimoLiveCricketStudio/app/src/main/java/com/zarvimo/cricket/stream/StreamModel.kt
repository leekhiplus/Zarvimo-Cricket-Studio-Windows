package com.zarvimo.cricket.stream

import java.net.URI

/** Output resolution profiles. All sizes are landscape (broadcast canvas is always landscape). */
enum class ResolutionProfile(
    val label: String,
    val width: Int,
    val height: Int,
    val minKbps: Int,
    val defaultKbps: Int,
    val maxKbps: Int
) {
    P360("360p", 640, 360, 400, 600, 800),
    // 848x480 (16-aligned) instead of 854x480: many hardware H.264 encoders reject or pad widths that are not
    // multiples of 16. Visually identical to 854x480 (16:9 within 0.6%).
    P480("480p", 848, 480, 700, 1000, 1500),
    P720("720p", 1280, 720, 1500, 2200, 3000),
    P1080("1080p (high bandwidth)", 1920, 1080, 3000, 4500, 6000);

    fun clampBitrate(kbps: Int): Int = kbps.coerceIn(minKbps, maxKbps)
}

object StreamOptions {
    val fpsOptions = listOf(15, 20, 24, 30)
    val audioBitrateOptionsKbps = listOf(64, 96, 128)
    const val AUDIO_SAMPLE_RATE = 44100
    const val KEYFRAME_INTERVAL_SEC = 2
    const val YOUTUBE_RTMP = "rtmp://a.rtmp.youtube.com/live2"
    const val YOUTUBE_RTMPS = "rtmps://a.rtmps.youtube.com:443/live2"
}

/**
 * Optional round camera picture ("bubble") placed over the background picture.
 * [size] is the diameter as a fraction of the output height; [x] / [y] are the centre as fractions of the output.
 */
data class BubbleConfig(
    val enabled: Boolean = false,
    val front: Boolean = true,
    val size: Float = 0.28f,
    val x: Float = 0.86f,
    val y: Float = 0.30f
) {
    fun sanitized() = copy(size = size.coerceIn(0.12f, 0.6f), x = x.coerceIn(0f, 1f), y = y.coerceIn(0f, 1f))

    companion object {
        val OFF = BubbleConfig()
    }
}

/** Where the program video comes from. The scoreboard graphics are drawn on top of every source. */
enum class VideoSourceMode(val label: String, val isCamera: Boolean) {
    BACKGROUND("Background picture", false),
    CAMERA_BACK("Back camera", true),
    CAMERA_FRONT("Front camera", true)
}

data class StreamSettings(
    val serverUrl: String = StreamOptions.YOUTUBE_RTMP,
    /** Held in memory only for the session; persisted separately and encrypted (see SecretStore). */
    val streamKey: String = "",
    val profile: ResolutionProfile = ResolutionProfile.P480,
    val fps: Int = 24,
    val videoBitrateKbps: Int = ResolutionProfile.P480.defaultKbps,
    val audioBitrateKbps: Int = 96,
    val stereo: Boolean = false,
    /** On a dropped connection, reduce the video bitrate by 25% (not below the profile minimum) before retrying. */
    val lowerBitrateOnReconnect: Boolean = true,
    /** Program video source (camera or background picture). */
    val videoSource: VideoSourceMode = VideoSourceMode.BACKGROUND,
    /** Extra clockwise camera rotation in degrees (0, 90, 180, 270) on top of the automatic orientation. */
    val cameraRotationOffset: Int = 0,
    /** Automatically lower the video bitrate while the network is congested and raise it again when it recovers. */
    val adaptiveBitrate: Boolean = true,
    /** Also save a copy of the broadcast on this phone while live. */
    val recordLocally: Boolean = false,
    /** Round camera picture over the background picture (only used when the video source is the background picture). */
    val bubbleEnabled: Boolean = false,
    val bubbleFront: Boolean = true,
    val bubbleSize: Float = 0.28f,
    val bubbleX: Float = 0.86f,
    val bubbleY: Float = 0.30f
) {
    fun bubble(): BubbleConfig = BubbleConfig(bubbleEnabled, bubbleFront, bubbleSize, bubbleX, bubbleY).sanitized()

    /** The stream key must NEVER appear in logs / crash reports, so toString masks it. */
    override fun toString(): String =
        "StreamSettings(server=${StreamValidator.redactServer(serverUrl)}, key=${if (streamKey.isEmpty()) "<empty>" else "<hidden>"}, " +
            "${profile.label}, ${fps}fps, v=${videoBitrateKbps}kbps, a=${audioBitrateKbps}kbps)"
}

sealed class ValidationResult {
    data class Valid(val endpoint: String, val secure: Boolean) : ValidationResult() {
        override fun toString(): String = "Valid(endpoint=<hidden>, secure=$secure)"
    }
    data class Invalid(val problems: List<String>) : ValidationResult()
}

object StreamValidator {

    const val HELP = "A valid ingest server URL (rtmp:// or rtmps://) and an ACTIVE stream key from your streaming " +
        "provider are both required. For YouTube: YouTube Studio > Go Live > Stream."

    fun validate(serverUrl: String, streamKey: String): ValidationResult {
        val problems = mutableListOf<String>()
        val url = serverUrl.trim()
        val key = streamKey.trim()

        if (url.isEmpty()) {
            problems += "Server URL is required"
        } else {
            val lower = url.lowercase()
            if (!lower.startsWith("rtmp://") && !lower.startsWith("rtmps://")) {
                problems += "Server URL must start with rtmp:// or rtmps://"
            } else if (url.any { it.isWhitespace() }) {
                problems += "Server URL must not contain spaces"
            } else {
                val host = try {
                    URI(url).host
                } catch (e: Exception) {
                    null
                }
                if (host.isNullOrBlank()) problems += "Server URL has no valid host name"
            }
        }

        if (key.isEmpty()) {
            problems += "Stream key is required"
        } else if (key.any { it.isWhitespace() }) {
            problems += "Stream key must not contain spaces"
        }

        if (problems.isNotEmpty()) return ValidationResult.Invalid(problems)
        val secure = url.lowercase().startsWith("rtmps://")
        return ValidationResult.Valid(url.trimEnd('/') + "/" + key, secure)
    }

    /** Safe-to-log form of a server URL (never includes a key; strips any path after the host/app). */
    fun redactServer(serverUrl: String): String {
        val u = serverUrl.trim()
        return try {
            val uri = URI(u)
            val host = uri.host ?: return "<invalid>"
            val port = if (uri.port > 0) ":${uri.port}" else ""
            "${uri.scheme}://$host$port/..."
        } catch (e: Exception) {
            "<invalid>"
        }
    }

    /** Remove the stream key from any text (e.g. library error messages) before showing / logging it. */
    fun scrub(text: String?, streamKey: String): String {
        if (text.isNullOrEmpty()) return ""
        val key = streamKey.trim()
        return if (key.length >= 4) text.replace(key, "<key>") else text
    }
}

// -------------------------------------------------------------------------------------------------
// State machine
// -------------------------------------------------------------------------------------------------

enum class StreamState { IDLE, PREPARING, CONNECTING, STREAMING, RECONNECTING, STOPPING, ERROR }

sealed class StreamEvent {
    object StartRequested : StreamEvent()
    object PrepareSucceeded : StreamEvent()
    data class PrepareFailed(val message: String) : StreamEvent()
    object ConnectionSucceeded : StreamEvent()
    /** The FIRST connection attempt of a session failed (e.g. bad key / unreachable host). */
    data class ConnectionFailed(val message: String) : StreamEvent()
    /** An established connection dropped. */
    data class ConnectionLost(val message: String) : StreamEvent()
    /** A reconnect attempt failed but more attempts remain. */
    data class ReconnectAttemptFailed(val message: String) : StreamEvent()
    data class RetriesExhausted(val message: String) : StreamEvent()
    data class AuthFailed(val message: String) : StreamEvent()
    object StopRequested : StreamEvent()
    object StopCompleted : StreamEvent()
}

object StreamStateMachine {

    /** @return the next state, or null if the event is not valid in [state] (caller must ignore it). */
    fun next(state: StreamState, event: StreamEvent): StreamState? = when (event) {
        StreamEvent.StartRequested ->
            if (state == StreamState.IDLE || state == StreamState.ERROR) StreamState.PREPARING else null

        StreamEvent.PrepareSucceeded ->
            if (state == StreamState.PREPARING) StreamState.CONNECTING else null

        is StreamEvent.PrepareFailed ->
            if (state == StreamState.PREPARING) StreamState.ERROR else null

        StreamEvent.ConnectionSucceeded ->
            if (state == StreamState.CONNECTING || state == StreamState.RECONNECTING) StreamState.STREAMING else null

        is StreamEvent.ConnectionFailed ->
            if (state == StreamState.CONNECTING) StreamState.ERROR else null

        is StreamEvent.ConnectionLost ->
            if (state == StreamState.STREAMING) StreamState.RECONNECTING else null

        is StreamEvent.ReconnectAttemptFailed ->
            if (state == StreamState.RECONNECTING) StreamState.RECONNECTING else null

        is StreamEvent.RetriesExhausted ->
            if (state == StreamState.RECONNECTING) StreamState.ERROR else null

        is StreamEvent.AuthFailed ->
            if (state == StreamState.CONNECTING || state == StreamState.STREAMING || state == StreamState.RECONNECTING)
                StreamState.ERROR else null

        StreamEvent.StopRequested -> when (state) {
            StreamState.PREPARING, StreamState.CONNECTING, StreamState.STREAMING, StreamState.RECONNECTING -> StreamState.STOPPING
            StreamState.ERROR -> StreamState.STOPPING
            else -> null
        }

        StreamEvent.StopCompleted -> if (state == StreamState.STOPPING) StreamState.IDLE else null
    }
}

/** Immutable snapshot published to the UI. Every field comes from real engine callbacks. */
data class StreamStatus(
    val state: StreamState = StreamState.IDLE,
    val errorMessage: String? = null,
    val reconnectAttempt: Int = 0,
    val maxReconnectAttempts: Int = 0,
    /** Epoch millis of the moment the server accepted the connection; null if never connected. */
    val liveSinceMs: Long? = null,
    /** Real bits-per-second reported by the transport; null = unavailable (never fabricated). */
    val measuredBitrateBps: Long? = null,
    /** Real frames sent to the encoder per second, if measured; null = unavailable. */
    val measuredFps: Int? = null,
    val droppedFrames: Long? = null
)

/** Labels shown in the UI. Preview status and network status are intentionally separate. */
object StatusLabels {
    fun stream(state: StreamState): String = when (state) {
        StreamState.IDLE -> "STREAM STOPPED"
        StreamState.PREPARING -> "PREPARING"
        StreamState.CONNECTING -> "CONNECTING"
        StreamState.STREAMING -> "LIVE STREAMING"
        StreamState.RECONNECTING -> "RECONNECTING"
        StreamState.STOPPING -> "STOPPING"
        StreamState.ERROR -> "STREAM ERROR"
    }

    fun preview(running: Boolean): String = if (running) "PREVIEW READY" else "PREVIEW OFF"

    /** The word LIVE may only be shown while the state really is STREAMING. */
    fun mayShowLiveBadge(state: StreamState): Boolean = state == StreamState.STREAMING
}

/** Bounded exponential backoff. Never retries forever. */
data class ReconnectPolicy(
    val maxAttempts: Int = 6,
    val baseDelayMs: Long = 2_000,
    val maxDelayMs: Long = 30_000
) {
    /** @param attempt 1-based attempt number. */
    fun delayForAttempt(attempt: Int): Long {
        require(attempt >= 1) { "attempt is 1-based" }
        val shift = (attempt - 1).coerceAtMost(20)
        val raw = baseDelayMs * (1L shl shift)
        return raw.coerceAtMost(maxDelayMs)
    }

    fun shouldRetry(attemptsAlreadyMade: Int): Boolean = attemptsAlreadyMade < maxAttempts
}

object DurationFormat {
    fun hhmmss(totalSeconds: Long): String {
        val s = totalSeconds.coerceAtLeast(0)
        return String.format(java.util.Locale.ROOT, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }
}

object BitrateAdvisor {
    /** Next (lower) bitrate in kbps after a drop; never below the profile minimum. */
    fun reduced(currentKbps: Int, profile: ResolutionProfile): Int =
        (currentKbps * 0.75).toInt().coerceAtLeast(profile.minKbps)
}
