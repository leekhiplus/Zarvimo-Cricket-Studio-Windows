package com.zarvimo.cricket.scoring

/** Raw text typed in the "join mid-match" form. Everything is comma separated so it is quick to type on a phone. */
data class SeedInputs(
    /** "runs, wickets" */
    val score: String = "",
    /** overs completed, e.g. "5.3" */
    val overs: String = "",
    /** "wides, no-balls, byes, leg-byes" (optional) */
    val extras: String = "",
    /** "runs, balls, 4s, 6s" */
    val striker: String = "",
    val nonStriker: String = "",
    /** "overs, maidens, runs, wickets" */
    val bowler: String = "",
    /** runs the current bowler conceded in the over in progress (optional) */
    val currentOverRuns: String = "",
    /** one batter per line: "Name, runs, balls, how out" (optional) */
    val outBatters: String = "",
    /** one bowler per line: "Name, overs, maidens, runs, wickets" (optional) */
    val otherBowlers: String = "",
    /** runs of each completed over: "8, 5, 12, 6" (optional, only for the run-rate graph) */
    val overRuns: String = "",
    /** current partnership "runs, balls" (optional) */
    val partnership: String = ""
)

data class SeedResult(val seed: InningsSeed?, val error: String?)

/** Turns the form text into an [InningsSeed]. Pure Kotlin (unit-tested); the engine validates the numbers afterwards. */
object SeedParser {

    /** "5.3" -> 33 legal balls with 6 balls per over. Returns null when the text is not a valid overs figure. */
    fun parseOvers(text: String, ballsPerOver: Int): Int? {
        val t = text.trim().replace(',', '.')
        if (t.isEmpty()) return null
        val parts = t.split('.')
        if (parts.size > 2) return null
        val overs = parts[0].toIntOrNull() ?: return null
        val balls = if (parts.size == 2 && parts[1].isNotEmpty()) (parts[1].toIntOrNull() ?: return null) else 0
        if (overs < 0 || balls < 0 || balls >= ballsPerOver) return null
        return overs * ballsPerOver + balls
    }

    private fun tokens(text: String): List<String> = text.split(',', ';', ' ', '/').map { it.trim() }.filter { it.isNotEmpty() }

    /** Up to [count] integers (missing ones are 0). Null when a token is not a whole number or there are too many. */
    fun parseInts(text: String, count: Int): List<Int>? {
        val t = tokens(text)
        if (t.size > count) return null
        val out = ArrayList<Int>()
        for (x in t) out.add(x.toIntOrNull() ?: return null)
        while (out.size < count) out.add(0)
        return out
    }

    private fun fail(msg: String) = SeedResult(null, msg)

    fun build(i: SeedInputs, ballsPerOver: Int): SeedResult {
        if (i.score.isBlank()) return fail("Enter the team score as \"runs, wickets\", for example 74, 2")
        val score = parseInts(i.score, 2) ?: return fail("Team score: write \"runs, wickets\", for example 74, 2")
        val balls = parseOvers(i.overs, ballsPerOver) ?: return fail("Overs completed: write it like 5.3 (the ball count must be below $ballsPerOver)")
        val ex = parseInts(i.extras, 4) ?: return fail("Extras: up to four numbers: wides, no-balls, byes, leg-byes")
        val st = parseInts(i.striker, 4) ?: return fail("Striker: runs, balls, 4s, 6s")
        val ns = parseInts(i.nonStriker, 4) ?: return fail("Non-striker: runs, balls, 4s, 6s")

        val bt = tokens(i.bowler)
        var bowlerBalls = 0
        var bowlerRest = listOf(0, 0, 0)
        if (bt.isNotEmpty()) {
            bowlerBalls = parseOvers(bt[0], ballsPerOver) ?: return fail("Current bowler: overs, maidens, runs, wickets (overs like 2.3)")
            bowlerRest = parseInts(bt.drop(1).joinToString(","), 3) ?: return fail("Current bowler: overs, maidens, runs, wickets")
        }
        val currentOver = if (i.currentOverRuns.isBlank()) 0 else (i.currentOverRuns.trim().toIntOrNull() ?: return fail("Runs in the current over must be a number"))

        val outs = ArrayList<SeedBatter>()
        i.outBatters.lines().withIndex().forEach { (idx, raw) ->
            if (raw.isBlank()) return@forEach
            val p = raw.split(',').map { it.trim() }
            val r = p.getOrNull(1)?.toIntOrNull()
            val b = p.getOrNull(2)?.toIntOrNull()
            if (p.size < 3 || p[0].isEmpty() || r == null || b == null) {
                return fail("Batters already out, line ${idx + 1}: write Name, runs, balls, how out")
            }
            outs.add(SeedBatter(p[0], r, b, 0, 0, p.drop(3).joinToString(", ").ifBlank { "out" }))
        }

        val others = ArrayList<SeedBowler>()
        i.otherBowlers.lines().withIndex().forEach { (idx, raw) ->
            if (raw.isBlank()) return@forEach
            val p = raw.split(',').map { it.trim() }
            val ob = p.getOrNull(1)?.let { parseOvers(it, ballsPerOver) }
            val m = p.getOrNull(2)?.toIntOrNull()
            val r = p.getOrNull(3)?.toIntOrNull()
            val w = p.getOrNull(4)?.toIntOrNull()
            if (p.size < 5 || p[0].isEmpty() || ob == null || m == null || r == null || w == null) {
                return fail("Other bowlers, line ${idx + 1}: write Name, overs, maidens, runs, wickets")
            }
            others.add(SeedBowler(p[0], ob, m, r, w))
        }

        val overRuns = if (i.overRuns.isBlank()) emptyList() else (tokens(i.overRuns).map { it.toIntOrNull() ?: return fail("Runs per over: numbers separated by commas") })

        var pr: Int? = null
        var pb: Int? = null
        if (i.partnership.isNotBlank()) {
            val p = parseInts(i.partnership, 2) ?: return fail("Partnership: runs, balls")
            pr = p[0]
            pb = p[1]
        }

        return SeedResult(
            InningsSeed(
                runs = score[0], wickets = score[1], legalBalls = balls,
                wides = ex[0], noBalls = ex[1], byes = ex[2], legByes = ex[3],
                strikerRuns = st[0], strikerBalls = st[1], strikerFours = st[2], strikerSixes = st[3],
                nonStrikerRuns = ns[0], nonStrikerBalls = ns[1], nonStrikerFours = ns[2], nonStrikerSixes = ns[3],
                bowlerLegalBalls = bowlerBalls, bowlerMaidens = bowlerRest[0], bowlerRuns = bowlerRest[1], bowlerWickets = bowlerRest[2],
                currentOverRuns = currentOver,
                outBatters = outs, otherBowlers = others, overRuns = overRuns,
                partnershipRuns = pr, partnershipBalls = pb
            ),
            null
        )
    }
}
