package com.zarvimo.cricket.desktop

import com.zarvimo.cricket.graphics.OverlayData
import java.awt.BasicStroke
import java.awt.Color
import java.awt.Font
import java.awt.GradientPaint
import java.awt.Graphics2D
import java.awt.RenderingHints
import java.awt.geom.Ellipse2D
import java.awt.geom.RoundRectangle2D
import java.awt.image.BufferedImage

/**
 * Draws the broadcast picture (background + scoreboard) with plain Java2D. The SAME function produces the preview
 * in the window and every frame sent to FFmpeg, so what you see is what goes on air.
 * All coordinates are in a 1920x1080 reference canvas that is scaled to the requested size.
 */
object OverlayPainter {

    private const val RW = 1920
    private const val RH = 1080

    fun render(o: OverlayData, width: Int, height: Int, bg: BufferedImage?): BufferedImage {
        val img = BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR)
        val g = img.createGraphics()
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR)
            g.scale(width.toDouble() / RW, height.toDouble() / RH)
            drawBackground(g, bg)
            drawTop(g, o)
            if (o.resultText != null) {
                drawCenterCard(g, o.resultText!!, null, Color(0xFFC107))
            } else if (o.preMatch != null && o.striker == null) {
                drawCenterCard(g, o.preMatch!!, o.preMatchSub, Color(0x29B6F6))
            }
            if (o.striker != null || o.score != "0/0") drawScoreStrip(g, o)
            o.banner?.let { drawBanner(g, it) }
        } finally {
            g.dispose()
        }
        return img
    }

    // ------------------------------------------------------------------------------------------ pieces

    private fun drawBackground(g: Graphics2D, bg: BufferedImage?) {
        if (bg != null) {
            // "cover": fill the canvas, crop the overflow
            val scale = maxOf(RW.toDouble() / bg.width, RH.toDouble() / bg.height)
            val w = (bg.width * scale).toInt()
            val h = (bg.height * scale).toInt()
            g.drawImage(bg, (RW - w) / 2, (RH - h) / 2, w, h, null)
            return
        }
        g.paint = GradientPaint(0f, 0f, Color(0x0B3D1E), 0f, RH.toFloat(), Color(0x1B7A3A))
        g.fillRect(0, 0, RW, RH)
        g.color = Color(255, 255, 255, 28)
        g.stroke = BasicStroke(5f)
        g.draw(Ellipse2D.Double(160.0, 90.0, 1600.0, 900.0))
        g.draw(Ellipse2D.Double(560.0, 290.0, 800.0, 500.0))
        g.color = Color(214, 190, 120, 70)
        g.fillRect(900, 330, 120, 420)
    }

    private fun drawTop(g: Graphics2D, o: OverlayData) {
        if (o.title.isNotBlank()) text(g, o.title.uppercase(), 120, 80, 40, true, Color.WHITE)
        if (o.venue.isNotBlank()) text(g, o.venue, 120, 122, 26, false, Color(255, 255, 255, 200))
    }

    private fun drawBanner(g: Graphics2D, textValue: String) {
        val w = textWidth(g, textValue, 42, true) + 90
        val x = (RW - w) / 2
        g.color = Color(0xB71C1C)
        g.fill(RoundRectangle2D.Double(x.toDouble(), 150.0, w.toDouble(), 74.0, 24.0, 24.0))
        text(g, textValue, x + 45, 203, 42, true, Color.WHITE)
    }

    private fun drawCenterCard(g: Graphics2D, line1: String, line2: String?, accent: Color) {
        val w = 1500
        val x = (RW - w) / 2
        val h = if (line2 == null) 190 else 260
        val y = 330
        g.color = Color(8, 14, 24, 225)
        g.fill(RoundRectangle2D.Double(x.toDouble(), y.toDouble(), w.toDouble(), h.toDouble(), 36.0, 36.0))
        g.color = accent
        g.fillRect(x, y + 20, 14, h - 40)
        centered(g, line1, RW / 2, y + 112, 62, true, Color.WHITE)
        if (line2 != null) centered(g, line2, RW / 2, y + 205, 34, false, Color(255, 255, 255, 210))
    }

    private fun drawScoreStrip(g: Graphics2D, o: OverlayData) {
        val x = 120
        val y = 790
        val w = 1680
        val h = 170
        // recent balls above the strip
        var cx = x + 8
        for (label in o.recentBalls.takeLast(12)) {
            val up = label.uppercase()
            val col = when {
                up.startsWith("W") && !up.startsWith("WD") -> Color(0xD32F2F)
                up == "4" -> Color(0x1E88E5)
                up == "6" -> Color(0x8E24AA)
                else -> Color(0x37474F)
            }
            g.color = col
            g.fill(Ellipse2D.Double(cx.toDouble(), (y - 62).toDouble(), 50.0, 50.0))
            centered(g, label, cx + 25, y - 26, 22, true, Color.WHITE)
            cx += 58
        }

        g.color = Color(8, 14, 24, 225)
        g.fill(RoundRectangle2D.Double(x.toDouble(), y.toDouble(), w.toDouble(), h.toDouble(), 28.0, 28.0))

        // team block
        g.color = Color(o.battingColor)
        g.fill(RoundRectangle2D.Double(x.toDouble(), y.toDouble(), 270.0, h.toDouble(), 28.0, 28.0))
        centered(g, o.battingShort.ifBlank { o.battingTeam.take(3).uppercase() }, x + 135, y + 92, 68, true, Color.WHITE)
        centered(g, "INNINGS ${o.inningsNumber}", x + 135, y + 140, 24, false, Color(255, 255, 255, 220))

        // score
        text(g, o.score, x + 300, y + 98, 90, true, Color.WHITE)
        text(g, "OVERS ${o.overs} / ${o.oversLimit}", x + 304, y + 142, 28, false, Color(255, 255, 255, 220))

        // batters
        val bx = x + 690
        o.striker?.let { text(g, "* ${it.name}", bx, y + 62, 34, true, Color.WHITE); right(g, "${it.runs} (${it.balls})", bx + 400, y + 62, 34, true, Color.WHITE) }
        o.nonStriker?.let { text(g, "   ${it.name}", bx, y + 108, 32, false, Color(255, 255, 255, 215)); right(g, "${it.runs} (${it.balls})", bx + 400, y + 108, 32, false, Color(255, 255, 255, 215)) }

        // bowler
        val wx = x + 1160
        o.bowlerName?.let { text(g, it, wx, y + 62, 32, true, Color.WHITE) }
        o.bowlerFigures?.let { text(g, it, wx, y + 108, 32, false, Color(255, 255, 255, 215)) }

        // bottom line: run rates / chase
        val parts = ArrayList<String>()
        parts += "CRR ${o.currentRunRate}"
        o.targetText?.let { parts += it }
        o.requiredRunRate?.let { parts += "RRR $it" }
        text(g, parts.joinToString("    "), wx, y + 152, 26, true, Color(0xFFD54F))
        o.chaseText?.let { text(g, it, bx, y + 152, 26, true, Color(0xFFD54F)) }
        if (o.chaseText == null) o.lastWicket?.let { text(g, "LAST WICKET  $it", bx, y + 152, 24, false, Color(255, 255, 255, 200)) }
    }

    // ------------------------------------------------------------------------------------------ text helpers

    private fun font(size: Int, bold: Boolean) = Font("SansSerif", if (bold) Font.BOLD else Font.PLAIN, size)

    private fun textWidth(g: Graphics2D, s: String, size: Int, bold: Boolean): Int {
        g.font = font(size, bold)
        return g.fontMetrics.stringWidth(s)
    }

    private fun text(g: Graphics2D, s: String, x: Int, y: Int, size: Int, bold: Boolean, color: Color) {
        g.font = font(size, bold)
        g.color = color
        g.drawString(s, x, y)
    }

    private fun centered(g: Graphics2D, s: String, cx: Int, y: Int, size: Int, bold: Boolean, color: Color) {
        val w = textWidth(g, s, size, bold)
        text(g, s, cx - w / 2, y, size, bold, color)
    }

    private fun right(g: Graphics2D, s: String, rx: Int, y: Int, size: Int, bold: Boolean, color: Color) {
        val w = textWidth(g, s, size, bold)
        text(g, s, rx - w, y, size, bold, color)
    }
}
