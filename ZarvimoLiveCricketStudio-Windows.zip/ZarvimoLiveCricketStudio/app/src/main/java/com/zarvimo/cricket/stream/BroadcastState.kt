package com.zarvimo.cricket.stream

import com.zarvimo.cricket.graphics.BroadcastAssets
import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.graphics.OverlayData
import java.util.concurrent.atomic.AtomicReference

/**
 * The single source of truth for what the compositor draws. The UI/scoring layer publishes new immutable
 * snapshots; the frame pump reads the latest snapshot for EVERY frame. Because preview and encoder both consume the
 * pump's frames, score changes appear in both without restarting anything.
 */
class BroadcastState {
    data class Snapshot(val overlay: OverlayData, val config: GraphicsConfig)

    private val ref = AtomicReference(Snapshot(OverlayData(), GraphicsConfig()))
    val assets = BroadcastAssets()

    fun snapshot(): Snapshot = ref.get()

    fun update(overlay: OverlayData? = null, config: GraphicsConfig? = null) {
        while (true) {
            val cur = ref.get()
            val next = Snapshot(overlay ?: cur.overlay, config ?: cur.config)
            if (ref.compareAndSet(cur, next)) return
        }
    }
}
