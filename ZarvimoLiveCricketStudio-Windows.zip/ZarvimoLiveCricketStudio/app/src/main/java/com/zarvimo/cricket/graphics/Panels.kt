package com.zarvimo.cricket.graphics

import com.zarvimo.cricket.scoring.BatterStat
import com.zarvimo.cricket.scoring.BowlerStat
import com.zarvimo.cricket.scoring.InningsState
import java.util.Locale

/** Full-screen FOUR / SIX / WICKET burst. [startMs] uses the same clock as the renderer (SystemClock.uptimeMillis()). */
enum class BurstKind(val text: String, val color: Int) {
    FOUR("FOUR", 0xFF1E88E5.toInt()),
    SIX("SIX", 0xFF8E24AA.toInt()),
    WICKET("WICKET", 0xFFD32F2F.toInt())
}

data class BurstInfo(val kind: BurstKind, val detail: String, val startMs: Long) {
    companion object {
        const val DURATION_MS = 2800L
    }
}

enum class PanelKind(val label: String, val emptyHint: String = "Nothing to show yet: start an innings and put the batters at the crease first") {
    SCORECARD("Full scorecard"),
    STRIKER("Striker stats"),
    NON_STRIKER("Non-striker stats"),
    BOWLER("Bowler stats"),
    PARTNERSHIP("Partnership"),
    RUN_RATE("Run-rate graph"),
    COMMENT("Viewer comment"),
    PLAYING_XI("Playing XI"),
    TOSS_CARD("Toss", "Enter the toss winner and decision in Match Setup first"),
    MATCH_SUMMARY("Match summary", "Start the match first: there is no innings to summarise yet"),
    RESULT_CARD("Result", "The match is not finished yet"),
    MAN_OF_MATCH("Man of the match", "Enter the man of the match in Match Setup first");

    /** These four cover the whole picture and stay longer on air. */
    val fullScreen: Boolean get() = this == TOSS_CARD || this == MATCH_SUMMARY || this == RESULT_CARD || this == MAN_OF_MATCH
}

/** One table row of the scorecard: a name and up to five right-aligned columns. */
data class PanelRow(
    val name: String,
    val sub: String = "",
    val c1: String = "",
    val c2: String = "",
    val c3: String = "",
    val c4: String = "",
    val c5: String = "",
    val highlight: Boolean = false
)

/** Everything the compositor needs to draw an on-air panel. Built from the scoring state (pure Kotlin). */
data class PanelInfo(
    val kind: PanelKind,
    val title: String,
    val subtitle: String = "",
    val batHeader: List<String> = emptyList(),
    val bat: List<PanelRow> = emptyList(),
    val bowlHeader: List<String> = emptyList(),
    val bowl: List<PanelRow> = emptyList(),
    val footer: String = "",
    /** key / value chips of the player and partnership cards. */
    val stats: List<Pair<String, String>> = emptyList(),
    /** runs per over (graph). */
    val overRuns: List<Int> = emptyList(),
    /** wickets per over (graph markers), same length as [overRuns]. */
    val overWickets: List<Int> = emptyList(),
    val oversLimit: Int = 20,
    /** required run rate shown as a reference line in a chase. */
    val requiredRate: Float? = null,
    val currentRate: Float = 0f,
    val shownAtMs: Long = 0L,
    /** Team colours of the Playing XI panel (0 = use the accent colour). */
    val colorA: Int = 0,
    val colorB: Int = 0,
    /** Which team logo belongs to the card: 0 none, 1 team A, 2 team B (man of the match). */
    val teamSide: Int = 0
)

/** A man-of-the-match suggestion: name, a short figures line, a score for sorting, and his team. */
data class Performer(val name: String, val line: String, val points: Int, val team: String)

object PanelBuilder {


    // ------------------------------------------------------------------------------ full-screen cards

    private fun visualColor(setup: com.zarvimo.cricket.scoring.MatchSetup, visuals: MatchVisuals, team: String): Int =
        if (team.trim().equals(setup.teamA.trim(), true)) visuals.teamAColor else visuals.teamBColor

    /** Toss card, or null when no toss winner has been entered. */
    fun toss(setup: com.zarvimo.cricket.scoring.MatchSetup, visuals: MatchVisuals): PanelInfo? {
        val w = setup.tossWinner.trim()
        if (w.isEmpty()) return null
        val decision = when (setup.tossDecision) {
            com.zarvimo.cricket.scoring.TossDecision.BAT -> "AND CHOSE TO BAT FIRST"
            com.zarvimo.cricket.scoring.TossDecision.BOWL -> "AND CHOSE TO BOWL FIRST"
            else -> "WON THE TOSS"
        }
        val chips = ArrayList<Pair<String, String>>()
        setup.battingFirstTeam?.let { chips += "BATTING FIRST" to it.uppercase() }
        if (setup.startTime.isNotBlank()) chips += "MATCH STARTS" to setup.startTime.trim().uppercase()
        if (setup.venue.isNotBlank()) chips += "VENUE" to setup.venue.trim().uppercase()
        return PanelInfo(
            kind = PanelKind.TOSS_CARD, title = "TOSS", subtitle = w.uppercase(), footer = decision, stats = chips,
            batHeader = listOf(setup.teamA), bowlHeader = listOf(setup.teamB),
            colorA = visuals.teamAColor, colorB = visuals.teamBColor
        )
    }

    /** Man of the match card, or null when no name has been entered. */
    fun manOfMatch(setup: com.zarvimo.cricket.scoring.MatchSetup, visuals: MatchVisuals): PanelInfo? {
        val n = setup.momName.trim()
        if (n.isEmpty()) return null
        val team = setup.momTeam.trim()
        val side = when {
            team.isEmpty() -> 0
            team.equals(setup.teamA.trim(), true) -> 1
            team.equals(setup.teamB.trim(), true) -> 2
            else -> 0
        }
        return PanelInfo(
            kind = PanelKind.MAN_OF_MATCH, title = "MAN OF THE MATCH", subtitle = n.uppercase(), footer = setup.momDetail.trim().uppercase(),
            stats = if (team.isNotEmpty()) listOf("TEAM" to team.uppercase()) else emptyList(),
            colorA = if (side == 2) visuals.teamBColor else visuals.teamAColor, teamSide = side
        )
    }

    private fun inningsColumn(st: InningsState): Pair<String, List<PanelRow>> {
        val bats = st.batters.filter { it.balls > 0 || it.runs > 0 }.sortedWith(compareByDescending<BatterStat> { it.runs }.thenBy { it.balls }).take(3)
        val bowls = st.bowlers.sortedWith(compareByDescending<BowlerStat> { it.wickets }.thenBy { it.runs }).take(2)
        val rows = bats.map { PanelRow(it.name, "BAT", "${it.runs}", "(${it.balls})") } +
            bowls.map { PanelRow(it.name, "BOWL", "${it.wickets}/${it.runs}", "(${it.oversText})") }
        return Pair("${st.battingTeam.uppercase()}   ${st.scoreText} (${st.oversText})", rows)
    }

    /** Both innings with their best batters and bowlers; super overs are listed underneath. Null before the first ball. */
    fun summary(setup: com.zarvimo.cricket.scoring.MatchSetup, session: com.zarvimo.cricket.scoring.MatchSession, visuals: MatchVisuals): PanelInfo? {
        val s1 = session.stateOf(0) ?: return null
        val s2 = session.stateOf(1)
        val c1 = inningsColumn(s1)
        val c2 = s2?.let { inningsColumn(it) }
        val extra = ArrayList<Pair<String, String>>()
        var k = 2
        while (k < session.innings.size) {
            val a = session.stateOf(k) ?: break
            val b = session.stateOf(k + 1)
            val line = "${a.battingTeam} ${a.scoreText}" + (b?.let { "   \u2022   ${it.battingTeam} ${it.scoreText}" } ?: "")
            extra += "SUPER OVER ${(k - 2) / 2 + 1}" to line.uppercase()
            k += 2
        }
        return PanelInfo(
            kind = PanelKind.MATCH_SUMMARY, title = "MATCH SUMMARY",
            subtitle = setup.title.ifBlank { "${setup.teamA} vs ${setup.teamB}" },
            batHeader = listOf(c1.first), bat = c1.second,
            bowlHeader = listOf(c2?.first ?: "SECOND INNINGS TO COME"), bowl = c2?.second ?: emptyList(),
            footer = session.finalResult()?.uppercase() ?: "MATCH IN PROGRESS",
            stats = extra,
            colorA = visualColor(setup, visuals, s1.battingTeam),
            colorB = if (s2 != null) visualColor(setup, visuals, s2.battingTeam) else visuals.teamBColor
        )
    }

    /** Result card, or null while the match is not finished. */
    fun result(setup: com.zarvimo.cricket.scoring.MatchSetup, session: com.zarvimo.cricket.scoring.MatchSession, visuals: MatchVisuals): PanelInfo? {
        val res = session.finalResult() ?: return null
        val s1 = session.stateOf(0) ?: return null
        val s2 = session.stateOf(1) ?: return null
        val lines = listOf(
            s1.battingTeam.uppercase() to "${s1.scoreText} (${s1.oversText} OV)",
            s2.battingTeam.uppercase() to "${s2.scoreText} (${s2.oversText} OV)"
        )
        return PanelInfo(
            kind = PanelKind.RESULT_CARD, title = "RESULT", subtitle = res.uppercase(),
            footer = if (setup.momName.isNotBlank()) "MAN OF THE MATCH: ${setup.momName.trim().uppercase()}" else "",
            stats = lines,
            batHeader = listOf(s1.battingTeam), bowlHeader = listOf(s2.battingTeam),
            colorA = visualColor(setup, visuals, s1.battingTeam), colorB = visualColor(setup, visuals, s2.battingTeam),
            teamSide = if (s1.battingTeam.trim().equals(setup.teamA.trim(), true)) 1 else 2
        )
    }

    /** Suggestions for the man of the match: the three best all-round performances (runs + 20 per wicket) of the match. */
    fun topPerformers(session: com.zarvimo.cricket.scoring.MatchSession): List<Performer> {
        data class Acc(var runs: Int = 0, var balls: Int = 0, var wkts: Int = 0, var conceded: Int = 0, var team: String = "")
        val map = LinkedHashMap<String, Acc>()
        val upper = minOf(session.innings.size, 2)
        for (i in 0 until upper) {
            val st = session.stateOf(i) ?: continue
            st.batters.forEach { b -> map.getOrPut(b.name) { Acc() }.apply { runs += b.runs; balls += b.balls; team = st.battingTeam } }
            st.bowlers.forEach { b -> map.getOrPut(b.name) { Acc() }.apply { wkts += b.wickets; conceded += b.runs; if (team.isEmpty()) team = st.bowlingTeam } }
        }
        return map.entries
            .map { (name, a) ->
                val parts = ArrayList<String>()
                if (a.balls > 0 || a.runs > 0) parts += "${a.runs} (${a.balls})"
                if (a.wkts > 0 || a.conceded > 0) parts += "${a.wkts}/${a.conceded}"
                Performer(name, parts.joinToString("  &  "), a.runs + 20 * a.wkts, a.team)
            }
            .filter { it.points > 0 }
            .sortedByDescending { it.points }
            .take(3)
    }

    /** Both squads side by side. Works before the first ball. [bat] = team A rows, [bowl] = team B rows; headers carry the team names. */
    fun playingXi(setup: com.zarvimo.cricket.scoring.MatchSetup, colorA: Int, colorB: Int): PanelInfo {
        fun rows(names: List<String>) = names.mapIndexed { i, n -> PanelRow(name = n, c1 = (i + 1).toString()) }
        return PanelInfo(
            kind = PanelKind.PLAYING_XI,
            title = "PLAYING XI",
            subtitle = setup.title.ifBlank { "${setup.teamA} vs ${setup.teamB}" },
            batHeader = listOf(setup.teamA), bat = rows(setup.squadA),
            bowlHeader = listOf(setup.teamB), bowl = rows(setup.squadB),
            footer = setup.venue,
            colorA = colorA, colorB = colorB
        )
    }

    private fun f1(v: Double) = String.format(Locale.ROOT, "%.1f", v)
    private fun f2(v: Double) = String.format(Locale.ROOT, "%.2f", v)

    private fun batRow(b: BatterStat, atCrease: Boolean) = PanelRow(
        name = b.name,
        sub = if (b.out) (b.dismissal ?: "out") else if (atCrease) "not out" else "",
        c1 = b.runs.toString(), c2 = b.balls.toString(), c3 = b.fours.toString(), c4 = b.sixes.toString(), c5 = f1(b.strikeRate),
        highlight = atCrease
    )

    private fun bowlRow(b: BowlerStat, current: Boolean) = PanelRow(
        name = b.name, c1 = b.oversText, c2 = b.maidens.toString(), c3 = b.runs.toString(), c4 = b.wickets.toString(), c5 = f1(b.economy),
        highlight = current
    )

    fun scorecard(st: InningsState): PanelInfo {
        val atCrease = setOfNotNull(st.striker?.name, st.nonStriker?.name)
        val bat = st.batters.map { batRow(it, !it.out && it.name in atCrease) }
        val bowl = st.bowlers.map { bowlRow(it, it.name == st.bowler?.name) }
        val fow = st.fallOfWickets.joinToString("  ") { "${it.wicketNumber}-${it.teamRuns} (${it.batter}, ${it.oversText})" }
        val ex = st.extras
        val extras = "Extras ${ex.total} (w ${ex.wides}, nb ${ex.noBalls}, b ${ex.byes}, lb ${ex.legByes}" + (if (ex.penalty > 0) ", pen ${ex.penalty}" else "") + ")"
        return PanelInfo(
            kind = PanelKind.SCORECARD,
            title = st.battingTeam.uppercase(),
            subtitle = "${st.scoreText}  (${st.oversText} ov)  •  RR ${f2(st.runRate)}",
            batHeader = listOf("BATTING", "R", "B", "4s", "6s", "SR"),
            bat = bat,
            bowlHeader = listOf("BOWLING", "O", "M", "R", "W", "ECO"),
            bowl = bowl,
            footer = extras + (if (fow.isNotEmpty()) "     FOW: $fow" else "")
        )
    }

    /** Striker / non-striker / bowler card. Returns null when that player is not at the crease yet. */
    fun player(st: InningsState, kind: PanelKind): PanelInfo? = when (kind) {
        PanelKind.STRIKER, PanelKind.NON_STRIKER -> {
            val b = (if (kind == PanelKind.STRIKER) st.striker else st.nonStriker) ?: return null
            PanelInfo(
                kind = kind, title = b.name.uppercase(),
                subtitle = (if (kind == PanelKind.STRIKER) "ON STRIKE" else "AT THE OTHER END") + "  •  ${st.battingTeam}",
                stats = listOf("RUNS" to b.runs.toString(), "BALLS" to b.balls.toString(), "4s" to b.fours.toString(), "6s" to b.sixes.toString(), "SR" to f1(b.strikeRate))
            )
        }
        PanelKind.BOWLER -> {
            val b = st.bowler ?: return null
            PanelInfo(
                kind = kind, title = b.name.uppercase(), subtitle = "BOWLING  •  ${st.bowlingTeam}",
                stats = listOf("OVERS" to b.oversText, "MAIDENS" to b.maidens.toString(), "RUNS" to b.runs.toString(), "WKTS" to b.wickets.toString(), "ECON" to f1(b.economy))
            )
        }
        else -> null
    }

    /** Balls faced in the current partnership: legal balls now minus legal balls when the last wicket fell. */
    fun partnership(st: InningsState): PanelInfo? {
        val s = st.striker ?: return null
        val n = st.nonStriker ?: return null
        val last = st.fallOfWickets.lastOrNull()
        val startRuns = last?.teamRuns ?: st.partnershipStartRuns ?: 0
        val startBalls = last?.let { ballsFromOversText(it.oversText, st.ballsPerOver) } ?: st.partnershipStartBalls ?: 0
        val runs = (st.runs - startRuns).coerceAtLeast(0)
        val balls = (st.legalBalls - startBalls).coerceAtLeast(0)
        val wicketNo = st.wickets + 1
        return PanelInfo(
            kind = PanelKind.PARTNERSHIP, title = "PARTNERSHIP",
            subtitle = "${ordinal(wicketNo)} WICKET  •  ${st.battingTeam}",
            stats = listOf("RUNS" to runs.toString(), "BALLS" to balls.toString(), "RATE" to (if (balls == 0) "0.00" else f2(runs * st.ballsPerOver.toDouble() / balls))),
            bat = listOf(
                PanelRow(s.name, c1 = s.runs.toString(), c2 = "(${s.balls})", highlight = true),
                PanelRow(n.name, c1 = n.runs.toString(), c2 = "(${n.balls})")
            )
        )
    }

    fun runRate(st: InningsState): PanelInfo {
        val overs = maxOf(1, st.allBalls.maxOfOrNull { it.overIndex + 1 } ?: 0, st.seedOverRuns.size)
        val runs = IntArray(overs)
        val wk = IntArray(overs)
        st.seedOverRuns.forEachIndexed { i, r -> if (i < overs) runs[i] = r }
        for (b in st.allBalls) {
            if (b.overIndex in 0 until overs) {
                runs[b.overIndex] += b.runsAdded
                if (b.wicket) wk[b.overIndex] += 1
            }
        }
        return PanelInfo(
            kind = PanelKind.RUN_RATE, title = "RUN RATE",
            subtitle = "${st.battingTeam}  •  ${st.scoreText} (${st.oversText} ov)",
            overRuns = runs.toList(), overWickets = wk.toList(), oversLimit = st.oversLimit,
            requiredRate = st.requiredRunRate?.toFloat(), currentRate = st.runRate.toFloat(),
            footer = "CRR ${f2(st.runRate)}" + (st.requiredRunRate?.let { "     RRR ${f2(it)}" } ?: "") +
                (if (st.seedOvers > 0 && st.seedOverRuns.isEmpty()) "     (overs before ${st.seedOvers + 1} were not recorded ball by ball)" else "")
        )
    }

    fun comment(author: String, text: String, highlight: String?): PanelInfo = PanelInfo(
        kind = PanelKind.COMMENT,
        title = author.uppercase(),
        subtitle = highlight ?: "VIEWER COMMENT",
        footer = text
    )

    /** Splits a comment into at most two lines of about [perLine] characters (the second line ends with an ellipsis when cut). */
    fun wrapTwoLines(text: String, perLine: Int): List<String> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val lines = ArrayList<String>()
        var cur = ""
        for (w in words) {
            val t = if (cur.isEmpty()) w else "$cur $w"
            if (t.length > perLine && cur.isNotEmpty()) {
                lines.add(cur)
                cur = w
            } else {
                cur = t
            }
        }
        if (cur.isNotEmpty()) lines.add(cur)
        return if (lines.size <= 2) lines else listOf(lines[0], lines[1].take(perLine - 1) + "\u2026")
    }

    fun ballsFromOversText(text: String, ballsPerOver: Int): Int {
        val parts = text.split('.')
        val o = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val b = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return o * ballsPerOver + b
    }

    private fun ordinal(n: Int): String = when {
        n % 100 in 11..13 -> "${n}TH"
        n % 10 == 1 -> "${n}ST"
        n % 10 == 2 -> "${n}ND"
        n % 10 == 3 -> "${n}RD"
        else -> "${n}TH"
    }
}
