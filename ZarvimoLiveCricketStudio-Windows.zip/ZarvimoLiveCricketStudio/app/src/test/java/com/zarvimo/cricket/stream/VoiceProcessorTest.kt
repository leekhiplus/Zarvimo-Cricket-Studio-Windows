package com.zarvimo.cricket.stream

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

class VoiceProcessorTest {

    private val sr = StreamOptions.AUDIO_SAMPLE_RATE

    private fun rms(a: ShortArray, from: Int, to: Int): Double {
        var s = 0.0
        for (i in from until to) s += a[i].toDouble() * a[i].toDouble()
        return sqrt(s / (to - from)) / 32768.0
    }

    private fun runChunks(p: VoiceProcessor, data: ShortArray) {
        var i = 0
        while (i < data.size) {
            val n = minOf(1024, data.size - i)
            val chunk = data.copyOfRange(i, i + n)
            p.process(chunk, n, 1)
            System.arraycopy(chunk, 0, data, i, n)
            i += n
        }
    }

    @Test
    fun highPassBlocksDc() {
        val b = Biquad().highPass(sr, 95.0, 0.707)
        var y = 0f
        for (i in 0 until 20000) y = b.process(1f)
        assertTrue(abs(y) < 0.01f)
    }

    @Test
    fun noiseReductionLowersSteadyNoise() {
        for (level in 2..3) {
            val rnd = Random(7)
            val x = ShortArray(sr * 4) { (rnd.nextGaussian() * 0.02 * 32768).toInt().toShort() }
            val before = rms(x, sr * 2, x.size)
            val p = VoiceProcessor(sr)
            p.configure(level, 0, false)
            runChunks(p, x)
            val after = rms(x, sr * 2, x.size)
            assertTrue("level $level: before=$before after=$after", after < before * 0.5)
        }
    }

    @Test
    fun noiseReductionKeepsAToneAboveTheNoise() {
        val rnd = Random(11)
        // one second of background noise first (so the noise floor is learned), then a steady voice-like tone on top
        val tone = DoubleArray(sr * 4) { if (it < sr) 0.0 else 0.3 * sin(2 * PI * 1000.0 * it / sr) }
        val x = ShortArray(sr * 4) { ((tone[it] + rnd.nextGaussian() * 0.01) * 32768).toInt().toShort() }
        val p = VoiceProcessor(sr)
        p.configure(2, 0, false)
        runChunks(p, x)
        val after = rms(x, sr * 3, x.size)
        val expected = 0.3 / sqrt(2.0) // the tone is on for the whole measured window
        assertTrue("after=$after expected=$expected", after > expected * 0.8 && after < expected * 1.2)
    }

    @Test
    fun studioVoiceEvensOutLoudnessAndNeverClips() {
        val x = ShortArray(sr * 2) { i ->
            val amp = if (i < sr) 0.03 else 0.5
            (amp * sin(2 * PI * 500.0 * i / sr) * 32768).toInt().toShort()
        }
        val inRatio = 0.5 / 0.03
        val p = VoiceProcessor(sr)
        p.configure(0, 1, false)
        runChunks(p, x)
        val quiet = rms(x, 5000, sr - 1000)
        val loud = rms(x, sr + 8000, x.size)
        assertTrue("ratio=${loud / quiet}", loud / quiet < inRatio * 0.5)
        assertTrue(x.all { abs(it.toInt()) <= 32767 })
    }

    @Test
    fun offLeavesSamplesUntouched() {
        val x = ShortArray(2048) { (it * 13 % 2000 - 1000).toShort() }
        val copy = x.copyOf()
        val p = VoiceProcessor(sr)
        p.configure(0, 0, false)
        p.process(x, x.size, 1)
        assertEquals(copy.toList(), x.toList())
    }
}
