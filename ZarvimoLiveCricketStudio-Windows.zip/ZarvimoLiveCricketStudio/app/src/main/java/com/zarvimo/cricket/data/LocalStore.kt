package com.zarvimo.cricket.data

import android.content.Context
import com.zarvimo.cricket.graphics.GraphicsConfig
import com.zarvimo.cricket.stream.AudioMixSettings
import com.zarvimo.cricket.stream.AutoShowSettings
import com.zarvimo.cricket.stream.StreamSettings
import org.json.JSONObject
import java.io.File

/** Plain JSON files in the app-private directory. Contains no credentials. */
class LocalStore(private val context: Context) {

    private fun dir(name: String) = File(context.filesDir, name).apply { mkdirs() }
    private fun safeName(s: String) = s.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").take(60).ifEmpty { "unnamed" }

    private fun atomicWrite(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    // ---------------------------------------------------------------- matches
    fun saveMatch(m: Json.SavedMatch) = atomicWrite(File(dir("matches"), safeName(m.id) + ".json"), Json.matchToJson(m).toString(1))

    fun listMatches(): List<Json.SavedMatch> =
        dir("matches").listFiles { f -> f.name.endsWith(".json") }.orEmpty().mapNotNull {
            try { Json.matchFromJson(JSONObject(it.readText())) } catch (e: Exception) { null }
        }.sortedByDescending { it.updatedAtMs }

    fun deleteMatch(id: String) { File(dir("matches"), safeName(id) + ".json").delete() }

    // ---------------------------------------------------------------- graphics presets
    fun savePreset(g: GraphicsConfig) = atomicWrite(File(dir("presets"), safeName(g.name) + ".json"), Json.graphicsToJson(g).toString(1))

    fun listPresets(): List<GraphicsConfig> =
        dir("presets").listFiles { f -> f.name.endsWith(".json") }.orEmpty().mapNotNull {
            try { Json.graphicsFromJson(JSONObject(it.readText())) } catch (e: Exception) { null }
        }.sortedBy { it.name.lowercase() }

    fun deletePreset(name: String) { File(dir("presets"), safeName(name) + ".json").delete() }

    // ---------------------------------------------------------------- last-used state
    fun saveGraphics(g: GraphicsConfig) = atomicWrite(File(context.filesDir, "graphics_current.json"), Json.graphicsToJson(g).toString())
    fun loadGraphics(): GraphicsConfig? = try { Json.graphicsFromJson(JSONObject(File(context.filesDir, "graphics_current.json").readText())) } catch (e: Exception) { null }

    fun saveStreamSettings(s: StreamSettings) = atomicWrite(File(context.filesDir, "stream_settings.json"), Json.streamSettingsToJson(s).toString())
    fun loadStreamSettings(): StreamSettings? = try { Json.streamSettingsFromJson(JSONObject(File(context.filesDir, "stream_settings.json").readText())) } catch (e: Exception) { null }

    fun saveAudioMix(a: AudioMixSettings) = atomicWrite(File(context.filesDir, "audio_mix.json"), Json.audioMixToJson(a).toString())
    fun loadAudioMix(): AudioMixSettings? = try { Json.audioMixFromJson(JSONObject(File(context.filesDir, "audio_mix.json").readText())) } catch (e: Exception) { null }

    fun saveAutoShow(a: AutoShowSettings) = atomicWrite(File(context.filesDir, "auto_show.json"), Json.autoShowToJson(a).toString())
    fun loadAutoShow(): AutoShowSettings? = try { Json.autoShowFromJson(JSONObject(File(context.filesDir, "auto_show.json").readText())) } catch (e: Exception) { null }

    /** The official DLS resource table pasted by the scorer (plain text, not shipped with the app). */
    fun saveDlsTableText(text: String) = atomicWrite(File(context.filesDir, "dls_table.txt"), text)
    fun loadDlsTableText(): String? = try { File(context.filesDir, "dls_table.txt").readText().ifBlank { null } } catch (e: Exception) { null }
    fun clearDlsTable() { File(context.filesDir, "dls_table.txt").delete() }

    fun saveAutosave(m: Json.SavedMatch) = atomicWrite(File(context.filesDir, "autosave_match.json"), Json.matchToJson(m).toString())
    fun loadAutosave(): Json.SavedMatch? = try { Json.matchFromJson(JSONObject(File(context.filesDir, "autosave_match.json").readText())) } catch (e: Exception) { null }
}
