package com.zarvimo.cricket.scoring

/** Result of the coin toss as announced before the match. */
enum class TossDecision(val label: String) {
    NONE("Not decided"),
    BAT("Bat first"),
    BOWL("Bowl first")
}

data class MatchSetup(
    val teamA: String = "Team A",
    val teamB: String = "Team B",
    val title: String = "",
    val venue: String = "",
    val oversLimit: Int = 20,
    val ballsPerOver: Int = 6,
    val playersPerSide: Int = 11,
    val widePenalty: Int = 1,
    val noBallPenalty: Int = 1,
    val enforceFreeHit: Boolean = true,
    val allowConsecutiveOvers: Boolean = false,
    val maxOversPerBowler: Int? = null,
    /** Team that won the toss (must equal teamA or teamB); blank = not announced. */
    val tossWinner: String = "",
    val tossDecision: TossDecision = TossDecision.NONE,
    /** Free text shown on the pre-match card, e.g. "3:30 PM". */
    val startTime: String = "",
    /** Playing XI of each side, in batting order (names only; may be empty). Editable at any time, never affects scoring. */
    val squadA: List<String> = emptyList(),
    val squadB: List<String> = emptyList(),
    /** Man of the match: name, the team he plays for (teamA / teamB name, may be blank) and one line of figures. */
    val momName: String = "",
    val momTeam: String = "",
    val momDetail: String = ""
) {
    /** Squad of the named team (matched like the rest of the engine: trimmed, ignoring case). */
    fun squadOf(team: String): List<String> = when {
        team.trim().equals(teamA.trim(), true) -> squadA
        team.trim().equals(teamB.trim(), true) -> squadB
        else -> emptyList()
    }

    val maxWickets: Int get() = (playersPerSide - 1).coerceAtLeast(1)

    /** Team that bats first according to the toss, or null when the toss is not (fully) entered. */
    val battingFirstTeam: String?
        get() {
            val w = tossWinner.trim()
            if (w.isEmpty() || tossDecision == TossDecision.NONE) return null
            val other = if (w.equals(teamA.trim(), true)) teamB.trim() else teamA.trim()
            return if (tossDecision == TossDecision.BAT) w else other
        }

    /** Two lines for the pre-match graphic (null when there is nothing to announce). */
    fun preMatchLines(): Pair<String?, String?> {
        val w = tossWinner.trim()
        val first = if (w.isNotEmpty() && tossDecision != TossDecision.NONE) {
            "TOSS: ${w.uppercase()} WON AND CHOSE TO ${if (tossDecision == TossDecision.BAT) "BAT" else "BOWL"} FIRST"
        } else if (w.isNotEmpty()) {
            "TOSS: ${w.uppercase()} WON THE TOSS"
        } else null
        val parts = ArrayList<String>()
        battingFirstTeam?.let { parts += "${it.uppercase()} BAT FIRST" }
        if (startTime.isNotBlank()) parts += "MATCH STARTS ${startTime.trim().uppercase()}"
        val second = if (parts.isEmpty()) null else parts.joinToString("   \u2022   ")
        return Pair(first, second)
    }

    fun validate(): String? = when {
        teamA.isBlank() || teamB.isBlank() -> "Both team names are required"
        teamA.trim().equals(teamB.trim(), ignoreCase = true) -> "Team names must be different"
        oversLimit !in 1..100 -> "Overs must be between 1 and 100"
        ballsPerOver !in 1..10 -> "Balls per over must be between 1 and 10"
        playersPerSide !in 2..15 -> "Players per side must be between 2 and 15"
        else -> null
    }

    fun innings(target: Int?) = InningsConfig(
        oversLimit = oversLimit,
        ballsPerOver = ballsPerOver,
        maxWickets = maxWickets,
        widePenalty = widePenalty,
        noBallPenalty = noBallPenalty,
        enforceFreeHit = enforceFreeHit,
        allowConsecutiveOvers = allowConsecutiveOvers,
        maxOversPerBowler = maxOversPerBowler,
        target = target
    )
}

/** One innings: its setup plus the ordered event list and a redo stack. */
class InningsData(
    val setup: InningsSetup,
    var targetOverride: Int? = null,
    /** Reduced overs for THIS innings (rain / DLS). Null = the match overs. */
    var oversOverride: Int? = null,
    val events: MutableList<ScoreEvent> = mutableListOf(),
    val redoStack: ArrayDeque<ScoreEvent> = ArrayDeque()
)

/**
 * Holds the whole match. Every mutation is validated by replaying the candidate event list; if the
 * candidate is invalid the original list is left untouched, so the scorecard can never be corrupted.
 */
class MatchSession(val setup: MatchSetup) {

    val innings: MutableList<InningsData> = mutableListOf()
    private var nextId = 1L

    val currentIndex: Int get() = innings.lastIndex
    val current: InningsData? get() = innings.lastOrNull()

    fun newId(): Long = nextId++

    /** Re-seeds the id counter after loading a saved match. */
    fun restoreIds() {
        nextId = (innings.flatMap { it.events }.maxOfOrNull { it.id } ?: 0L) + 1L
    }

    /**
     * Innings are played in pairs: 0-1 is the match, 2-3 the first super over, 4-5 the second one, and so on.
     * The first innings of a pair has no target; the second chases the first (+1) unless a target was overridden (DLS).
     */
    fun isSuperOver(index: Int): Boolean = index >= 2

    /** Rules of one innings: a super over is ONE over with TWO wickets; a reduced innings uses its own overs. */
    fun configFor(index: Int, target: Int?): InningsConfig {
        var c = setup.innings(target)
        if (index >= 2) c = c.copy(oversLimit = 1, maxWickets = 2, maxOversPerBowler = null, allowConsecutiveOvers = true)
        innings.getOrNull(index)?.oversOverride?.let { c = c.copy(oversLimit = it) }
        return c
    }

    fun targetFor(index: Int): Int? {
        if (index % 2 == 0) return null
        val data = innings.getOrNull(index) ?: return null
        data.targetOverride?.let { return it }
        val first = stateOf(index - 1) ?: return null
        return first.runs + 1
    }

    /** Derived state of an innings, or null if the index is invalid / replay fails. */
    fun stateOf(index: Int): InningsState? {
        val data = innings.getOrNull(index) ?: return null
        val target = if (index % 2 == 0) null else (data.targetOverride ?: stateOfFirstRuns(index))
        return when (val r = ScoreEngine.replay(configFor(index, target), data.setup, data.events)) {
            is ReplayResult.Ok -> r.state
            is ReplayResult.Failed -> null
        }
    }

    private fun stateOfFirstRuns(index: Int): Int? {
        val prev = innings.getOrNull(index - 1) ?: return null
        val r = ScoreEngine.replay(configFor(index - 1, null), prev.setup, prev.events)
        return (r as? ReplayResult.Ok)?.state?.runs?.plus(1)
    }

    /** True when the pair that starts at [firstIndex] is finished with the scores level. */
    fun isTied(firstIndex: Int): Boolean {
        val s1 = stateOf(firstIndex) ?: return false
        val s2 = stateOf(firstIndex + 1) ?: return false
        val t = s2.target ?: return false
        return s1.ended && s2.ended && s2.runs == t - 1
    }

    /** A super over may start when the last pair is finished and tied (up to five super overs). */
    val canStartSuperOver: Boolean
        get() = innings.size >= 2 && innings.size % 2 == 0 && innings.size < 12 && isTied(innings.size - 2)

    /** Team that must bat first in the next super over: the side that batted second in the pair just finished. */
    val nextSuperOverBattingTeam: String?
        get() = if (canStartSuperOver) stateOf(innings.lastIndex)?.battingTeam else null

    /**
     * Final result of the match (null while it is still in progress). A tied super over is followed by another one.
     */
    fun finalResult(): String? {
        if (innings.size < 2 || innings.size % 2 != 0) return null
        val f = innings.size - 2
        val s2 = stateOf(f + 1) ?: return null
        if (!s2.ended) return null
        if (isTied(f)) return if (f == 0) "MATCH TIED" else "SUPER OVER TIED"
        val t = s2.target ?: return null
        val win = if (s2.runs >= t) s2.battingTeam else s2.bowlingTeam
        if (f >= 2) return "$win WON THE SUPER OVER"
        return if (s2.runs >= t) {
            val w = s2.wicketsRemaining
            "${s2.battingTeam} WON BY $w WICKET${if (w == 1) "" else "S"}"
        } else {
            val m = t - 1 - s2.runs
            "${s2.bowlingTeam} WON BY $m RUN${if (m == 1) "" else "S"}"
        }
    }

    val currentState: InningsState? get() = if (innings.isEmpty()) null else stateOf(currentIndex)

    fun startInnings(inningsSetup: InningsSetup, targetOverride: Int? = null): OpResult {
        ScoreEngine.validateSetup(inningsSetup)?.let { return OpResult.Error(it) }
        ScoreEngine.seedProblem(setup.innings(null), inningsSetup)?.let { return OpResult.Error(it) }
        val n = innings.size
        if (n > 0) {
            val prev = stateOf(n - 1)
            if (prev == null || !prev.ended) {
                return OpResult.Error(if (n % 2 == 1) "End the first innings before starting the second" else "End the current innings first")
            }
            if (n % 2 == 0) {
                if (n >= 12) return OpResult.Error("Five super overs have already been played")
                if (!isTied(n - 2)) return OpResult.Error("A super over can only be played when the match is tied")
                if (inningsSetup.seed != null) return OpResult.Error("A super over cannot be joined in the middle")
            }
        }
        innings.add(InningsData(inningsSetup, if (n % 2 == 1) targetOverride else null))
        val st = stateOf(currentIndex) ?: run {
            innings.removeAt(innings.lastIndex)
            return OpResult.Error("Could not build innings")
        }
        return OpResult.Ok(st)
    }

    /** Adds an event built with a fresh id. */
    fun add(factory: (Long) -> ScoreEvent): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val event = factory(newId())
        val candidate = data.events + event
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.events.add(event)
                data.redoStack.clear()
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error(r.reason)
        }
    }

    fun undo(): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        if (data.events.isEmpty()) return OpResult.Error("Nothing to undo")
        val removed = data.events.removeAt(data.events.lastIndex)
        data.redoStack.addLast(removed)
        return stateResult()
    }

    fun redo(): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val event = data.redoStack.lastOrNull() ?: return OpResult.Error("Nothing to redo")
        val candidate = data.events + event
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.redoStack.removeLast()
                data.events.add(event)
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error(r.reason)
        }
    }

    /** Replace an earlier event (e.g. correct 1 -> 2 runs). Rejected if later events become invalid. */
    fun replaceEvent(eventId: Long, replacement: (Long) -> ScoreEvent): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val idx = data.events.indexOfFirst { it.id == eventId }
        if (idx < 0) return OpResult.Error("Event not found")
        val candidate = data.events.toMutableList()
        candidate[idx] = replacement(eventId)
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.events[idx] = candidate[idx]
                data.redoStack.clear()
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error("Edit rejected: ${r.reason}")
        }
    }

    fun deleteEvent(eventId: Long): OpResult {
        val data = current ?: return OpResult.Error("No innings in progress")
        val idx = data.events.indexOfFirst { it.id == eventId }
        if (idx < 0) return OpResult.Error("Event not found")
        val candidate = data.events.toMutableList()
        candidate.removeAt(idx)
        return when (val r = replayCandidate(currentIndex, candidate)) {
            is ReplayResult.Ok -> {
                data.events.removeAt(idx)
                data.redoStack.clear()
                OpResult.Ok(r.state)
            }
            is ReplayResult.Failed -> OpResult.Error("Delete rejected: ${r.reason}")
        }
    }

    fun setTargetOverride(index: Int, target: Int?): OpResult {
        val data = innings.getOrNull(index) ?: return OpResult.Error("Innings not found")
        if (index % 2 == 0) return OpResult.Error("The first innings of a pair has no target")
        if (target != null && target < 1) return OpResult.Error("Target must be at least 1")
        val old = data.targetOverride
        data.targetOverride = target
        val st = stateOf(index)
        if (st == null) {
            data.targetOverride = old
            return OpResult.Error("Target would invalidate the recorded events")
        }
        return OpResult.Ok(st)
    }

    /** Reduced overs for one innings (rain / DLS). Rejected when the recorded balls would no longer fit. */
    fun setOversOverride(index: Int, overs: Int?): OpResult {
        val data = innings.getOrNull(index) ?: return OpResult.Error("Innings not found")
        if (index >= 2) return OpResult.Error("A super over is always one over")
        if (overs != null && overs !in 1..setup.oversLimit) return OpResult.Error("Overs must be between 1 and ${setup.oversLimit}")
        val old = data.oversOverride
        data.oversOverride = overs
        val st = stateOf(index)
        if (st == null || (index == 1 && stateOf(0) == null)) {
            data.oversOverride = old
            return OpResult.Error("These overs do not fit the balls already recorded")
        }
        return OpResult.Ok(st)
    }

    private fun stateResult(): OpResult {
        val st = currentState ?: return OpResult.Error("State could not be rebuilt")
        return OpResult.Ok(st)
    }

    private fun replayCandidate(index: Int, events: List<ScoreEvent>): ReplayResult {
        val data = innings[index]
        val target = if (index % 2 == 0) null else (data.targetOverride ?: stateOfFirstRuns(index))
        return ScoreEngine.replay(configFor(index, target), data.setup, events)
    }
}

/** Turns pasted text ("1. Babar Azam (c)\n2) Rizwan (wk)\n...") into clean, de-duplicated player names. */
object SquadParser {
    const val MAX_PLAYERS = 15

    fun parse(text: String): List<String> {
        val seen = HashSet<String>()
        val out = ArrayList<String>()
        for (raw in text.split('\n', '\r', ';')) {
            val name = clean(raw)
            if (name.isEmpty()) continue
            if (seen.add(name.lowercase())) out += name
        }
        return out.take(MAX_PLAYERS)
    }

    /** Removes list numbering such as "1.", "2)", "3-" and extra spaces. */
    fun clean(raw: String): String =
        raw.trim().replace(Regex("^\\(?\\d{1,2}\\s*[.)\\-:]\\s*"), "").replace(Regex("\\s+"), " ").trim()

    /** Adds one name (ignored when blank, duplicate or the squad is full). */
    fun add(list: List<String>, raw: String): List<String> {
        val n = clean(raw)
        if (n.isEmpty() || list.size >= MAX_PLAYERS || list.any { it.equals(n, true) }) return list
        return list + n
    }

    fun move(list: List<String>, index: Int, delta: Int): List<String> {
        val to = index + delta
        if (index !in list.indices || to !in list.indices) return list
        val m = list.toMutableList()
        val x = m.removeAt(index)
        m.add(to, x)
        return m
    }
}
