package com.zarvimo.cricket.stream

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Crowd and effect sounds that can be played into the stream. */
enum class Sfx(val label: String) {
    CHEER("Cheer"),
    ROAR("Big roar"),
    APPLAUSE("Applause"),
    OOH("Oh no!"),
    WHISTLE("Whistle"),
    HORN("Air horn"),
    DRUMROLL("Drum roll"),
    /** Endless stadium murmur used as a quiet background bed. */
    AMBIENCE("Crowd atmosphere"),
    /** Used for the operator's own extra pads; never generated. */
    CUSTOM("My sound")
}

/**
 * Makes every sound from maths, so the app needs no audio files and no licences. The sounds are generic (filtered noise,
 * claps, voices and tones), good as stadium atmosphere; real recordings sound richer. Output: 16-bit interleaved stereo at
 * 44.1 kHz. Everything is deterministic (fixed random seeds), so the same sound is produced every time.
 */
object CrowdSynth {
    const val RATE = 44100

    private class Rng(seed: Long) {
        private var s = seed xor 0x5DEECE66DL
        fun next(): Float {
            s = s xor (s shl 13); s = s xor (s ushr 7); s = s xor (s shl 17)
            return ((s ushr 11) and 0xFFFFFF).toInt() / 8388608f - 1f
        }
        fun unit(): Float = (next() + 1f) * 0.5f
    }

    /** RBJ band-pass filter (constant skirt gain). */
    private class Band(freq: Double, q: Double) {
        private val b0: Double; private val b2: Double; private val a1: Double; private val a2: Double
        private var x1 = 0.0; private var x2 = 0.0; private var y1 = 0.0; private var y2 = 0.0
        init {
            val w = 2 * PI * freq / RATE
            val alpha = sin(w) / (2 * q)
            val a0 = 1 + alpha
            b0 = alpha / a0; b2 = -alpha / a0
            a1 = -2 * cos(w) / a0; a2 = (1 - alpha) / a0
        }
        fun process(x: Double): Double {
            val y = b0 * x + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = x; y2 = y1; y1 = y
            return y
        }
    }

    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3 - 2 * t) }

    /** Scales so the loudest sample reaches [level] (0..1) and converts to interleaved 16-bit stereo. */
    private fun finish(l: FloatArray, r: FloatArray, level: Float): ShortArray {
        var peak = 1e-6f
        for (i in l.indices) { peak = max(peak, max(abs(l[i]), abs(r[i]))) }
        val k = level * 32767f / peak
        val out = ShortArray(l.size * 2)
        for (i in l.indices) {
            out[2 * i] = (l[i] * k).toInt().coerceIn(-32768, 32767).toShort()
            out[2 * i + 1] = (r[i] * k).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    /** Murmur of thousands of voices: two band-passed noises with a slow, uneven swell. */
    private fun crowdBed(n: Int, lowCentre: Double, seed: Long, wobble: Float): Pair<FloatArray, FloatArray> {
        val out = arrayOf(FloatArray(n), FloatArray(n))
        for (ch in 0..1) {
            val rng = Rng(seed + ch * 7919L)
            val b1 = Band(lowCentre, 0.7)
            val b2 = Band(lowCentre * 2.4, 0.9)
            val b3 = Band(lowCentre * 4.5, 1.2)
            val ph = ch * 1.7
            for (i in 0 until n) {
                val t = i.toDouble() / RATE
                val x = rng.next().toDouble()
                val am = 1.0 + wobble * (0.5 * sin(2 * PI * 0.55 * t + ph) + 0.3 * sin(2 * PI * 1.3 * t + 2 * ph) + 0.2 * sin(2 * PI * 2.9 * t))
                out[ch][i] = ((b1.process(x) * 1.0 + b2.process(x) * 0.7 + b3.process(x) * 0.35) * am).toFloat()
            }
        }
        return Pair(out[0], out[1])
    }

    private fun swell(t: Float, attack: Float, hold: Float, tau: Float): Float {
        val up = smooth(t / attack)
        val down = if (t <= hold) 1f else exp(-(t - hold) / tau)
        return up * down
    }

    fun render(kind: Sfx): ShortArray = when (kind) {
        Sfx.CHEER -> cheer(4.2f, 0.45f, 1.4f, 0.9f, 650.0, 11L, 0.75f)
        Sfx.ROAR -> cheer(6.5f, 0.9f, 3.0f, 1.3f, 480.0, 23L, 0.9f)
        Sfx.APPLAUSE -> applause()
        Sfx.OOH -> ooh()
        Sfx.WHISTLE -> whistle()
        Sfx.HORN -> horn()
        Sfx.DRUMROLL -> drumroll()
        Sfx.AMBIENCE -> ambience()
        Sfx.CUSTOM -> ShortArray(2)
    }

    private fun cheer(sec: Float, attack: Float, hold: Float, tau: Float, centre: Double, seed: Long, level: Float): ShortArray {
        val n = (sec * RATE).toInt()
        val (l, r) = crowdBed(n, centre, seed, 0.35f)
        for (i in 0 until n) {
            val e = swell(i.toFloat() / RATE, attack, hold, tau)
            l[i] *= e; r[i] *= e
        }
        return finish(l, r, level)
    }

    private fun applause(): ShortArray {
        val sec = 4.6f
        val n = (sec * RATE).toInt()
        val l = FloatArray(n + 800); val r = FloatArray(n + 800)
        val rng = Rng(31L)
        val clapLen = 360
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val density = 260f * smooth(t / 0.6f) * (if (t < 2.4f) 1f else exp(-(t - 2.4f) / 0.9f))
            if (rng.unit() < density / RATE) {
                val amp = 0.35f + 0.65f * rng.unit()
                val pan = rng.unit()
                val band = Band(1400.0 + 2200.0 * rng.unit(), 1.1)
                for (k in 0 until clapLen) {
                    val v = (band.process(rng.next().toDouble()) * exp(-k / 55.0) * amp).toFloat()
                    l[i + k] += v * (1f - pan); r[i + k] += v * pan
                }
            }
        }
        return finish(l.copyOf(n), r.copyOf(n), 0.8f)
    }

    /** A falling "ooooh": several slightly detuned voices gliding down, over a little crowd noise. */
    private fun ooh(): ShortArray {
        val sec = 2.8f
        val n = (sec * RATE).toInt()
        val (bl, br) = crowdBed(n, 420.0, 47L, 0.2f)
        val l = FloatArray(n); val r = FloatArray(n)
        for (v in 0 until 7) {
            val f0 = 190.0 * (1.0 + 0.05 * v) * (1.0 + 0.01 * ((v * 37) % 5))
            var phase = 0.0
            val pan = v / 6f
            for (i in 0 until n) {
                val t = i.toDouble() / RATE
                val f = f0 * (1.0 - 0.32 * smooth((t / 2.2).toFloat())) * (1.0 + 0.012 * sin(2 * PI * (5.0 + v * 0.3) * t))
                phase += 2 * PI * f / RATE
                var s = 0.0
                for (h in 1..6) s += sin(h * phase) / h.toDouble().pow(1.2)
                val e = (smooth((t / 0.18).toFloat()) * exp(-max(0.0, t - 0.6) / 0.9)).toFloat()
                l[i] += (s * e * (1 - pan)).toFloat(); r[i] += (s * e * pan).toFloat()
            }
        }
        for (i in 0 until n) {
            val e = swell(i.toFloat() / RATE, 0.2f, 0.5f, 0.9f)
            l[i] = l[i] * 0.55f + bl[i] * 0.25f * e
            r[i] = r[i] * 0.55f + br[i] * 0.25f * e
        }
        return finish(l, r, 0.7f)
    }

    private fun whistle(): ShortArray {
        val n = (0.95f * RATE).toInt()
        val rng = Rng(61L)
        val l = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val trill = 0.65 + 0.35 * sin(2 * PI * 26.0 * t)
            phase += 2 * PI * (2850.0 + 140.0 * sin(2 * PI * 5.0 * t)) / RATE
            val e = smooth((t / 0.02).toFloat()) * (if (t < 0.8) 1f else (1 - ((t - 0.8) / 0.15).toFloat()).coerceAtLeast(0f))
            l[i] = ((sin(phase) * trill + 0.12 * rng.next()) * e).toFloat()
        }
        return finish(l, l.copyOf(), 0.6f)
    }

    private fun horn(): ShortArray {
        val n = (1.5f * RATE).toInt()
        val l = FloatArray(n)
        val freqs = doubleArrayOf(311.0, 392.0, 466.0, 622.0)
        val ph = DoubleArray(freqs.size)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            var s = 0.0
            for (k in freqs.indices) {
                ph[k] += 2 * PI * freqs[k] / RATE
                var saw = 0.0
                for (h in 1..7) saw += sin(h * ph[k]) / h
                s += saw
            }
            val e = smooth((t / 0.01).toFloat()) * (if (t < 1.25) 1f else (1 - ((t - 1.25) / 0.25).toFloat()).coerceAtLeast(0f))
            l[i] = (s * e).toFloat()
        }
        return finish(l, l.copyOf(), 0.75f)
    }

    private fun drumroll(): ShortArray {
        val sec = 3.2f
        val n = (sec * RATE).toInt()
        val l = FloatArray(n + 9000); val r = FloatArray(n + 9000)
        val rng = Rng(83L)
        var t = 0.0
        var side = 0
        while (t < 2.9) {
            val p = (t / 2.9).toFloat()
            val rate = 12.0 + 20.0 * p
            val amp = 0.25f + 0.75f * p * p
            val band = Band(190.0 + 40.0 * rng.unit(), 0.9)
            val start = (t * RATE).toInt()
            for (k in 0 until 2600) {
                val v = (band.process(rng.next().toDouble()) * exp(-k / 520.0) * amp).toFloat()
                if (side == 0) { l[start + k] += v; r[start + k] += v * 0.6f } else { r[start + k] += v; l[start + k] += v * 0.6f }
            }
            side = 1 - side
            t += 1.0 / rate
        }
        // final accent hit
        val band = Band(150.0, 0.8)
        val start = (2.95 * RATE).toInt()
        for (k in 0 until 8000) {
            val v = (band.process(rng.next().toDouble()) * exp(-k / 1800.0) * 1.6f).toFloat()
            l[start + k] += v; r[start + k] += v
        }
        return finish(l.copyOf(n), r.copyOf(n), 0.85f)
    }

    /** 12 s of murmur whose end fades into its start, so it can loop without a click. */
    private fun ambience(): ShortArray {
        val n = 12 * RATE
        val x = (0.5f * RATE).toInt()
        val (bl, br) = crowdBed(n + x, 520.0, 97L, 0.5f)
        val l = FloatArray(n); val r = FloatArray(n)
        for (i in 0 until n) {
            var a = bl[i]; var b = br[i]
            if (i < x) {
                val f = i.toFloat() / x
                a = a * f + bl[n + i] * (1 - f)
                b = b * f + br[n + i] * (1 - f)
            }
            l[i] = a; r[i] = b
        }
        return finish(l, r, 0.55f)
    }
}

/**
 * The sound of each pad: the operator's real recording when one has been chosen, otherwise the generated one.
 * Decoded sounds are cached, so a pad answers instantly the second time.
 */
object SfxLibrary {
    private val cache = HashMap<Sfx, ShortArray>()
    private val fileCache = HashMap<String, ShortArray>()
    private var files: Map<String, String> = emptyMap()

    /** kind name -> file path. Called whenever the audio settings change. */
    fun setFiles(m: Map<String, String>) {
        synchronized(cache) {
            if (m != files) {
                files = m
                cache.clear()
            }
        }
    }

    fun hasFile(kind: Sfx): Boolean = synchronized(cache) { files.containsKey(kind.name) }

    fun get(kind: Sfx): ShortArray = synchronized(cache) {
        cache.getOrPut(kind) { files[kind.name]?.let { loadFile(it) } ?: CrowdSynth.render(kind) }
    }

    /** Decodes a real audio file to 44.1 kHz stereo (null when it cannot be read). */
    fun loadFile(path: String): ShortArray? = synchronized(fileCache) {
        fileCache[path] ?: SfxDecoder.decode(path)?.also { fileCache[path] = it }
    }

    fun forget(path: String) { synchronized(fileCache) { fileCache.remove(path) } }
}

/** Plays several sounds at the same time and hands the mixed result to the audio mixer, 44.1 kHz stereo. */
class SfxPlayer {
    private class Voice(val kind: Sfx, val data: ShortArray, val gain: Float, val loop: Boolean) { var pos = 0 }

    private val lock = Any()
    private val voices = ArrayList<Voice>()
    private var acc = IntArray(0)

    /** True while at least one effect other than the background atmosphere is sounding. */
    val oneShotActive: Boolean get() = synchronized(lock) { voices.any { !it.loop } }

    fun play(kind: Sfx, data: ShortArray, gain: Float, loop: Boolean = false) {
        synchronized(lock) {
            if (loop) voices.removeAll { it.kind == kind }
            voices += Voice(kind, data, gain, loop)
        }
    }

    fun stop(kind: Sfx) { synchronized(lock) { voices.removeAll { it.kind == kind } } }
    fun stopOneShots() { synchronized(lock) { voices.removeAll { !it.loop } } }
    fun stopAll() { synchronized(lock) { voices.clear() } }

    /** Mixes [frames] stereo frames into [dst]. Returns [frames] when anything sounded, otherwise 0 (dst untouched). */
    fun pullStereo(dst: ShortArray, frames: Int): Int = synchronized(lock) {
        if (voices.isEmpty()) return 0
        val n = frames * 2
        if (acc.size < n) acc = IntArray(n)
        java.util.Arrays.fill(acc, 0, n, 0)
        val it = voices.iterator()
        while (it.hasNext()) {
            val v = it.next()
            var i = 0
            while (i < n) {
                if (v.pos >= v.data.size) {
                    if (v.loop) v.pos = 0 else break
                }
                acc[i] += (v.data[v.pos] * v.gain).toInt()
                v.pos++
                i++
            }
            if (!v.loop && v.pos >= v.data.size) it.remove()
        }
        for (i in 0 until n) dst[i] = PcmMath.clamp16(acc[i])
        frames
    }
}
