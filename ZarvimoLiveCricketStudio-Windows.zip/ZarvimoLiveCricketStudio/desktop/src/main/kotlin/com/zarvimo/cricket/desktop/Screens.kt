package com.zarvimo.cricket.desktop

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.scoring.DismissalType
import com.zarvimo.cricket.scoring.ExtraType
import com.zarvimo.cricket.scoring.TossDecision
import com.zarvimo.cricket.stream.ResolutionProfile
import com.zarvimo.cricket.stream.StreamOptions
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

// ------------------------------------------------------------------------------------------------ root

@Composable
fun App(state: AppState) {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Match", "Scoring", "Stream")

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // left: the live picture, exactly what is sent on air
                Column(Modifier.weight(0.45f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Live picture (same as on air)", fontSize = 13.sp, color = Color.Gray)
                    Preview(state)
                    val st = state.session?.currentState
                    if (st != null) {
                        Text("${st.battingTeam}  ${st.scoreText}  (${st.oversText}/${st.oversLimit})", fontSize = 20.sp)
                    }
                    if (state.message.isNotBlank()) {
                        Text(state.message, color = Color(0xFFFF8A80), fontSize = 14.sp)
                    }
                    Text("Stream: ${state.streamer.status}", fontSize = 14.sp, color = if (state.streamer.live) Color(0xFF69F0AE) else Color.Gray)
                }
                // right: tabs
                Column(Modifier.weight(0.55f).fillMaxHeight()) {
                    TabRow(selectedTabIndex = tab) {
                        titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        when (tab) {
                            0 -> MatchTab(state)
                            1 -> ScoringTab(state)
                            else -> StreamTab(state)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Preview(state: AppState) {
    val overlay = state.overlay()
    val bg = state.bgImage
    val bmp = remember(overlay, bg) { OverlayPainter.render(overlay, 960, 540, bg).toComposeImageBitmap() }
    Image(bmp, contentDescription = null, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
}

// ------------------------------------------------------------------------------------------------ helpers

@Composable
private fun Field(label: String, value: String, enabled: Boolean = true, modifier: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, enabled = enabled, modifier = modifier)
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
private fun Choice(selected: Boolean, label: String, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(label) }
    else OutlinedButton(onClick = onClick) { Text(label) }
}

@Composable
private fun <T> Dropdown(label: String, current: String, items: List<T>, itemLabel: (T) -> String, onPick: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text("$label: $current") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { item ->
                DropdownMenuItem(text = { Text(itemLabel(item)) }, onClick = { onPick(item); open = false })
            }
        }
    }
}

private fun pickFile(title: String, save: Boolean, defaultName: String = ""): File? {
    val dlg = FileDialog(null as Frame?, title, if (save) FileDialog.SAVE else FileDialog.LOAD)
    if (defaultName.isNotEmpty()) dlg.file = defaultName
    dlg.isVisible = true
    val f = dlg.file ?: return null
    return File(dlg.directory, f)
}

// ------------------------------------------------------------------------------------------------ match

@Composable
private fun MatchTab(state: AppState) {
    val locked = state.session != null
    val s = state.setup

    Section("Teams and match") {
        Field("Team A", s.teamA, !locked) { state.setup = s.copy(teamA = it); state.touch() }
        Field("Team B", s.teamB, !locked) { state.setup = s.copy(teamB = it); state.touch() }
        Field("Match title (shown on screen)", s.title, !locked) { state.setup = s.copy(title = it); state.touch() }
        Field("Venue", s.venue, !locked) { state.setup = s.copy(venue = it); state.touch() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Overs", s.oversLimit.toString(), !locked, Modifier.width(120.dp)) { v ->
                v.toIntOrNull()?.let { state.setup = s.copy(oversLimit = it); state.touch() }
            }
            Field("Players per side", s.playersPerSide.toString(), !locked, Modifier.width(160.dp)) { v ->
                v.toIntOrNull()?.let { state.setup = s.copy(playersPerSide = it); state.touch() }
            }
            Field("Start time (text)", s.startTime, !locked, Modifier.width(200.dp)) { state.setup = s.copy(startTime = it); state.touch() }
        }
    }

    Section("Toss") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice(s.tossWinner.isBlank(), "No toss yet") { if (!locked) { state.setup = s.copy(tossWinner = "", tossDecision = TossDecision.NONE); state.touch() } }
            Choice(s.tossWinner.isNotBlank() && s.tossWinner == s.teamA, s.teamA.ifBlank { "Team A" }) { if (!locked) { state.setup = s.copy(tossWinner = s.teamA); state.touch() } }
            Choice(s.tossWinner.isNotBlank() && s.tossWinner == s.teamB, s.teamB.ifBlank { "Team B" }) { if (!locked) { state.setup = s.copy(tossWinner = s.teamB); state.touch() } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TossDecision.values().forEach { d ->
                Choice(s.tossDecision == d, d.label) { if (!locked) { state.setup = s.copy(tossDecision = d); state.touch() } }
            }
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!locked) Button(onClick = { state.createMatch() }) { Text("Create match") }
        else OutlinedButton(onClick = { state.resetMatch() }) { Text("Reset match (clears the score)") }
        OutlinedButton(onClick = {
            pickFile("Save match", true, "match.json")?.let { state.saveMatch(it) }
        }) { Text("Save match...") }
        OutlinedButton(onClick = {
            pickFile("Open match", false)?.let { state.loadMatch(it) }
        }) { Text("Open match...") }
    }
    if (locked) Text("Team names are locked while a match is running. Use Reset to change them.", fontSize = 12.sp, color = Color.Gray)
}

// ------------------------------------------------------------------------------------------------ scoring

@Composable
private fun ScoringTab(state: AppState) {
    val session = state.session
    if (session == null) {
        Text("Create the match first (Match tab).")
        return
    }
    if (state.canStartInnings()) {
        StartInningsForm(state)
        session.finalResult()?.let { Text(it, fontSize = 18.sp) }
        return
    }
    val st = session.currentState
    if (st == null) {
        Text("No innings yet.")
        return
    }
    session.finalResult()?.let { Text("RESULT: $it", fontSize = 18.sp, color = Color(0xFFFFD54F)) }

    if (st.ended) {
        Text("Innings ended: ${st.endReason ?: ""}")
    }

    var showWicket by remember { mutableStateOf(false) }

    // bowler / batter prompts
    if (st.bowlerRequired) {
        var name by remember(st.legalBalls, st.runs) { mutableStateOf("") }
        Section("New bowler for the next over") {
            Field("Bowler name", name) { name = it }
            Button(onClick = { state.setBowler(name) }) { Text("Set bowler") }
        }
    }
    if (st.batterRequired) {
        var name by remember(st.wickets) { mutableStateOf("") }
        Section("New batter") {
            Field("Incoming batter name", name) { name = it }
            Button(onClick = { state.batterIn(name) }) { Text("Send in batter") }
        }
    }

    if (st.canScoreNextBall) {
        Section("Next ball${if (st.freeHit) "  (FREE HIT)" else ""}") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ExtraType.values().forEach { e ->
                    Choice(state.extraMode == e, if (e == ExtraType.NONE) "Normal" else e.label) { state.extraMode = e }
                }
            }
            val note = when (state.extraMode) {
                ExtraType.NONE -> "Runs off the bat"
                ExtraType.WIDE -> "Extra runs run on top of the wide (0 = just the wide)"
                ExtraType.NO_BALL -> "Runs off the bat on the no-ball (0 = just the no-ball)"
                ExtraType.BYE -> "Byes run"
                ExtraType.LEG_BYE -> "Leg-byes run"
            }
            Text(note, fontSize = 12.sp, color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0, 1, 2, 3, 4, 5, 6).forEach { n ->
                    Button(onClick = { state.ball(n) }, modifier = Modifier.width(64.dp)) { Text("$n") }
                }
            }
            Button(
                onClick = { showWicket = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
            ) { Text("WICKET...") }
        }
    }

    Section("Corrections") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { state.undo() }) { Text("Undo") }
            OutlinedButton(onClick = { state.redo() }) { Text("Redo") }
            OutlinedButton(onClick = { state.swapStrike() }) { Text("Swap strike") }
            OutlinedButton(onClick = { state.penalty(5) }) { Text("+5 penalty") }
            OutlinedButton(onClick = { state.endInnings() }) { Text("End innings") }
        }
    }

    val batters = listOfNotNull(st.striker?.let { "* ${it.name}  ${it.scoreText}" }, st.nonStriker?.let { "  ${it.name}  ${it.scoreText}" })
    Section("At the crease") {
        batters.forEach { Text(it) }
        st.bowler?.let { Text("Bowler: ${it.name}  ${it.figuresText}") }
        if (st.recentBalls.isNotEmpty()) Text("Recent: " + st.recentBalls.joinToString("  ") { it.label })
        st.requiredRuns?.let { Text("Need $it from ${st.ballsRemaining} balls") }
    }

    if (showWicket) WicketDialog(state, onClose = { showWicket = false })
}

@Composable
private fun StartInningsForm(state: AppState) {
    val bat = state.nextBattingTeam()
    val bowl = state.otherTeam(bat)
    var striker by remember(bat) { mutableStateOf("") }
    var nonStriker by remember(bat) { mutableStateOf("") }
    var bowler by remember(bat) { mutableStateOf("") }
    Section("Start innings: $bat batting, $bowl bowling") {
        Field("Striker", striker) { striker = it }
        Field("Non-striker", nonStriker) { nonStriker = it }
        Field("Opening bowler", bowler) { bowler = it }
        Button(onClick = { state.startInnings(striker, nonStriker, bowler) }) { Text("Start innings") }
    }
}

@Composable
private fun WicketDialog(state: AppState, onClose: () -> Unit) {
    var type by remember { mutableStateOf(DismissalType.BOWLED) }
    var strikerOut by remember { mutableStateOf(true) }
    var fielder by remember { mutableStateOf("") }
    var incoming by remember { mutableStateOf("") }
    var runs by remember { mutableStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Wicket") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Dropdown("How out", type.label, DismissalType.values().toList(), { it.label }) { type = it }
                if (type.canDismissNonStriker) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Choice(strikerOut, "Striker out") { strikerOut = true }
                        Choice(!strikerOut, "Non-striker out") { strikerOut = false }
                    }
                }
                if (type.allowsRuns) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Runs completed:")
                        (0..3).forEach { n -> Choice(runs == n, "$n") { runs = n } }
                    }
                }
                Field("Fielder (optional)", fielder) { fielder = it }
                Field("Incoming batter (can be left empty and entered next)", incoming) { incoming = it }
            }
        },
        confirmButton = {
            Button(onClick = {
                state.wicket(type, strikerOut || !type.canDismissNonStriker, fielder, incoming, runs)
                onClose()
            }) { Text("Record wicket") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

// ------------------------------------------------------------------------------------------------ stream

@Composable
private fun StreamTab(state: AppState) {
    var server by remember { mutableStateOf(StreamOptions.YOUTUBE_RTMP) }
    var key by remember { mutableStateOf("") }
    var profile by remember { mutableStateOf(ResolutionProfile.P720) }
    var fps by remember { mutableStateOf(30) }
    var kbps by remember { mutableStateOf(ResolutionProfile.P720.defaultKbps.toString()) }
    var mic by remember { mutableStateOf<String?>(null) }
    var ffmpegPath by remember { mutableStateOf("") }
    var record by remember { mutableStateOf(false) }
    val streamer = state.streamer

    val ffmpeg = remember(ffmpegPath) { streamer.findFfmpeg(ffmpegPath) }

    Section("Server") {
        Field("Server URL (rtmp:// or rtmps://)", server) { server = it }
        OutlinedTextField(
            value = key, onValueChange = { key = it }, label = { Text("Stream key (kept in memory only)") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { server = StreamOptions.YOUTUBE_RTMP }) { Text("YouTube RTMP") }
            OutlinedButton(onClick = { server = StreamOptions.YOUTUBE_RTMPS }) { Text("YouTube RTMPS") }
        }
    }

    Section("Quality") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ResolutionProfile.values().forEach { p ->
                Choice(profile == p, p.label.substringBefore(' ')) { profile = p; kbps = p.defaultKbps.toString() }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("FPS:")
            StreamOptions.fpsOptions.forEach { f -> Choice(fps == f, "$f") { fps = f } }
        }
        Field("Video bitrate (kbps)", kbps, modifier = Modifier.width(220.dp)) { kbps = it.filter { c -> c.isDigit() } }
    }

    Section("Background picture and sound") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pickFile("Background picture", false)?.let { state.loadBackground(it) } }) { Text("Choose picture...") }
            if (state.bgImage != null) OutlinedButton(onClick = { state.clearBackground() }) { Text("Use built-in stadium") }
        }
        if (state.bgImagePath.isNotBlank()) Text(state.bgImagePath, fontSize = 12.sp, color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Dropdown("Microphone", mic ?: "None (silent)", listOf<String?>(null) + streamer.devices, { it ?: "None (silent)" }) { mic = it }
            OutlinedButton(onClick = { ffmpeg?.let { streamer.refreshDevices(it) } }, enabled = ffmpeg != null) { Text("Find microphones") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice(record, if (record) "Recording a copy: ON" else "Record a copy: OFF") { record = !record }
        }
    }

    Section("FFmpeg") {
        if (ffmpeg != null) Text("FFmpeg found: $ffmpeg", fontSize = 12.sp, color = Color(0xFF69F0AE))
        else {
            Text("FFmpeg was not found. Install FFmpeg, or paste the full path to ffmpeg.exe below.", color = Color(0xFFFF8A80), fontSize = 13.sp)
            Field("Path to ffmpeg.exe", ffmpegPath) { ffmpegPath = it }
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!streamer.live) {
            Button(
                enabled = ffmpeg != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                onClick = {
                    val rate = profile.clampBitrate(kbps.toIntOrNull() ?: profile.defaultKbps)
                    val recPath = if (record) {
                        val dir = File(System.getProperty("user.home"), "Videos/Zarvimo").also { it.mkdirs() }
                        File(dir, "match-${System.currentTimeMillis() / 1000}.mp4").absolutePath
                    } else null
                    streamer.start(
                        ffmpeg!!,
                        DesktopStreamConfig(server, key, profile.width, profile.height, fps, rate, 128, mic, recPath),
                        overlay = { state.liveOverlay },
                        bg = { state.bgImage }
                    )
                }
            ) { Text("GO LIVE") }
        } else {
            Button(onClick = { streamer.stop() }) { Text("STOP LIVE") }
        }
    }
    Text(
        "Tip: do a private/unlisted test stream first. The video on air is the picture on the left.",
        fontSize = 12.sp, color = Color.Gray
    )
}
