package com.zarvimo.cricket.scoring

import com.zarvimo.cricket.data.Json
import com.zarvimo.cricket.graphics.PanelBuilder
import com.zarvimo.cricket.graphics.PanelKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SquadTest {

    @Test fun parse_removesNumbering_blanks_andDuplicates() {
        val text = "1. Fakhar Zaman\n2) Babar Azam (c)\n\n  3 - Mohammad Rizwan (wk)  \nbabar azam (C)\r\nShaheen Afridi;Naseem Shah"
        assertEquals(
            listOf("Fakhar Zaman", "Babar Azam (c)", "Mohammad Rizwan (wk)", "Shaheen Afridi", "Naseem Shah"),
            SquadParser.parse(text)
        )
    }

    @Test fun parse_keepsDigitsInsideNames_andLimitsToFifteen() {
        assertEquals(listOf("Player 7"), SquadParser.parse("Player 7"))
        val many = (1..20).joinToString("\n") { "Name$it" }
        assertEquals(15, SquadParser.parse(many).size)
    }

    @Test fun add_ignoresBlankDuplicateAndFullSquad() {
        var l = emptyList<String>()
        l = SquadParser.add(l, "  Ali  ")
        l = SquadParser.add(l, "ali")
        l = SquadParser.add(l, "   ")
        assertEquals(listOf("Ali"), l)
        var full = (1..15).map { "P$it" }
        full = SquadParser.add(full, "Extra")
        assertEquals(15, full.size)
    }

    @Test fun move_reordersAndIgnoresOutOfRange() {
        val l = listOf("A", "B", "C")
        assertEquals(listOf("B", "A", "C"), SquadParser.move(l, 1, -1))
        assertEquals(l, SquadParser.move(l, 0, -1))
        assertEquals(l, SquadParser.move(l, 2, 1))
    }

    @Test fun squadOf_matchesTeamNameIgnoringCase() {
        val s = MatchSetup(teamA = "Pakistan", teamB = "England", squadA = listOf("Babar"), squadB = listOf("Root"))
        assertEquals(listOf("Babar"), s.squadOf(" pakistan "))
        assertEquals(listOf("Root"), s.squadOf("ENGLAND"))
        assertTrue(s.squadOf("India").isEmpty())
    }

    @Test fun json_roundTrip_keepsSquadsAndOldFilesStillLoad() {
        val s = MatchSetup(teamA = "A", teamB = "B", squadA = listOf("x", "y"), squadB = listOf("z"))
        val back = Json.setupFromJson(Json.setupToJson(s))
        assertEquals(listOf("x", "y"), back.squadA)
        assertEquals(listOf("z"), back.squadB)
        val old = Json.setupToJson(s)
        old.remove("squadA"); old.remove("squadB")
        assertTrue(Json.setupFromJson(old).squadA.isEmpty())
    }

    @Test fun playingXiPanel_hasBothTeamsInOrder() {
        val s = MatchSetup(teamA = "A", teamB = "B", squadA = listOf("a1", "a2"), squadB = listOf("b1"))
        val p = PanelBuilder.playingXi(s, 1, 2)
        assertEquals(PanelKind.PLAYING_XI, p.kind)
        assertEquals(listOf("a1", "a2"), p.bat.map { it.name })
        assertEquals(listOf("1", "2"), p.bat.map { it.c1 })
        assertEquals(listOf("b1"), p.bowl.map { it.name })
        assertEquals("A", p.batHeader.first())
    }
}
