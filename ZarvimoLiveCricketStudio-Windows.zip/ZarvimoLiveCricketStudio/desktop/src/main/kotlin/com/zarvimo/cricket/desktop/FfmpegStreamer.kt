package com.zarvimo.cricket.desktop

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zarvimo.cricket.graphics.OverlayData
import com.zarvimo.cricket.stream.StreamValidator
import com.zarvimo.cricket.stream.ValidationResult
import java.awt.image.BufferedImage
import java.awt.image.DataBufferByte
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.concurrent.TimeUnit

data class DesktopStreamConfig(
    val serverUrl: String,
    val streamKey: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val videoKbps: Int,
    val audioKbps: Int,
    /** DirectShow audio device name, or null for silence. */
    val micName: String?,
    /** Optional path to a local MP4 copy of the broadcast. */
    val recordPath: String?
)

/**
 * Sends the rendered scoreboard picture to an RTMP/RTMPS server by piping raw frames into an FFmpeg process.
 * The stream key is never logged: every text coming back from FFmpeg is scrubbed first.
 */
class FfmpegStreamer {

    var status by mutableStateOf("Not live")
        private set
    var live by mutableStateOf(false)
        private set
    var devices by mutableStateOf<List<String>>(emptyList())
        private set

    @Volatile private var process: Process? = null
    @Volatile private var running = false
    private var worker: Thread? = null

    // ------------------------------------------------------------------------------------------ ffmpeg location

    /** Bundled copy (installed next to the app) first, then a user-given path, then "ffmpeg" from PATH. */
    fun findFfmpeg(custom: String): String? {
        val bundledDir = System.getProperty("compose.application.resources.dir")
        if (bundledDir != null) {
            val f = File(bundledDir, "ffmpeg.exe")
            if (f.isFile) return f.absolutePath
        }
        if (custom.isNotBlank()) {
            val f = File(custom.trim())
            if (f.isFile) return f.absolutePath
        }
        return try {
            val p = ProcessBuilder("ffmpeg", "-version").redirectErrorStream(true).start()
            p.inputStream.readBytes()
            if (p.waitFor(5, TimeUnit.SECONDS) && p.exitValue() == 0) "ffmpeg" else null
        } catch (e: Exception) {
            null
        }
    }

    fun refreshDevices(ffmpeg: String) {
        Thread {
            val names = ArrayList<String>()
            try {
                val p = ProcessBuilder(ffmpeg, "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy")
                    .redirectErrorStream(true).start()
                val text = p.inputStream.bufferedReader().readText()
                p.waitFor(10, TimeUnit.SECONDS)
                val re = Regex("\"([^\"]+)\"\\s*\\(audio\\)")
                for (m in re.findAll(text)) names += m.groupValues[1]
            } catch (e: Exception) {
                // ignore: the list simply stays empty
            }
            devices = names.distinct()
        }.start()
    }

    // ------------------------------------------------------------------------------------------ start / stop

    fun start(ffmpeg: String, cfg: DesktopStreamConfig, overlay: () -> OverlayData, bg: () -> BufferedImage?) {
        if (running) return
        val validation = StreamValidator.validate(cfg.serverUrl, cfg.streamKey)
        val endpoint = when (validation) {
            is ValidationResult.Valid -> validation.endpoint
            is ValidationResult.Invalid -> {
                status = validation.problems.joinToString("; ")
                return
            }
        }

        val k = cfg.videoKbps
        val cmd = ArrayList<String>()
        cmd += listOf(
            ffmpeg, "-hide_banner", "-loglevel", "warning", "-nostats",
            "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "${cfg.width}x${cfg.height}", "-framerate", "${cfg.fps}", "-i", "-"
        )
        if (cfg.micName != null) {
            cmd += listOf("-f", "dshow", "-i", "audio=${cfg.micName}")
        } else {
            cmd += listOf("-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100")
        }
        cmd += listOf(
            "-map", "0:v", "-map", "1:a",
            "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency", "-pix_fmt", "yuv420p",
            "-b:v", "${k}k", "-maxrate", "${k}k", "-bufsize", "${k * 2}k", "-g", "${cfg.fps * 2}",
            "-c:a", "aac", "-b:a", "${cfg.audioKbps}k", "-ar", "44100"
        )
        val rec = cfg.recordPath?.trim().orEmpty()
        if (rec.isNotEmpty()) {
            // one encode, two outputs: the server and a local MP4 copy
            val recSafe = rec.replace('\\', '/')
            cmd += listOf("-f", "tee", "[f=flv:onfail=ignore]$endpoint|[f=mp4:movflags=frag_keyframe+empty_moov]$recSafe")
        } else {
            cmd += listOf("-f", "flv", endpoint)
        }

        val proc = try {
            ProcessBuilder(cmd).redirectErrorStream(true).start()
        } catch (e: IOException) {
            status = "Could not start FFmpeg: ${StreamValidator.scrub(e.message, cfg.streamKey)}"
            return
        }
        process = proc
        running = true
        live = true
        status = "Connecting..."

        val tail = ArrayDeque<String>()
        Thread {
            try {
                proc.inputStream.bufferedReader().forEachLine { line ->
                    synchronized(tail) {
                        tail.addLast(StreamValidator.scrub(line, cfg.streamKey))
                        while (tail.size > 6) tail.removeFirst()
                    }
                }
            } catch (e: IOException) {
                // process ended
            }
        }.also { it.isDaemon = true }.start()

        worker = Thread {
            var failure: String? = null
            try {
                pump(proc.outputStream, cfg, overlay, bg)
            } catch (e: IOException) {
                failure = "FFmpeg stopped"
            } catch (e: Exception) {
                failure = "Error: ${StreamValidator.scrub(e.message, cfg.streamKey)}"
            }
            val wasStopped = !running
            running = false
            try { proc.outputStream.close() } catch (e: IOException) { }
            if (!proc.waitFor(3, TimeUnit.SECONDS)) proc.destroy()
            process = null
            live = false
            status = if (wasStopped && failure == null) "Not live" else {
                val last = synchronized(tail) { tail.toList() }.lastOrNull().orEmpty()
                (failure ?: "Ended") + if (last.isNotBlank()) " - $last" else ""
            }
        }.also { it.isDaemon = true; it.name = "ffmpeg-frame-pump"; it.start() }
    }

    private fun pump(out: OutputStream, cfg: DesktopStreamConfig, overlay: () -> OverlayData, bg: () -> BufferedImage?) {
        val frameNanos = 1_000_000_000L / cfg.fps
        var next = System.nanoTime()
        var lastOverlay: OverlayData? = null
        var lastBg: BufferedImage? = null
        var bytes = ByteArray(0)
        var sent = 0L
        while (running) {
            val o = overlay()
            val b = bg()
            if (o != lastOverlay || b !== lastBg || bytes.isEmpty()) {
                val img = OverlayPainter.render(o, cfg.width, cfg.height, b)
                bytes = (img.raster.dataBuffer as DataBufferByte).data.copyOf()
                lastOverlay = o
                lastBg = b
            }
            out.write(bytes)
            out.flush()
            sent++
            if (sent == cfg.fps.toLong()) status = "LIVE"
            next += frameNanos
            val wait = next - System.nanoTime()
            if (wait > 0) {
                Thread.sleep(wait / 1_000_000, (wait % 1_000_000).toInt())
            } else if (wait < -frameNanos * 5) {
                next = System.nanoTime() // fell behind (slow PC): do not try to catch up
            }
        }
    }

    fun stop() {
        if (!running) return
        status = "Stopping..."
        running = false
    }
}
