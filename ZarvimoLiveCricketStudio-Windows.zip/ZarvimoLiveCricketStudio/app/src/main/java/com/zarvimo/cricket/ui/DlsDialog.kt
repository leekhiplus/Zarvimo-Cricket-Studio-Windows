package com.zarvimo.cricket.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zarvimo.cricket.scoring.DlsCalc
import com.zarvimo.cricket.scoring.DlsInnings
import com.zarvimo.cricket.scoring.DlsStoppage

/** Parses lines "overs left at stop, wickets down, overs left at resume" (cricket notation: 12.3 = 12 overs 3 balls). */
internal fun parseStoppages(text: String, bpo: Int): Pair<List<DlsStoppage>, String?> {
    val out = ArrayList<DlsStoppage>()
    for ((i, raw) in text.lines().withIndex()) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        val t = line.split(Regex("[\\s;,]+")).filter { it.isNotEmpty() }
        if (t.size != 3) return Pair(emptyList(), "Line ${i + 1}: write three numbers: overs left when play stopped, wickets down, overs left when play resumed.")
        val stop = DlsCalc.parseOvers(t[0], bpo)
        val w = t[1].toIntOrNull()
        val resume = DlsCalc.parseOvers(t[2], bpo)
        if (stop == null || resume == null || w == null || w !in 0..9) return Pair(emptyList(), "Line ${i + 1}: numbers are not valid.")
        if (resume > stop) return Pair(emptyList(), "Line ${i + 1}: overs left at resume cannot be more than at the stop.")
        out += DlsStoppage(stop, w, resume)
    }
    return Pair(out, null)
}

/**
 * Duckworth-Lewis-Stern calculator: resources of both teams, revised target, par score now. Uses the official table when
 * one has been pasted, otherwise the built-in ESTIMATE (clearly labelled). Applying changes the overs and target of the match.
 */
@Composable
fun DlsDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val m by vm.match.collectAsState()
    val table by vm.dlsTable.collectAsState()
    val st = m.state
    val bpo = m.setup.ballsPerOver
    val matchOvers = m.setup.oversLimit
    var g50 by remember { mutableStateOf("245") }
    var t1Overs by remember { mutableStateOf(matchOvers.toString()) }
    var t1Score by remember { mutableStateOf(vm.firstInningsRuns()?.toString() ?: "") }
    var t1Stops by remember { mutableStateOf("") }
    var t2Overs by remember { mutableStateOf(matchOvers.toString()) }
    var t2Stops by remember { mutableStateOf("") }
    var pasteOpen by remember { mutableStateOf(false) }
    var pasted by remember { mutableStateOf("") }
    var pasteError by remember { mutableStateOf<String?>(null) }

    val p1 = parseStoppages(t1Stops, bpo)
    val p2 = parseStoppages(t2Stops, bpo)
    val s1 = DlsCalc.parseOvers(t1Overs, bpo)
    val s2 = DlsCalc.parseOvers(t2Overs, bpo)
    val score = t1Score.trim().toIntOrNull()
    val g = g50.trim().toIntOrNull() ?: 0
    val ready = s1 != null && s2 != null && score != null && p1.second == null && p2.second == null
    val team1 = if (ready) DlsInnings(s1!!, p1.first) else null
    val team2 = if (ready) DlsInnings(s2!!, p2.first) else null
    val outcome = if (team1 != null && team2 != null) DlsCalc.target(table, g, score!!, team1, team2) else null
    val chasing = st != null && m.inningsIndex == 1 && !st.ended

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("DLS calculator") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (table.official) {
                    Text("Table: OFFICIAL (the one you pasted)", fontWeight = FontWeight.Bold, color = Mint, fontSize = 13.sp)
                } else {
                    WarnLine(
                        "Table: built-in ESTIMATE. The official DLS tables are not included in this app, so these numbers are close but NOT official. " +
                            "Paste the official table below before using a result for a real decision.",
                        color = Color(0xFFFFB74D)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigButton(if (pasteOpen) "Close" else "Paste official table", Modifier.weight(1f).height(44.dp), icon = Ic.Upload) { pasteOpen = !pasteOpen }
                    if (table.official) BigButton("Use estimate", Modifier.weight(1f).height(44.dp), Color(0xFF5A2A2A), icon = Ic.Trash) { vm.useEstimatedDlsTable() }
                }
                if (pasteOpen) {
                    Text("One line per row: overs left (0 to 50), then the resource % for 0, 1, 2 ... 9 wickets lost. A header line is fine.", fontSize = 12.sp)
                    TextInput("Official table", pasted, { pasted = it; pasteError = null }, singleLine = false, placeholder = "50 100 93.4 85.1 ...")
                    pasteError?.let { WarnLine(it) }
                    BigButton("Use this table", Modifier.fillMaxWidth(), Gold, Color.Black, enabled = pasted.isNotBlank(), icon = Ic.Check) {
                        val err = vm.loadDlsTable(pasted)
                        pasteError = err
                        if (err == null) { pasted = ""; pasteOpen = false }
                    }
                }
                Text("Team 1 (batted first)", fontWeight = FontWeight.Bold, color = Gold, fontSize = 14.sp)
                TextInput("Runs scored", t1Score, { t1Score = it }, numeric = true)
                TextInput("Overs it was allowed to bat (start)", t1Overs, { t1Overs = it }, placeholder = "20  or  17.2")
                TextInput(
                    "Stoppages in its innings (one per line)", t1Stops, { t1Stops = it }, singleLine = false,
                    placeholder = "overs left at stop, wickets down, overs left at resume\n12.0, 3, 8.0"
                )
                p1.second?.let { WarnLine(it) }
                Text("Team 2 (chasing)", fontWeight = FontWeight.Bold, color = Gold, fontSize = 14.sp)
                TextInput("Overs it is allowed to bat (start)", t2Overs, { t2Overs = it }, placeholder = "20  or  15.0")
                TextInput(
                    "Stoppages in its innings so far (one per line)", t2Stops, { t2Stops = it }, singleLine = false,
                    placeholder = "overs left at stop, wickets down, overs left at resume"
                )
                p2.second?.let { WarnLine(it) }
                TextInput("G50 (245 for ODI and T20; use your playing conditions)", g50, { g50 = it }, numeric = true)

                if (outcome != null) {
                    Text(
                        "R1 ${"%.1f".format(java.util.Locale.ROOT, outcome.r1)}%    R2 ${"%.1f".format(java.util.Locale.ROOT, outcome.r2)}%",
                        fontSize = 14.sp
                    )
                    Text("Revised target: ${outcome.target}", fontWeight = FontWeight.ExtraBold, color = Gold, fontSize = 22.sp)
                    val ov = s2!!
                    Text("in ${"%.1f".format(java.util.Locale.ROOT, ov)} overs".replace(".0 overs", " overs"), fontSize = 13.sp)
                    if (chasing && st != null) {
                        val left = st.ballsRemaining.toDouble() / bpo
                        val par = DlsCalc.parNow(table, g, score!!, team1!!, team2!!, left, st.wickets)
                        if (par != null) {
                            val parInt = Math.floor(par + 1e-9).toInt()
                            val diff = st.runs - parInt
                            Text(
                                "Par score now: $parInt  (${if (diff >= 0) "ahead by $diff" else "behind by ${-diff}"})",
                                fontWeight = FontWeight.Bold, fontSize = 14.sp
                            )
                        }
                    }
                    val whole1 = s1!!.takeIf { it == Math.rint(it) }?.toInt()
                    val whole2 = s2.takeIf { it == Math.rint(it) }?.toInt()
                    val applyOk = m.inningsIndex in 0..1 &&
                        (whole1 == null || whole1 in 1..matchOvers) && (whole2 == null || whole2 in 1..matchOvers)
                    if (whole2 == null || whole1 == null) {
                        Text("Part-over allocations cannot be applied to the match clock: the target is still shown here. Round the overs or set the target by hand.", fontSize = 11.sp, color = Color(0xFFFFB74D))
                    }
                    BigButton(
                        if (m.inningsIndex == 0) "Apply overs to the 1st innings" else "Apply target ${outcome.target}" + (whole2?.let { " in $it overs" } ?: ""),
                        Modifier.fillMaxWidth(), Gold, Color.Black, enabled = applyOk, icon = Ic.Check
                    ) {
                        vm.applyDls(outcome.target, whole1?.takeIf { it != matchOvers }, whole2?.takeIf { it != matchOvers })
                        onDismiss()
                    }
                } else {
                    Text("Fill in the scores and overs to calculate.", fontSize = 12.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
