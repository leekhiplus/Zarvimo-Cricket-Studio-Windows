package com.zarvimo.cricket.desktop

import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPosition
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState

fun main() = application {
    val state = AppState()
    Window(
        onCloseRequest = {
            state.streamer.stop()
            exitApplication()
        },
        title = "Zarvimo Live Cricket Studio",
        state = rememberWindowState(size = DpSize(1360.dp, 860.dp), position = WindowPosition.PlatformDefault)
    ) {
        App(state)
    }
}
