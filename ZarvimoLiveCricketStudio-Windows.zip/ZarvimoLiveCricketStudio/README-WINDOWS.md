# Zarvimo Live Cricket Studio — Windows edition

**اردو میں:** پورا پروجیکٹ (`app/` اور `desktop/` دونوں فولڈر) GitHub پر اپلوڈ کریں → *Actions* → **Build Windows App** → *Run workflow*.
مکمل ہونے پر *Artifacts* سے `Zarvimo-Live-Cricket-Studio-Windows-portable` ڈاؤن لوڈ کریں، ZIP کھولیں، اور اندر `ZarvimoLiveCricketStudio.exe` چلائیں
(انسٹال کی ضرورت نہیں؛ FFmpeg اندر شامل ہے). `...-installers` میں `.msi` / `.exe` انسٹالر بھی ملے گا (اگر وہ مرحلہ کامیاب ہو).

## What it is
A separate Compose-for-Desktop project in `desktop/`. The Android app in `app/` is untouched and still builds with *Build Android APK*.

| Part | Windows edition |
|---|---|
| Scoring, DLS, overlay model, JSON save/load | **shared** with Android (same source files) |
| Scoreboard picture | Java2D (`OverlayPainter`) — the preview and the stream use the same function |
| Encoding + RTMP/RTMPS | FFmpeg (bundled by the workflow, or any `ffmpeg.exe` in PATH) |
| Video source | background picture or built-in stadium |
| Audio | silent, or a DirectShow microphone |

## NOT in the Windows edition (yet)
Camera picture / round camera bubble, music playlist, crowd sounds & effects mixer, spoken commentary, full-screen four/six/wicket animations,
on-air scorecard panels, DLS dialog, squad (Playing XI) screens, 19 scoreboard templates (one clean template is drawn).
The shared model code for most of these is already compiled in; they need desktop UI/audio code.

## Verification status (honest)
* The Windows code was written without a Gradle/Kotlin compiler or Windows machine available: it has **never been compiled or run**.
  The first GitHub run may show compile errors — send me the red log lines and I will fix them.
* Live streaming through FFmpeg is untested. Test with a private/unlisted YouTube stream first.
