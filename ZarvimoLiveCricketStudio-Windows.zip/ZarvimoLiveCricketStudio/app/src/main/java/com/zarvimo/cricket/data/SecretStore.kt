package com.zarvimo.cricket.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Optional "remember my stream key" storage. The key is encrypted with an AES-256-GCM key that lives in the Android
 * Keystore (not extractable). Nothing is written unless the user explicitly enables "Remember". The plain key is never
 * logged and is excluded from backups (allowBackup=false).
 */
object SecretStore {
    private const val ALIAS = "zarvimo_stream_key_v1"
    private const val PREFS = "zarvimo_secrets"
    private const val PREF_KEY = "stream_key_blob"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun save(context: Context, plain: String, prefKey: String = PREF_KEY) {
        if (plain.isBlank()) { clear(context, prefKey); return }
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, secretKey())
            val blob = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(prefKey, Base64.encodeToString(blob, Base64.NO_WRAP)).apply()
        } catch (e: Exception) {
            clear(context, prefKey) // never fall back to plaintext
        }
    }

    fun load(context: Context, prefKey: String = PREF_KEY): String {
        val b64 = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(prefKey, null) ?: return ""
        return try {
            val blob = Base64.decode(b64, Base64.NO_WRAP)
            val iv = blob.copyOfRange(0, 12)
            val data = blob.copyOfRange(12, blob.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(c.doFinal(data), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }

    fun clear(context: Context, prefKey: String = PREF_KEY) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(prefKey).apply()
    }
}
