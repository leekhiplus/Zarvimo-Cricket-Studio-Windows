package com.zarvimo.cricket.desktop

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.zarvimo.cricket.data.Json
import com.zarvimo.cricket.graphics.MatchVisuals
import com.zarvimo.cricket.graphics.OverlayBuilder
import com.zarvimo.cricket.graphics.OverlayData
import com.zarvimo.cricket.scoring.BallEvent
import com.zarvimo.cricket.scoring.BatterInEvent
import com.zarvimo.cricket.scoring.DismissalType
import com.zarvimo.cricket.scoring.EndInningsEvent
import com.zarvimo.cricket.scoring.ExtraType
import com.zarvimo.cricket.scoring.InningsSetup
import com.zarvimo.cricket.scoring.MatchSession
import com.zarvimo.cricket.scoring.MatchSetup
import com.zarvimo.cricket.scoring.OpResult
import com.zarvimo.cricket.scoring.PenaltyEvent
import com.zarvimo.cricket.scoring.SetBowlerEvent
import com.zarvimo.cricket.scoring.SwapStrikeEvent
import com.zarvimo.cricket.scoring.WicketInfo
import org.json.JSONObject
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/**
 * All state of the desktop app. [MatchSession] is a mutable class, so every change calls [touch], which bumps [rev]
 * (Compose re-reads) and refreshes [liveOverlay] (read by the streaming thread).
 */
class AppState {
    var setup by mutableStateOf(MatchSetup(teamA = "Team A", teamB = "Team B", oversLimit = 20))
    var visuals by mutableStateOf(MatchVisuals())
    var session by mutableStateOf<MatchSession?>(null)
    var extraMode by mutableStateOf(ExtraType.NONE)
    var message by mutableStateOf("")
    var rev by mutableIntStateOf(0)

    var bgImage by mutableStateOf<BufferedImage?>(null)
    var bgImagePath by mutableStateOf("")

    @Volatile
    var liveOverlay: OverlayData = OverlayBuilder.from(setup, null, visuals)

    val streamer = FfmpegStreamer()

    fun overlay(): OverlayData {
        rev.hashCode() // read, so that Compose recomposes after every scoring action
        return OverlayBuilder.from(setup, session, visuals)
    }

    fun touch() {
        rev++
        liveOverlay = OverlayBuilder.from(setup, session, visuals)
    }

    // ---------------------------------------------------------------- match
    fun createMatch() {
        val err = setup.validate()
        if (err != null) {
            message = err
            return
        }
        session = MatchSession(setup)
        message = ""
        touch()
    }

    fun resetMatch() {
        session = null
        extraMode = ExtraType.NONE
        message = ""
        touch()
    }

    fun nextBattingTeam(): String {
        val s = session ?: return setup.teamA
        val n = s.innings.size
        if (n == 0) return setup.battingFirstTeam ?: setup.teamA
        val prev = s.stateOf(n - 1) ?: return setup.teamA
        return if (n % 2 == 1) prev.bowlingTeam else (s.nextSuperOverBattingTeam ?: prev.battingTeam)
    }

    fun otherTeam(team: String): String =
        if (team.trim().equals(setup.teamA.trim(), ignoreCase = true)) setup.teamB else setup.teamA

    fun canStartInnings(): Boolean {
        val s = session ?: return false
        val n = s.innings.size
        if (n == 0) return true
        val st = s.stateOf(n - 1) ?: return false
        if (!st.ended) return false
        return n % 2 == 1 || s.canStartSuperOver
    }

    fun startInnings(striker: String, nonStriker: String, bowler: String) {
        val bat = nextBattingTeam()
        exec { it.startInnings(InningsSetup(bat, otherTeam(bat), striker.trim(), nonStriker.trim(), bowler.trim())) }
    }

    // ---------------------------------------------------------------- scoring
    private fun exec(op: (MatchSession) -> OpResult) {
        val s = session
        if (s == null) {
            message = "Create the match first"
            return
        }
        message = when (val r = op(s)) {
            is OpResult.Ok -> ""
            is OpResult.Error -> r.message
        }
        touch()
    }

    private fun ballWith(n: Int, w: WicketInfo?) {
        val mode = extraMode
        val boundary = w == null && (n == 4 || n == 6)
        exec { s ->
            s.add { id ->
                when (mode) {
                    ExtraType.NONE -> BallEvent(id, runsBat = n, boundary = boundary, wicket = w)
                    ExtraType.NO_BALL -> BallEvent(id, runsBat = n, extra = ExtraType.NO_BALL, boundary = boundary, wicket = w)
                    ExtraType.WIDE -> BallEvent(id, extra = ExtraType.WIDE, extraRuns = n, wicket = w)
                    ExtraType.BYE -> BallEvent(id, extra = ExtraType.BYE, extraRuns = n, wicket = w)
                    ExtraType.LEG_BYE -> BallEvent(id, extra = ExtraType.LEG_BYE, extraRuns = n, wicket = w)
                }
            }
        }
        extraMode = ExtraType.NONE
    }

    fun ball(runs: Int) = ballWith(runs, null)

    fun wicket(type: DismissalType, outIsStriker: Boolean, fielder: String, incoming: String, runs: Int) {
        val info = WicketInfo(
            type = type,
            outBatterIsStriker = outIsStriker,
            fielder = fielder.trim().ifEmpty { null },
            incomingBatter = incoming.trim().ifEmpty { null }
        )
        ballWith(if (type.allowsRuns) runs else 0, info)
    }

    fun setBowler(name: String) = exec { s -> s.add { id -> SetBowlerEvent(id, name.trim()) } }
    fun batterIn(name: String) = exec { s -> s.add { id -> BatterInEvent(id, name.trim()) } }
    fun swapStrike() = exec { s -> s.add { id -> SwapStrikeEvent(id) } }
    fun penalty(runs: Int) = exec { s -> s.add { id -> PenaltyEvent(id, runs) } }
    fun endInnings() = exec { s -> s.add { id -> EndInningsEvent(id, "Declared") } }
    fun undo() = exec { it.undo() }
    fun redo() = exec { it.redo() }

    // ---------------------------------------------------------------- files
    fun saveMatch(file: File) {
        try {
            val saved = Json.SavedMatch(
                id = "desktop", name = setup.title.ifBlank { "${setup.teamA} v ${setup.teamB}" },
                updatedAtMs = System.currentTimeMillis(), setup = setup, visuals = visuals, session = session
            )
            file.writeText(Json.matchToJson(saved).toString(2), Charsets.UTF_8)
            message = "Saved: ${file.name}"
        } catch (e: Exception) {
            message = "Could not save: ${e.message}"
        }
    }

    fun loadMatch(file: File) {
        try {
            val m = Json.matchFromJson(JSONObject(file.readText(Charsets.UTF_8)))
            setup = m.setup
            visuals = m.visuals
            session = m.session ?: MatchSession(m.setup)
            extraMode = ExtraType.NONE
            message = "Loaded: ${file.name}"
            touch()
        } catch (e: Exception) {
            message = "Could not load: ${e.message}"
        }
    }

    fun loadBackground(file: File) {
        try {
            val img = ImageIO.read(file)
            if (img == null) {
                message = "This picture format is not supported"
                return
            }
            bgImage = img
            bgImagePath = file.absolutePath
        } catch (e: Exception) {
            message = "Could not open the picture: ${e.message}"
        }
    }

    fun clearBackground() {
        bgImage = null
        bgImagePath = ""
    }
}
